'use strict';
/* ==========================================================
   UNMUTE — Lógica del diario emocional
   Los registros viven solo en este navegador (localStorage).
   Registros: unmute_registros_v1 · Borrador: unmute_borrador_v1
   ========================================================== */

/* ---------- Catálogo de emociones ---------- */
const MOODS = {
  muyfeliz:{emoji:'😄', nombre:'Muy feliz', tipo:'positivo', color:'#f59e46'},
  feliz:   {emoji:'🙂', nombre:'Feliz',     tipo:'positivo', color:'#f7bb5f'},
  neutral: {emoji:'😐', nombre:'Neutral',   tipo:'neutral',  color:'#9aa7c9'},
  triste:  {emoji:'😔', nombre:'Triste',    tipo:'negativo', color:'#7f8fe0'},
  mal:     {emoji:'😣', nombre:'Mal',       tipo:'negativo', color:'#6d78cf'},
  enojado: {emoji:'😡', nombre:'Enojado',   tipo:'negativo', color:'#e2707f'},
  ansioso: {emoji:'😰', nombre:'Ansioso',   tipo:'negativo', color:'#9d7ce0'},
  cansado: {emoji:'😴', nombre:'Cansado',   tipo:'negativo', color:'#8fa6c9'}
};

const KEY = 'unmute_registros_v1', DRAFT = 'unmute_borrador_v1', MAX = 800, PAGE = 30;
const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
let registros = [], protegido = false, avisoFijo = '', editandoId = null, guardando = false, limite = PAGE;

/* ---------- Utilidades ---------- */
const $ = (sel) => document.querySelector(sel);
function formatearFechaLarga(iso){
  return new Intl.DateTimeFormat('es-ES',{weekday:'long', day:'numeric', month:'long', year:'numeric'}).format(new Date(iso));
}
function formatearFechaCorta(iso){
  const d = new Date(iso);
  return String(d.getDate()).padStart(2,'0') + '/' + String(d.getMonth()+1).padStart(2,'0');
}

const $$ = (s) => [...document.querySelectorAll(s)];
const hora = (iso) => new Intl.DateTimeFormat('es-ES', {hour:'2-digit', minute:'2-digit'}).format(new Date(iso));
const dia = (iso) => { const d = new Date(iso); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); };
const norm = (s) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const uid = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : Date.now() + '-' + Math.random().toString(36).slice(2, 9);
const firma = (r) => r.fecha + '|' + r.mood + '|' + r.texto;
function el(t, c, x, a){
  const e = document.createElement(t);
  if(c) e.className = c;
  if(x != null) e.textContent = x;
  if(a) for(const k in a) e.setAttribute(k, a[k]);
  return e;
}
/* ---------- Toast ---------- */
let toastTimer = null;
function showToast(msg){
  const t = $('#toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(()=> t.classList.remove('show'), 3200);
}


/* ---------- Almacenamiento seguro ---------- */
const MSG_MEM = 'No se pudo guardar en este navegador (almacenamiento lleno o bloqueado). Tus registros siguen aquí mientras no cierres la página: descarga una copia en «Mis datos».';
function avisar(m){ const b = $('#storageWarn'); b.textContent = m || avisoFijo; b.hidden = !b.textContent; }
function validar(r){
  if(!r || typeof r !== 'object') return null;
  const f = new Date(r.fecha), n = Math.round(Number(r.intensidad));
  if(isNaN(f) || !MOODS[r.mood] || !(n >= 1 && n <= 5)) return null;
  const o = {id: (typeof r.id === 'string' && r.id && r.id.length < 80) ? r.id : uid(), fecha: f.toISOString(), mood: r.mood, intensidad: n, texto: typeof r.texto === 'string' ? r.texto.slice(0, MAX) : ''};
  const e = r.editado ? new Date(r.editado) : null;
  if(e && !isNaN(e)) o.editado = e.toISOString();
  return o;
}
function respaldar(raw, msg){
  try{ localStorage.setItem(KEY + '_copia_' + Date.now(), raw); avisoFijo = msg + ' Se guardó una copia del original en este navegador.'; }
  catch(e){ protegido = true; avisoFijo = msg + ' No se pudo hacer una copia, así que no se guardarán cambios en este navegador.'; }
}
function cargar(){
  let raw;
  try{ raw = localStorage.getItem(KEY); }catch(e){ protegido = true; avisoFijo = MSG_MEM; return []; }
  if(!raw) return [];
  try{
    const arr = JSON.parse(raw);
    if(!Array.isArray(arr)) throw new Error('formato');
    const ids = new Set(), out = [];
    arr.forEach((x) => { const r = validar(x); if(!r) return; if(ids.has(r.id)) r.id = uid(); ids.add(r.id); out.push(r); });
    if(out.length < arr.length) respaldar(raw, 'Se omitieron ' + (arr.length - out.length) + ' registros con formato inesperado.');
    return out;
  }catch(e){ respaldar(raw, 'No se pudieron leer tus datos guardados.'); return []; }
}
function guardar(){
  if(protegido){ avisar(MSG_MEM); return false; }
  try{ localStorage.setItem(KEY, JSON.stringify(registros)); avisar(''); return true; }
  catch(e){ avisar(MSG_MEM); return false; }
}

/* ---------- Diálogo de confirmación reutilizable ---------- */
let resolverModal = null, focoPrevio = null;
function confirmar(o){
  return new Promise((res) => {
    focoPrevio = document.activeElement;
    $('#modalIcon').textContent = o.icono || '💜';
    $('#modalTitle').textContent = o.titulo; $('#modalText').textContent = o.texto;
    $('#modalExtra').replaceChildren(...(o.lineas || []).map((t) => el('li', null, t)));
    const si = $('#modalConfirmar'); si.textContent = o.si; si.className = 'btn ' + (o.peligro ? 'btn-danger' : 'btn-primary');
    $('#modalCancelar').textContent = o.no || 'Cancelar';
    resolverModal = res; $('#modalOverlay').classList.add('open'); $('#modalCancelar').focus();
  });
}
function cerrarModal(v){
  if(!resolverModal) return;
  const r = resolverModal; resolverModal = null; $('#modalOverlay').classList.remove('open');
  const f = (focoPrevio && document.contains(focoPrevio) && focoPrevio.offsetParent !== null) ? focoPrevio : $('.view.active h2, .view.active h1');
  if(f) f.focus();
  r(v);
}
$('#modalCancelar').addEventListener('click', () => cerrarModal(false));
$('#modalConfirmar').addEventListener('click', () => cerrarModal(true));
$('#modalOverlay').addEventListener('click', (e) => { if(e.target === e.currentTarget) cerrarModal(false); });

/* ---------- Navegación ---------- */
const VIEWS = ['inicio', 'registrar', 'historial', 'estado', 'datos'];
const menu = $('#navMenu'), tog = $('#navToggle');
const cerrarMenu = () => { menu.classList.remove('open'); tog.setAttribute('aria-expanded', 'false'); };
function navegar(nombre){
  if(!VIEWS.includes(nombre)) nombre = 'inicio';
  $$('.view').forEach((v) => v.classList.remove('active'));
  const vista = $('#view-' + nombre); vista.classList.add('active');
  $$('nav [data-nav]').forEach((a) => {
    const on = a.dataset.nav === nombre;
    a.classList.toggle('active', on);
    if(on) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
  });
  cerrarMenu();
  window.scrollTo({top: 0, behavior: reduceMotion ? 'auto' : 'smooth'});
  const h = vista.querySelector('h1,h2');
  if(h){ h.setAttribute('tabindex', '-1'); h.focus({preventScroll: true}); }
}
window.addEventListener('hashchange', () => navegar(location.hash.replace('#', '')));
tog.addEventListener('click', () => tog.setAttribute('aria-expanded', String(menu.classList.toggle('open'))));
menu.addEventListener('click', (e) => { if(e.target.closest('a')) cerrarMenu(); });
$('#ctaFeel').addEventListener('click', () => {
  location.hash = 'registrar';
  setTimeout(() => { const f = $('#moodGrid input'); if(f) f.focus({preventScroll: true}); }, 350);
});
document.addEventListener('keydown', (e) => {
  if(resolverModal){
    if(e.key === 'Escape') cerrarModal(false);
    else if(e.key === 'Tab'){ e.preventDefault(); ($('#modalCancelar') === document.activeElement ? $('#modalConfirmar') : $('#modalCancelar')).focus(); }
    return;
  }
  if(e.key === 'Escape' && menu.classList.contains('open')){ cerrarMenu(); tog.focus(); }
});
/* Anillo de foco visible en tarjetas de emoción e intensidad (solo con teclado) */
document.addEventListener('focusin', (e) => { const l = e.target.closest && e.target.closest('.mood-card,.intensity-opt'); if(l && e.target.matches(':focus-visible')) l.classList.add('kb'); });
document.addEventListener('focusout', (e) => { const l = e.target.closest && e.target.closest('.mood-card,.intensity-opt'); if(l) l.classList.remove('kb'); });

/* ---------- Revelado al hacer scroll (el contenido es visible si falla) ---------- */
const revelables = $$('.reveal');
if(reduceMotion || !('IntersectionObserver' in window)){ revelables.forEach((e) => e.classList.add('in')); }
else{
  const obs = new IntersectionObserver((es) => es.forEach((x) => { if(x.isIntersecting){ x.target.classList.add('in'); obs.unobserve(x.target); } }), {threshold: .15});
  revelables.forEach((e) => obs.observe(e));
}

/* ---------- Mensajes de apoyo (locales, sin IA) ---------- */
const MSG = {
  alegre: ['Qué bonito que hoy haya sido un buen día. Guarda este momento y recuerda que también puedes volver a sentirte así.', 'Lo que se siente bien también merece quedar escrito. Disfrútalo sin prisa.'],
  neutral: ['Los días tranquilos también cuentan. Hoy estuviste aquí, y eso ya es importante.', 'No todo tiene que ser intenso para merecer un registro.'],
  triste: ['Está bien no sentirse bien todo el tiempo. Date permiso para sentir lo que estás sintiendo y recuerda que un día difícil no define todos tus días.', 'Lo que sientes es real aunque no sepas explicarlo. Aquí no hace falta justificarlo.'],
  ansioso: ['Tómate un momento. Respira, ve paso a paso y recuerda que no tienes que resolverlo todo de una vez.', 'Si quieres, apoya los pies en el suelo y suelta el aire despacio. Con eso basta por ahora.'],
  enojado: ['Tus emociones son válidas. Antes de reaccionar, date un momento para respirar y entender qué estás sintiendo.', 'El enojo suele avisar de algo que importa. No tienes que resolverlo hoy.'],
  cansado: ['Descansar también es avanzar. No tienes que estar al máximo todos los días.', 'Si tu cuerpo pide una pausa, escucharlo también es cuidarte.']
};
const GRUPO = {muyfeliz:'alegre', feliz:'alegre', neutral:'neutral', triste:'triste', mal:'triste', ansioso:'ansioso', enojado:'enojado', cansado:'cansado'};
const ultMsg = {};
function generarMensaje(mood){
  const g = GRUPO[mood], a = MSG[g];
  if(!a) return 'Gracias por compartir cómo te sientes.';
  let i = Math.floor(Math.random() * a.length);
  if(i === ultMsg[g]) i = (i + 1) % a.length;
  ultMsg[g] = i; return a[i];
}
/* Observación descriptiva y prudente: solo refleja lo registrado */
function mensajeHistorial(){
  if(!registros.length) return null;
  const rec = [...registros].sort((a, b) => b.fecha.localeCompare(a.fecha)).slice(0, 5);
  const neg = rec.filter((r) => MOODS[r.mood].tipo === 'negativo').length, pos = rec.filter((r) => MOODS[r.mood].tipo === 'positivo').length;
  const u = Math.ceil(rec.length * .75);
  if(rec.length >= 3 && neg >= u) return 'En tus últimos registros han aparecido varias emociones difíciles. Es solo un reflejo de lo que anotaste, no de todo lo que eres. Si te pesa, contárselo a alguien de confianza puede aliviar un poco.';
  if(rec.length >= 3 && pos >= u) return 'En tus últimos registros aparecen sobre todo momentos agradables. Es bonito poder mirarlos de vez en cuando.';
  return 'Gracias por seguir escribiendo cómo te sientes. Mirar tu camino con cariño también es cuidarte.';
}

/* Partículas de celebración al guardar */
function lanzarParticulas(x, y){
  if(reduceMotion) return;
  const simbolos = ['💜','✨','🤍','💫','💜'];
  for(let i=0;i<8;i++){
    const p = document.createElement('span');
    p.className = 'particle';
    p.textContent = simbolos[i % simbolos.length];
    p.style.left = x + 'px';
    p.style.top  = y + 'px';
    p.style.setProperty('--tx', (Math.random()*180 - 90) + 'px');
    p.style.setProperty('--ty', (-60 - Math.random()*120) + 'px');
    document.body.appendChild(p);
    p.addEventListener('animationend', ()=> p.remove());
  }
}

/* ---------- Formulario de registro ---------- */
const valMood = () => { const r = $('#moodGrid input:checked'); return r ? r.value : ''; };
const valInt = () => +$('#intensityRow input:checked').value;
function marcar(){ $$('.mood-card,.intensity-opt').forEach((l) => l.classList.toggle('selected', l.querySelector('input').checked)); }
function contar(){ const n = $('#textoInput').value.length, c = $('#charCount'); c.textContent = n + ' / ' + MAX; c.classList.toggle('near', n >= MAX - 80); }
function errMood(on){
  $('#moodError').hidden = !on;
  const fs = $('#moodGrid').closest('fieldset');
  if(on) fs.setAttribute('aria-describedby', 'moodError'); else fs.removeAttribute('aria-describedby');
}
function setForm(m, i, t){
  $$('#moodGrid input').forEach((x) => { x.checked = (x.value === m); });
  $('#intensityRow input[value="' + i + '"]').checked = true;
  $('#textoInput').value = t || ''; marcar(); contar(); errMood(false);
}
/* Borrador: se guarda al escribir y sobrevive a recargas o cambios de sección */
function guardarBorrador(){
  if(editandoId) return;
  const d = {mood: valMood(), intensidad: valInt(), texto: $('#textoInput').value};
  try{ if(d.mood || d.texto.trim()) localStorage.setItem(DRAFT, JSON.stringify(d)); else localStorage.removeItem(DRAFT); }catch(e){}
}
function borrarBorrador(){ try{ localStorage.removeItem(DRAFT); }catch(e){} }
function restaurarBorrador(silencio){
  let d = null; try{ d = JSON.parse(localStorage.getItem(DRAFT)); }catch(e){}
  if(!d || typeof d !== 'object') return;
  const n = Math.round(Number(d.intensidad)), t = typeof d.texto === 'string' ? d.texto.slice(0, MAX) : '';
  if(!MOODS[d.mood] && !t.trim()) return;
  setForm(MOODS[d.mood] ? d.mood : '', (n >= 1 && n <= 5) ? n : 3, t);
  if(!silencio) showToast('Recuperamos tu borrador.');
}
function hayCambios(){
  if(editandoId){ const r = registros.find((x) => x.id === editandoId); return !!r && (r.mood !== valMood() || r.intensidad !== valInt() || r.texto !== $('#textoInput').value.trim()); }
  return !!valMood() || $('#textoInput').value.trim() !== '';
}
$('#moodGrid').addEventListener('change', () => { marcar(); errMood(false); guardarBorrador(); });
$('#intensityRow').addEventListener('change', () => { marcar(); guardarBorrador(); });
$('#textoInput').addEventListener('input', () => { contar(); guardarBorrador(); });

function salirEdicion(){
  editandoId = null; $('#editBanner').hidden = true; $('#discardBtn').hidden = false;
  $('#saveBtn').textContent = '💾 Guardar registro';
  setForm('', 3, ''); restaurarBorrador(true);
}
async function editar(id){
  const r = registros.find((x) => x.id === id); if(!r) return;
  if(editandoId && editandoId !== id && hayCambios() && !await confirmar({icono:'✏️', titulo:'¿Cambiar de registro?', texto:'Tienes cambios sin guardar en otro registro. Si continúas, se descartarán.', si:'Descartar y continuar', no:'Seguir editando', peligro:true})) return;
  editandoId = id; setForm(r.mood, r.intensidad, r.texto);
  $('#editInfo').textContent = 'Editando el registro del ' + formatearFechaLarga(r.fecha) + ', ' + hora(r.fecha) + '.';
  $('#editBanner').hidden = false; $('#discardBtn').hidden = true; $('#saveBtn').textContent = '💾 Guardar cambios';
  $('#mensajeGuardado').replaceChildren(); location.hash = 'registrar';
}
$('#cancelEdit').addEventListener('click', async () => {
  if(hayCambios() && !await confirmar({icono:'✏️', titulo:'¿Descartar los cambios?', texto:'Los cambios que hiciste a este registro no se guardarán.', si:'Descartar cambios', no:'Seguir editando', peligro:true})) return;
  salirEdicion(); location.hash = 'historial';
});
$('#discardBtn').addEventListener('click', async () => {
  if(!hayCambios()){ showToast('No hay nada que limpiar.'); return; }
  if(!await confirmar({icono:'🧹', titulo:'¿Limpiar lo que escribiste?', texto:'Se vaciará el formulario y también el borrador guardado. Este texto no se podrá recuperar.', si:'Sí, limpiar', no:'Seguir escribiendo', peligro:true})) return;
  borrarBorrador(); setForm('', 3, ''); $('#textoInput').focus();
});

function mostrarExito(reg){
  const m = MOODS[reg.mood], box = $('#mensajeGuardado'), hist = mensajeHistorial(), card = el('div', 'success-card');
  card.innerHTML = '<div class="check" aria-hidden="true"><svg viewBox="0 0 24 24"><path d="M4 12.5l5.2 5.2L20 6.5"/></svg></div>' +
    '<h3>Tu voz fue escuchada. Tu registro ha sido guardado.</h3>' +
    '<p>' + m.emoji + ' Registraste <strong>' + m.nombre + '</strong> con intensidad ' + reg.intensidad + ' de 5.</p>';
  card.append(el('div', 'success-quote', '“' + generarMensaje(reg.mood) + '”'));
  if(hist) card.append(el('div', 'success-quote', '“' + hist + '”'));
  if(reg.mood === 'ansioso'){
    const b = el('div', 'breath');
    b.append(el('div', 'breath-circle', null, {'aria-hidden': 'true'}), el('p', null, 'Sigue el círculo: inhala despacio… y exhala despacio. Un momento a la vez.'));
    card.append(b);
  }
  const acc = el('div', 'success-actions'), otro = el('button', 'btn btn-ghost', '✍️ Escribir otro registro', {type: 'button'}),
    ver = el('a', 'btn btn-ghost', 'Ver mi historial', {href: '#historial', 'data-nav': 'historial'});
  otro.addEventListener('click', () => { box.replaceChildren(); $('#textoInput').focus(); });
  acc.append(otro, ver); card.append(acc); box.replaceChildren(card);
  card.scrollIntoView({behavior: reduceMotion ? 'auto' : 'smooth', block: 'center'});
}
$('#regForm').addEventListener('submit', (e) => {
  e.preventDefault();
  if(guardando) return;
  const mood = valMood();
  if(!mood){
    errMood(true);
    const g = $('#moodGrid'); g.classList.remove('shake'); void g.offsetWidth; g.classList.add('shake');
    $('#moodGrid input').focus(); return;
  }
  guardando = true; $('#saveBtn').disabled = true;
  const texto = $('#textoInput').value.trim().slice(0, MAX), intensidad = valInt();
  if(editandoId){
    const r = registros.find((x) => x.id === editandoId);
    if(r){ r.mood = mood; r.intensidad = intensidad; r.texto = texto; r.editado = new Date().toISOString(); }
    const ok = guardar(); salirEdicion(); actualizarTodo();
    showToast(ok ? 'Cambios guardados.' : 'Cambios aplicados solo en esta página: no se pudieron guardar en el navegador.');
    location.hash = 'historial';
  }else{
    const reg = {id: uid(), fecha: new Date().toISOString(), mood, intensidad, texto};
    registros.push(reg); borrarBorrador(); const ok = guardar(); actualizarTodo();
    const b = $('#saveBtn').getBoundingClientRect(); lanzarParticulas(b.left + b.width / 2, b.top);
    showToast(ok ? 'Tu voz fue escuchada. Tu registro ha sido guardado.' : 'Registro guardado solo en esta página: no se pudo guardar en el navegador.');
    setForm('', 3, ''); mostrarExito(reg);
  }
  setTimeout(() => { guardando = false; $('#saveBtn').disabled = false; }, 700);
});

/* ---------- Historial: búsqueda, filtros, edición y borrado ---------- */
const filtro = {q: '', mood: '', int: '', desde: '', hasta: '', orden: 'desc'};
let tFiltro = null;
Object.keys(MOODS).forEach((k) => $('#fmood').append(el('option', null, MOODS[k].emoji + ' ' + MOODS[k].nombre, {value: k})));
function filtrados(){
  const f = filtro, q = norm(f.q.trim());
  const l = registros.filter((r) => (!q || norm(r.texto).includes(q)) && (!f.mood || r.mood === f.mood) && (!f.int || r.intensidad === +f.int) && (!f.desde || dia(r.fecha) >= f.desde) && (!f.hasta || dia(r.fecha) <= f.hasta));
  l.sort((a, b) => a.fecha.localeCompare(b.fecha));
  return f.orden === 'desc' ? l.reverse() : l;
}
function leerFiltros(){
  filtro.q = $('#fq').value; filtro.mood = $('#fmood').value; filtro.int = $('#fint').value;
  filtro.desde = $('#fdesde').value; filtro.hasta = $('#fhasta').value; filtro.orden = $('#forden').value;
  limite = PAGE; mostrarHistorial();
}
$('#filtros').addEventListener('submit', (e) => e.preventDefault());
$('#filtros').addEventListener('input', () => { clearTimeout(tFiltro); tFiltro = setTimeout(leerFiltros, 160); });
$('#filtros').addEventListener('change', () => { clearTimeout(tFiltro); leerFiltros(); });
$('#fclear').addEventListener('click', () => { $('#filtros').reset(); leerFiltros(); $('#fq').focus(); });
$('#masBtn').addEventListener('click', () => { limite += PAGE; mostrarHistorial(); $('#masBtn').focus(); });

function vacio(texto, href, btn){
  const d = el('div', 'empty-state');
  d.append(el('span', 'big', '🌱', {'aria-hidden': 'true'}), el('p', null, texto));
  if(href){ const w = el('div'); w.style.marginTop = '20px'; w.append(el('a', 'btn btn-primary', btn, {href, 'data-nav': href.slice(1)})); d.append(w); }
  return d;
}
function tarjeta(r, i){
  const m = MOODS[r.mood], c = el('article', 'reg-card'), cab = el('div', 'reg-head'), inten = el('span', 'reg-intensity');
  const cuando = formatearFechaLarga(r.fecha) + ' a las ' + hora(r.fecha);
  c.style.setProperty('--mood', m.color); c.style.animationDelay = Math.min(i * 70, 400) + 'ms';
  for(let k = 1; k <= 5; k++) inten.append(el('span', 'dot' + (k <= r.intensidad ? ' on' : '')));
  inten.append(el('span', 'int-txt', 'Intensidad ' + r.intensidad + ' de 5'));
  cab.append(el('span', 'reg-emoji', m.emoji, {'aria-hidden': 'true'}), el('span', 'reg-mood', m.nombre), inten,
    el('span', 'reg-date', formatearFechaLarga(r.fecha) + ' · ' + hora(r.fecha) + (r.editado ? ' · editado' : '')));
  const t = el('p', 'reg-text', r.texto || '(Sin texto, solo la emoción del día.)');
  c.append(cab, t);
  if(r.texto.length > 200){
    t.classList.add('clamp');
    const b = el('button', 'mini-btn', 'Leer más', {type: 'button', 'aria-expanded': 'false'});
    b.addEventListener('click', () => { const corto = t.classList.toggle('clamp'); b.textContent = corto ? 'Leer más' : 'Leer menos'; b.setAttribute('aria-expanded', String(!corto)); });
    c.append(b);
  }
  const act = el('div', 'reg-actions'), ed = el('button', 'mini-btn', '✏️ Editar', {type: 'button', 'aria-label': 'Editar el registro del ' + cuando}),
    del = el('button', 'mini-btn del', '🗑️ Eliminar', {type: 'button', 'aria-label': 'Eliminar el registro del ' + cuando});
  ed.addEventListener('click', () => editar(r.id)); del.addEventListener('click', () => eliminar(r.id));
  act.append(ed, del); c.append(act); return c;
}
function mostrarHistorial(){
  const lista = $('#listaHistorial'), info = $('#historialCount'), n = registros.length;
  lista.replaceChildren(); $('#masWrap').hidden = true;
  if(!n){
    info.textContent = ''; $('#filtros').hidden = true;
    lista.append(vacio('Todavía no tienes registros. Cuando estés listo, puedes comenzar a escribir cómo te sientes.', '#registrar', 'Hacer mi primer registro'));
    return;
  }
  $('#filtros').hidden = false;
  const l = filtrados();
  info.textContent = (l.length === n ? 'Tienes ' + n + (n === 1 ? ' registro' : ' registros') + ' en este navegador.' : 'Mostrando ' + l.length + ' de ' + n + ' registros.') + (filtro.orden === 'desc' ? ' Los más recientes aparecen primero.' : ' Los más antiguos aparecen primero.');
  if(!l.length){ lista.append(vacio('No encontramos registros con esa búsqueda o esos filtros. Prueba con otras palabras o limpia los filtros.')); return; }
  l.slice(0, limite).forEach((r, i) => lista.append(tarjeta(r, i)));
  if(l.length > limite){ $('#masWrap').hidden = false; $('#masBtn').textContent = 'Mostrar más (' + (l.length - limite) + ' restantes)'; }
}
async function eliminar(id){
  const r = registros.find((x) => x.id === id); if(!r) return;
  if(!await confirmar({icono:'🗑️', titulo:'¿Eliminar este registro?', texto:'Se borrará el registro de «' + MOODS[r.mood].nombre + '» del ' + formatearFechaLarga(r.fecha) + '. Esta acción no se puede deshacer.', si:'Sí, eliminar', no:'Cancelar', peligro:true})) return;
  registros = registros.filter((x) => x.id !== id);
  if(editandoId === id) salirEdicion();
  guardar(); actualizarTodo(); showToast('Registro eliminado. Tu espacio, tus reglas.');
}

/* ---------- Estadísticas ---------- */
function actualizarEstadisticas(){
  const n = registros.length, dias = new Set(registros.map((r) => dia(r.fecha))).size;
  $('#statDias').textContent = dias;
  $('#defDias').textContent = 'Días distintos con al menos un registro. En total: ' + n + (n === 1 ? ' registro.' : ' registros.');
  if(!n){ $('#statFrecuente').textContent = '—'; $('#statPromedio').textContent = '—'; $('#defFrecuente').textContent = 'Aparecerá cuando tengas registros.'; return; }
  const c = {}, ult = {};
  registros.forEach((r) => { c[r.mood] = (c[r.mood] || 0) + 1; ult[r.mood] = Math.max(ult[r.mood] || 0, +new Date(r.fecha)); });
  const top = Object.keys(c).sort((a, b) => c[b] - c[a] || ult[b] - ult[a])[0];
  $('#statFrecuente').textContent = MOODS[top].emoji + ' ' + MOODS[top].nombre;
  $('#defFrecuente').textContent = 'La que más anotaste: ' + c[top] + ' de ' + n + (n === 1 ? ' registro.' : ' registros.');
  $('#statPromedio').textContent = (registros.reduce((s, r) => s + r.intensidad, 0) / n).toFixed(1).replace('.', ',');
}
const etiquetaPunto = (r) => formatearFechaCorta(r.fecha) + ' ' + hora(r.fecha) + ' · ' + MOODS[r.mood].nombre + ' · intensidad ' + r.intensidad + ' de 5';
function tablaGrafica(d, total){
  const det = el('details'), tb = el('table'), h = el('tr');
  det.append(el('summary', null, 'Ver estos datos como tabla'));
  if(total > d.length) det.append(el('p', 'sub', 'Se muestran los últimos ' + d.length + ' de ' + total + ' registros.'));
  tb.append(el('caption', 'sr-only', 'Fecha, emoción e intensidad de los registros de la gráfica'));
  ['Fecha', 'Emoción', 'Intensidad (1 a 5)'].forEach((x) => h.append(el('th', null, x, {scope: 'col'})));
  tb.append(h);
  d.forEach((r) => { const tr = el('tr'); tr.append(el('td', null, formatearFechaCorta(r.fecha) + ' · ' + hora(r.fecha)), el('td', null, MOODS[r.mood].emoji + ' ' + MOODS[r.mood].nombre), el('td', null, String(r.intensidad))); tb.append(tr); });
  const w = el('div', 'table-wrap'); w.append(tb); det.append(w); $('#chartTable').replaceChildren(det);
}
/* ---------- Gráfica emocional (SVG propio, sin librerías) ---------- */
function actualizarGrafica(){
  const box = $('#chartBox');
  const empty = $('#chartEmpty');
  const distWrap = $('#distWrap');
  box.innerHTML = ''; $('#chartTable').replaceChildren();

  if(registros.length === 0){
    empty.hidden = false;
    distWrap.style.display = 'none';
    return;
  }
  empty.hidden = true;
  distWrap.style.display = '';

  const todos = [...registros].sort((a,b)=> a.fecha.localeCompare(b.fecha));
  const datos = todos.slice(-60);
  const W = 680, H = 300, L = 40, R = 18, T = 18, B = 44;
  const innerW = W - L - R, innerH = H - T - B;
  const n = datos.length;
  const x = (i)=> n === 1 ? L + innerW/2 : L + i * (innerW/(n-1));
  const y = (v)=> T + (5 - v) * (innerH/4);

  const svgNS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(svgNS,'svg');
  svg.setAttribute('viewBox', '0 0 ' + W + ' ' + H);
  svg.setAttribute('role','group');
  svg.setAttribute('aria-label','Gráfica de intensidad emocional por fecha');

  // Líneas de rejilla (intensidad 1..5)
  for(let v=1; v<=5; v++){
    const line = document.createElementNS(svgNS,'line');
    line.setAttribute('x1', L); line.setAttribute('x2', W-R);
    line.setAttribute('y1', y(v)); line.setAttribute('y2', y(v));
    line.setAttribute('class','chart-grid');
    svg.appendChild(line);
    const lbl = document.createElementNS(svgNS,'text');
    lbl.setAttribute('x', L-12); lbl.setAttribute('y', y(v)+4);
    lbl.setAttribute('class','chart-grid-lbl');
    lbl.setAttribute('text-anchor','end');
    lbl.textContent = v;
    svg.appendChild(lbl);
  }

  // Puntos
  const pts = datos.map((r,i)=> ({px:x(i), py:y(r.intensidad), r}));

  // Línea suave (curvas cuadráticas por puntos medios)
  if(n > 1){
    let d = 'M ' + pts[0].px + ' ' + pts[0].py;
    for(let i=1;i<n-1;i++){
      const mx = (pts[i].px + pts[i+1].px)/2, my = (pts[i].py + pts[i+1].py)/2;
      d += ' Q ' + pts[i].px + ' ' + pts[i].py + ' ' + mx + ' ' + my;
    }
    d += ' L ' + pts[n-1].px + ' ' + pts[n-1].py;
    const path = document.createElementNS(svgNS,'path');
    path.setAttribute('d', d);
    path.setAttribute('class','chart-line');
    svg.appendChild(path);
    // Animación de trazo
    if(!reduceMotion){
      const len = path.getTotalLength();
      path.style.strokeDasharray = len;
      path.style.strokeDashoffset = len;
      requestAnimationFrame(()=>{
        path.style.transition = 'stroke-dashoffset 1.4s ease';
        path.style.strokeDashoffset = '0';
      });
    }
  }

  // Puntos coloreados por emoción, con tooltip accesible
  pts.forEach(p=>{
    const c = document.createElementNS(svgNS,'circle');
    c.setAttribute('cx', p.px); c.setAttribute('cy', p.py); c.setAttribute('r', 7);
    c.setAttribute('class','chart-dot'); c.setAttribute('tabindex','0'); c.setAttribute('role','img'); c.setAttribute('aria-label', etiquetaPunto(p.r));
    c.setAttribute('fill', (MOODS[p.r.mood] || {color:'#999'}).color);
    const t = document.createElementNS(svgNS,'title');
    t.textContent = etiquetaPunto(p.r);
    c.appendChild(t);
    svg.appendChild(c);
  });

  // Etiquetas de fecha en el eje X (máximo 6)
  const paso = Math.max(1, Math.ceil(n/6));
  datos.forEach((r,i)=>{
    if(i % paso === 0 || i === n-1){
      const t = document.createElementNS(svgNS,'text');
      t.setAttribute('x', x(i)); t.setAttribute('y', H-14);
      t.setAttribute('class','chart-grid-lbl');
      t.setAttribute('text-anchor','middle');
      t.textContent = formatearFechaCorta(r.fecha);
      svg.appendChild(t);
    }
  });

  box.appendChild(svg);
  tablaGrafica(datos, todos.length);

  // Barra de distribución de emociones
  const bar = $('#distBar'), legend = $('#distLegend');
  bar.innerHTML = ''; legend.innerHTML = '';
  const conteo = {};
  registros.forEach(r=>{ conteo[r.mood] = (conteo[r.mood] || 0) + 1; });
  Object.keys(MOODS).forEach(k=>{
    const c = conteo[k];
    if(!c) return;
    const pct = (c / registros.length) * 100;
    const seg = document.createElement('div');
    seg.style.width = pct + '%';
    seg.style.background = MOODS[k].color;
    seg.title = MOODS[k].nombre + ': ' + c;
    bar.appendChild(seg);
    const chip = document.createElement('span');
    const dot = document.createElement('i'); dot.style.background = MOODS[k].color;
    chip.appendChild(dot);
    chip.appendChild(document.createTextNode(MOODS[k].emoji + ' ' + MOODS[k].nombre + ' · ' + c + ' (' + Math.round(pct) + '%)'));
    legend.appendChild(chip);
  });
}

function actualizarMensajePerfil(){
  const m = mensajeHistorial(); $('#msgPerfil').style.display = m ? '' : 'none';
  if(m) $('#msgPerfilTexto').textContent = '“' + m + '”';
}
function actualizarHeroCount(){
  const e = $('#heroCount'), n = registros.length; e.hidden = !n;
  if(n) e.textContent = '💜 Llevas ' + n + (n === 1 ? ' emoción guardada' : ' emociones guardadas') + ' en este navegador';
}
function actualizarTodo(){ mostrarHistorial(); actualizarEstadisticas(); actualizarGrafica(); actualizarMensajePerfil(); actualizarHeroCount(); }

/* ---------- Mis datos: copia, importación y borrado total ---------- */
$('#btnExport').addEventListener('click', () => {
  if(!registros.length){ showToast('Aún no hay registros para descargar.'); return; }
  const blob = new Blob([JSON.stringify({app: 'UNMUTE', version: 1, exportado: new Date().toISOString(), registros}, null, 2)], {type: 'application/json'});
  const a = el('a', null, null, {href: URL.createObjectURL(blob), download: 'unmute-copia-' + dia(new Date().toISOString()) + '.json'});
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1500);
  showToast('Copia descargada. Guárdala en un lugar seguro.');
});
$('#btnImport').addEventListener('click', () => $('#fileImport').click());
$('#fileImport').addEventListener('change', async (e) => {
  const f = e.target.files[0]; e.target.value = ''; if(!f) return;
  let arr = null;
  try{
    if(f.size > 5e6) throw new Error('grande');
    const j = JSON.parse(await f.text());
    arr = Array.isArray(j) ? j : (j && j.app === 'UNMUTE' && Array.isArray(j.registros) ? j.registros : null);
  }catch(x){ arr = null; }
  if(!arr){ showToast('Ese archivo no es una copia válida de UNMUTE. No se cambió nada.'); return; }
  const ids = new Set(registros.map((r) => r.id)), fs = new Set(registros.map(firma)), nuevos = []; let dup = 0, mal = 0;
  arr.forEach((x) => {
    const r = validar(x); if(!r){ mal++; return; }
    if(ids.has(r.id) || fs.has(firma(r))){ dup++; return; }
    ids.add(r.id); fs.add(firma(r)); nuevos.push(r);
  });
  if(!nuevos.length){ showToast('No hay registros nuevos para importar. No se cambió nada.'); return; }
  if(!await confirmar({icono:'📥', titulo:'¿Importar esta copia?', texto:'Revisa el resumen. Tus registros actuales no se borrarán.', lineas:[nuevos.length + ' registros nuevos se añadirán', dup + ' ya existen y se omitirán', mal + ' con formato inválido se omitirán'], si:'Importar', no:'Cancelar'})) return;
  registros = registros.concat(nuevos); const ok = guardar(); actualizarTodo();
  showToast(ok ? 'Importados ' + nuevos.length + ' registros.' : 'Importados solo en esta página: no se pudieron guardar en el navegador.');
});
$('#btnBorrar').addEventListener('click', async () => {
  if(!registros.length){ showToast('No hay registros que eliminar.'); return; }
  if(!await confirmar({icono:'🗑️', titulo:'¿Eliminar todos tus registros?', texto:'Se borrarán los ' + registros.length + ' registros guardados en este navegador. No se puede deshacer. Si quieres conservarlos, descarga antes una copia.', si:'Sí, eliminar todo', no:'Cancelar', peligro:true})) return;
  registros = []; borrarBorrador(); if(editandoId) salirEdicion();
  guardar(); actualizarTodo(); showToast('Todos tus registros fueron eliminados.');
});

/* ---------- Inicio ---------- */
registros = cargar(); avisar('');
restaurarBorrador(); contar(); marcar();
navegar(location.hash.replace('#', '') || 'inicio');
actualizarTodo();
