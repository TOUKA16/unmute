# UNMUTE 1.0.0 — Informe de cambios

**Versión de referencia:** UNMUTE 0.5.0  
**Nueva versión:** UNMUTE 1.0.0  
**Tipo de aplicación:** diario emocional web, con almacenamiento local en el navegador.

## 1. Resumen

UNMUTE 1.0.0 amplía la experiencia del diario emocional respecto a 0.5.0. Se fortalece la identidad visual, se mejora el formulario de registro, se amplían los filtros del historial, se incorpora una visualización gráfica del recorrido emocional y se refuerzan las herramientas para proteger, consultar y gestionar los datos almacenados localmente.

La aplicación continúa siendo una web estática de tres archivos principales: HTML, CSS y JavaScript. No incorpora backend, cuentas de usuario, base de datos remota ni inteligencia artificial.

## 2. Cambios incorporados y motivo

### 2.1. Identidad visual y página de inicio

**Se incorpora:**
- Presentación de marca más elaborada y lema «Tu voz también merece ser escuchada».
- Hero visual con ilustración, elementos flotantes y llamada principal para registrar el estado emocional.
- Cinta visual de palabras y una explicación de tres pasos: Siente, Escribe y Mírate.
- Sección visible sobre el carácter personal del diario y el almacenamiento en el navegador.
- Mejor adaptación de navegación para pantallas pequeñas, con menú desplegable.
- Estados y ayudas para navegadores sin JavaScript.

**Motivo:** presentar con mayor claridad la identidad de UNMUTE, explicar cómo se utiliza y facilitar el acceso al registro desde la pantalla inicial.

### 2.2. Registro emocional y experiencia de escritura

**Se incorpora o mejora:**
- Formulario organizado en tres pasos: selección de emoción, intensidad y texto libre.
- Intensidad inicial seleccionada en nivel 3, con descripciones de los niveles del 1 al 5.
- Indicador de caracteres y límite de 800 caracteres.
- Validación visible cuando no se selecciona una emoción.
- Guardado automático del borrador en `localStorage` y posibilidad de recuperarlo al volver a abrir la aplicación.
- Detección de cambios al editar y confirmación antes de descartar texto o limpiar el formulario.
- Mensaje de confirmación después de guardar y mensajes locales de apoyo relacionados con la emoción registrada.
- Animaciones decorativas moderadas y una indicación de respiración para ciertos registros, sin presentarla como tratamiento.

**Motivo:** reducir la pérdida accidental de lo escrito, hacer más claro el proceso de registro y ofrecer una respuesta amable después de guardar.

### 2.3. Historial y consulta de registros

**Se incorpora o amplía:**
- Búsqueda de texto.
- Filtros combinables por emoción, intensidad y rango de fechas.
- Orden ascendente o descendente por fecha.
- Presentación progresiva mediante el botón «Mostrar más», con páginas de 30 registros.
- Tarjetas de historial con fecha, emoción, intensidad y texto.
- Controles para ampliar o contraer textos extensos.
- Acciones de edición y eliminación con confirmación.
- Estados vacíos y mensajes cuando no hay resultados.

**Motivo:** facilitar la localización de registros concretos y hacer que el historial siga siendo manejable cuando crece.

### 2.4. Mi estado: estadísticas y visualización

**Se incorpora:**
- Número de días/entradas registradas.
- Emoción más frecuente.
- Promedio de intensidad.
- Gráfica SVG que representa la intensidad de los registros en el tiempo y diferencia las emociones mediante color.
- Distribución de frecuencia de las emociones.
- Tabla alternativa con los datos de la gráfica para facilitar su consulta.
- Mensajes de apoyo basados en el historial local.
- Aclaración de que los indicadores describen únicamente los registros y no constituyen un diagnóstico.

**Motivo:** ofrecer una lectura sencilla del historial sin convertir las estadísticas en una evaluación clínica ni en una predicción sobre la persona.

### 2.5. Datos, importación y exportación

**Se incorpora o mejora:**
- Sección «Mis datos y privacidad» con explicación de qué se almacena, dónde y cuáles son los límites del almacenamiento local.
- Exportación de registros a un archivo JSON.
- Importación de copias JSON con validación de estructura y tamaño.
- Detección de identificadores o registros duplicados.
- Resumen de registros nuevos, duplicados e inválidos antes de confirmar la importación.
- Eliminación de todos los registros con confirmación previa.
- Manejo de errores cuando `localStorage` está bloqueado o no tiene espacio.
- Respaldo local del contenido original cuando se detecta información guardada con formato inesperado.

**Motivo:** dar a la persona mayor control sobre sus registros y reducir el riesgo de pérdida accidental o importación de información inválida.

### 2.6. Accesibilidad y experiencia de uso

**Se incorpora o mejora:**
- Navegación semántica y etiquetas accesibles.
- Estados anunciados mediante `aria-live` y mensajes de error identificables.
- Gestión del foco al cambiar de vista y al cerrar diálogos.
- Diálogo reutilizable con controles de teclado y confirmación/cancelación.
- Navegación responsive y menú móvil.
- Respeto a `prefers-reduced-motion` para reducir animaciones.
- Alternativa tabular para los datos presentados en la gráfica.

**Motivo:** mejorar la orientación, la comprensión de los controles y el uso desde diferentes dispositivos y con teclado.

## 3. Archivos principales

| Archivo | Responsabilidad |
|---|---|
| `index.html` | Estructura de Inicio, Registro, Historial, Mi estado y Mis datos. |
| `css/styles.css` | Identidad visual, componentes, animaciones y diseño responsive. |
| `js/app.js` | Navegación, registros, borradores, validación, historial, estadísticas, gráfica y copias JSON. |
| `VERSION.txt` | Identificación de la versión. |
| `INFORME_CAMBIOS.md` | Registro de cambios y límites funcionales. |
| `README.md` | Instrucciones de ejecución y estructura. |

## 4. Almacenamiento y privacidad

- Los registros y borradores se guardan en `localStorage` del navegador.
- El diario no requiere cuentas ni envía automáticamente sus entradas a un servidor.
- El almacenamiento local no está cifrado. Otra persona con acceso al mismo perfil del navegador podría acceder a los datos.
- La exportación genera un archivo JSON que la persona debe guardar de forma segura.
- La descarga de tipografías o ilustraciones desde servicios externos no incluye los registros del diario.
- La aplicación no incorpora sincronización remota, autenticación, backend ni IA en esta versión.

## 5. Compatibilidad con los datos de UNMUTE 0.5.0

La versión 1.0.0 utiliza nombres de campos diferentes para representar cada registro. La versión 0.5.0 guarda propiedades como `date`, `intensity` y `note`; esta versión utiliza `fecha`, `intensidad` y `texto`.

Aunque ambas versiones utilizan claves de almacenamiento con el mismo nombre, **los registros guardados directamente por 0.5.0 no se convierten automáticamente al nuevo formato**. Cuando se detectan registros incompatibles, esta versión intenta conservar el contenido original mediante una copia local de respaldo y muestra un aviso. La importación de archivos JSON de 0.5.0 tampoco está garantizada por el importador actual.

Antes de actualizar una instalación que ya contenga registros de 0.5.0, se recomienda exportar una copia y conservarla. La migración automática entre ambos formatos queda como mejora pendiente.

## 6. Alcance y límites

Esta versión funciona como aplicación web estática. No incluye:
- Backend ni API propia.
- Cuentas, autenticación o panel administrativo.
- Base de datos remota o sincronización entre dispositivos.
- Chatbot ni integración con OpenAI.
- Diagnóstico, tratamiento ni seguimiento clínico.

## 7. Cómo ejecutar

1. Descomprimir el paquete.
2. Abrir `index.html` en un navegador moderno.
3. Para comprobar el funcionamiento de almacenamiento, permitir `localStorage` en el navegador.
4. Los datos permanecen en el navegador y dispositivo donde se utiliza la aplicación.

No requiere instalación de dependencias ni credenciales de servidor.

## 8. Comprobaciones realizadas para esta entrega

- Comparación de los tres archivos de aplicación frente a la base 0.5.0.
- Comprobación de sintaxis JavaScript con `node --check`.
- Comprobación estática de identificadores HTML duplicados.
- Comprobación estática de referencias locales a CSS y JavaScript.
- Comprobación de integridad del ZIP generado.

No se declara una prueba visual completa en navegador, una auditoría certificada de accesibilidad ni una prueba con lectores de pantalla.
