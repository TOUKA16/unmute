# UNMUTE 1.0.0

**Tu voz también merece ser escuchada.**

Diario emocional personal para registrar emociones, escribir reflexiones y consultar el propio historial.

## Ejecutar

Descomprime el paquete y abre `index.html` en un navegador moderno. No requiere dependencias, servidor, cuenta ni credenciales.

## Estructura

```text
UNMUTE_1_0_0/
├── index.html
├── css/
│   └── styles.css
├── js/
│   └── app.js
├── VERSION.txt
├── README.md
└── INFORME_CAMBIOS.md
```

## Funciones

- Registro de emoción, intensidad y texto opcional.
- Borrador automático local.
- Historial con búsqueda, filtros, orden y edición.
- Estadísticas y gráfica de intensidad.
- Exportación e importación JSON.
- Información de privacidad y eliminación local.

## Privacidad

Los registros se guardan en `localStorage` del navegador. Este almacenamiento no está cifrado ni sincronizado. Conserva las copias exportadas en un lugar seguro.

## Compatibilidad de datos

Consulta `INFORME_CAMBIOS.md`, sección 5, antes de abrir esta versión en un navegador que ya contenga datos de UNMUTE 0.5.0. Los formatos de registro difieren y no se migran automáticamente.
