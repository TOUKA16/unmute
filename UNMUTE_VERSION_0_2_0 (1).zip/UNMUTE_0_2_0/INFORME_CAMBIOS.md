# UNMUTE 0.2.0 — Navegación y primer formulario

## Cambios incorporados

- Se incorpora navegación entre Inicio y Registrar sin recargar la página.
- Se añade un formulario para seleccionar emoción, intensidad y escribir una nota opcional.
- Se implementan validaciones básicas y una confirmación temporal de envío.

## Por qué se incorporaron

Permitir que la persona recorra la aplicación y pruebe el registro emocional antes de incorporar almacenamiento persistente.

## Archivos principales

- `index.html`: estructura y contenido de la interfaz.
- `css/styles.css`: estilos visuales y adaptación de la interfaz.
- `js/app.js`: navegación y comportamiento de las funciones incorporadas.

## Cómo probarla

Abre `index.html` en un navegador moderno. No requiere instalación ni servicios externos.

## Alcance y límites funcionales

El formulario valida los datos y muestra una confirmación temporal. Todavía no conserva entradas ni presenta un historial persistente.

## Privacidad

No se transmiten entradas a servidores. Esta versión no incorpora backend ni cuentas.

## Comprobaciones realizadas

- Sintaxis JavaScript comprobada con `node --check`.
- No se detectaron IDs HTML duplicados.
- Se comprobaron las referencias locales a CSS y JavaScript.
- No se certificó la accesibilidad mediante una auditoría externa ni se realizó una prueba completa con lectores de pantalla.
