# UNMUTE 0.2.0

**Navegación y primer formulario**

Esta versión incorpora las funciones descritas en `INFORME_CAMBIOS.md`.

## Ejecutar

Abre `index.html` en un navegador moderno. No requiere instalación de dependencias ni credenciales.

## Estructura

```text
UNMUTE_0_2_0/
├── index.html
├── css/styles.css
├── js/app.js
├── VERSION.txt
└── INFORME_CAMBIOS.md
```

Consulta `INFORME_CAMBIOS.md` para conocer las incorporaciones, su propósito y los límites funcionales de esta versión.
