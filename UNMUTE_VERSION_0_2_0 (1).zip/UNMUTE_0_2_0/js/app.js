'use strict';
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const VIEWS=['inicio','registrar'];
function navigate(name){
 if(!VIEWS.includes(name)) return;
 $$('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+name));
 $$('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
}
document.addEventListener('click',e=>{
 const target=e.target.closest('[data-view],[data-go]');
 if(!target)return;
 navigate(target.dataset.view||target.dataset.go);
});

// El formulario solo valida y confirma temporalmente. No conserva registros.
const form=$('#entryForm');
form.addEventListener('submit',e=>{
 e.preventDefault();
 const mood=form.querySelector('[name="mood"]:checked');
 const intensity=form.querySelector('[name="intensity"]:checked');
 const status=$('#formStatus');
 if(!mood||!intensity){
  status.hidden=false; status.textContent='Selecciona una emoción y su intensidad para continuar.'; return;
 }
 status.hidden=false;
 status.textContent='Registro de prueba: '+mood.value+' · intensidad '+intensity.value+'. Todavía no se guarda un historial.';
});
form.addEventListener('reset',()=>{$('#formStatus').hidden=true;});
$('#note').addEventListener('input',()=>$('#count').textContent=$('#note').value.length+' / 800');
