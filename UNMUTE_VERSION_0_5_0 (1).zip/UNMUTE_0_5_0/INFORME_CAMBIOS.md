# UNMUTE 0.5.0 — Historial y seguimiento personal

## Cambios incorporados

- Se mejora el historial con búsqueda por texto y filtro por emoción.
- Se incorporan indicadores básicos: cantidad de registros, emoción más frecuente e intensidad promedio.
- Se añaden exportación e importación de copias JSON y eliminación de registros locales.
- Se mejoran la navegación, la presentación responsive y los mensajes de estado.

## Por qué se incorporaron

Facilitar la consulta del recorrido personal, ofrecer una lectura general de los registros y dar a la persona una forma de guardar y recuperar una copia de sus datos.

## Archivos principales

- `index.html`: estructura y contenido de la interfaz.
- `css/styles.css`: estilos visuales y adaptación de la interfaz.
- `js/app.js`: navegación y comportamiento de las funciones incorporadas.

## Cómo probarla

Abre `index.html` en un navegador moderno. No requiere instalación ni servicios externos.

## Alcance y límites funcionales

Incluye búsqueda, filtro por emoción, indicadores y copias JSON básicas. La versión siguiente amplía validaciones, filtros, visualización gráfica y controles de accesibilidad.

## Privacidad

Las entradas siguen almacenándose localmente. La exportación crea una copia para que la persona la conserve; la importación restaura registros en el navegador.

## Comprobaciones realizadas

- Sintaxis JavaScript comprobada con `node --check`.
- No se detectaron IDs HTML duplicados.
- Se comprobaron las referencias locales a CSS y JavaScript.
- No se certificó la accesibilidad mediante una auditoría externa ni se realizó una prueba completa con lectores de pantalla.
