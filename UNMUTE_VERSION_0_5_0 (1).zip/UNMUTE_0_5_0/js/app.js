'use strict';
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const VIEWS=['inicio','registrar', 'historial', 'estado','datos'];
function navigate(name){
 if(!VIEWS.includes(name)) return;
 $$('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+name));
 $$('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
}
document.addEventListener('click',e=>{
 const target=e.target.closest('[data-view],[data-go]');
 if(!target)return;
 navigate(target.dataset.view||target.dataset.go);
});

const form=$('#entryForm'), list=$('#entries');
const KEY='unmute_registros_v1', DRAFT='unmute_borrador_v1';
let entries=[], editing=null;
const moodNames={muyfeliz:'Muy feliz',feliz:'Feliz',neutral:'Neutral',triste:'Triste',mal:'Mal',enojado:'Enojado',ansioso:'Ansioso',cansado:'Cansado'};
const getMood=()=>form.querySelector('[name="mood"]:checked')?.value||'';
const getIntensity=()=>form.querySelector('[name="intensity"]:checked')?.value||'';
const announce=msg=>{const s=$('#formStatus');s.hidden=false;s.textContent=msg;};
const escDate=iso=>new Intl.DateTimeFormat('es',{dateStyle:'medium',timeStyle:'short'}).format(new Date(iso));
function saveLocal(){
 try{localStorage.setItem(KEY,JSON.stringify(entries));return true;}catch(e){announce('No se pudo guardar en este navegador. Descarga una copia si está disponible.');return false;}
}
function loadLocal(){
 try{const parsed=JSON.parse(localStorage.getItem(KEY)||'[]');return Array.isArray(parsed)?parsed.filter(x=>x&&x.id&&moodNames[x.mood]&&Number(x.intensity)>=1&&Number(x.intensity)<=5):[];}catch(e){return [];}
}

function render(){
 list.replaceChildren();
 if(!entries.length){list.textContent='Aún no tienes registros. Puedes comenzar desde Registrar.';return;}
 entries.slice().reverse().forEach(item=>{
  const card=document.createElement('article');card.className='entry';
  const head=document.createElement('div');head.className='entry-head';
  const title=document.createElement('strong');title.textContent=(moodNames[item.mood]||item.mood)+' · Intensidad '+item.intensity+'/5';
  const date=document.createElement('time');date.dateTime=item.date;date.textContent=escDate(item.date);
  head.append(title,date);card.append(head);
  const note=document.createElement('p');note.textContent=item.note||'Sin nota escrita.';card.append(note);
  const actions=document.createElement('div');actions.className='entry-actions';
  const del=document.createElement('button');del.type='button';del.textContent='Eliminar';del.addEventListener('click',()=>removeEntry(item.id));actions.append(del);

  const edit=document.createElement('button');edit.type='button';edit.textContent='Editar';edit.addEventListener('click',()=>editEntry(item.id));actions.append(edit);

  card.append(actions);list.append(card);
 });
}
function removeEntry(id){
 if(!confirm('¿Eliminar este registro?'))return;
 entries=entries.filter(x=>x.id!==id);saveLocal();render();
}

function editEntry(id){
 const item=entries.find(x=>x.id===id);if(!item)return;
 editing=id;
 form.querySelector('[name="mood"][value="'+item.mood+'"]').checked=true;
 form.querySelector('[name="intensity"][value="'+item.intensity+'"]').checked=true;
 $('#note').value=item.note||'';$('#count').textContent=$('#note').value.length+' / 800';
 $('#saveBtn').textContent='Guardar cambios';navigate('registrar');$('#note').focus();
}
function restoreDraft(){
 try{
  const d=JSON.parse(localStorage.getItem(DRAFT)||'null');
  if(d&&d.note&&!editing){$('#note').value=d.note;$('#count').textContent=d.note.length+' / 800';}
 }catch(e){}
}
$('#note').addEventListener('input',()=>{
 $('#count').textContent=$('#note').value.length+' / 800';
 try{localStorage.setItem(DRAFT,JSON.stringify({note:$('#note').value,updatedAt:new Date().toISOString()}));}catch(e){}
});

form.addEventListener('submit',e=>{
 e.preventDefault();
 const mood=getMood(), intensity=getIntensity(), note=$('#note').value.trim();
 if(!mood||!intensity){announce('Selecciona una emoción y una intensidad.');return;}
 const item={id:editing||((crypto.randomUUID&&crypto.randomUUID())||String(Date.now())),date:new Date().toISOString(),mood,intensity:Number(intensity),note};
 if(editing){const i=entries.findIndex(x=>x.id===editing);if(i>=0)entries[i]=item;editing=null;}
 else entries.push(item);
 if(saveLocal()){
  form.reset();$('#note').value='';$('#count').textContent='0 / 800';$('#saveBtn').textContent='Guardar registro';
  try{localStorage.removeItem(DRAFT);}catch(e){}
  announce('Tu registro se guardó en esta etapa.');render();
  if(VIEWS.includes('historial'))navigate('historial');
 }
});
form.addEventListener('reset',()=>{editing=null; if($('#saveBtn'))$('#saveBtn').textContent='Guardar registro';});
$('#note').addEventListener('input',()=>$('#count').textContent=$('#note').value.length+' / 800');

restoreDraft();
$('#btnCancelEdit')?.addEventListener('click',()=>{editing=null;form.reset();$('#note').value='';$('#saveBtn').textContent='Guardar registro';});


const search=$('#search'), filter=$('#filterMood');
function renderFiltered(){
 const q=(search.value||'').toLocaleLowerCase();
 const m=filter.value;
 list.replaceChildren();
 const filtered=entries.filter(x=>(!m||x.mood===m)&&(!q||(x.note||'').toLocaleLowerCase().includes(q))).slice().reverse();
 if(!filtered.length){list.textContent='No hay registros que coincidan con la búsqueda.';return;}
 filtered.forEach(item=>{
  const card=document.createElement('article');card.className='entry';
  const head=document.createElement('div');head.className='entry-head';
  const title=document.createElement('strong');title.textContent=moodNames[item.mood]+' · Intensidad '+item.intensity+'/5';
  const date=document.createElement('time');date.dateTime=item.date;date.textContent=escDate(item.date);
  head.append(title,date);card.append(head);
  const note=document.createElement('p');note.textContent=item.note||'Sin nota escrita.';card.append(note);
  const actions=document.createElement('div');actions.className='entry-actions';
  const edit=document.createElement('button');edit.type='button';edit.textContent='Editar';edit.addEventListener('click',()=>editEntry(item.id));
  const del=document.createElement('button');del.type='button';del.textContent='Eliminar';del.addEventListener('click',()=>removeEntry(item.id));
  actions.append(edit,del);card.append(actions);list.append(card);
 });
}
function updateStats(){
 $('#total').textContent=entries.length;
 const counts={};entries.forEach(x=>counts[x.mood]=(counts[x.mood]||0)+1);
 const leader=Object.entries(counts).sort((a,b)=>b[1]-a[1])[0];
 $('#common').textContent=leader?moodNames[leader[0]]:'—';
 const avg=entries.length?entries.reduce((a,x)=>a+Number(x.intensity),0)/entries.length:0;
 $('#average').textContent=entries.length?avg.toFixed(1)+'/5':'—';
 const box=$('#moodStats');box.replaceChildren();
 Object.entries(moodNames).forEach(([key,name])=>{
  const count=counts[key]||0;if(!count)return;
  const row=document.createElement('p');row.textContent=name+': '+count+' registro(s)';box.append(row);
 });
}
function refresh(){renderFiltered();updateStats();}
search.addEventListener('input',refresh);filter.addEventListener('change',refresh);
$('#export').addEventListener('click',()=>{
 const blob=new Blob([JSON.stringify({version:1,entries},null,2)],{type:'application/json'});
 const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download='unmute-copia.json';a.click();URL.revokeObjectURL(url);$('#dataStatus').textContent='Copia descargada.';
});
$('#import').addEventListener('click',()=>$('#fileImport').click());
$('#fileImport').addEventListener('change',async e=>{
 const file=e.target.files[0];if(!file)return;
 try{const data=JSON.parse(await file.text());const incoming=Array.isArray(data)?data:data.entries;
  if(!Array.isArray(incoming))throw new Error('Formato inválido');
  const ids=new Set(entries.map(x=>x.id));incoming.forEach(x=>{if(!x||typeof x.id!=='string'||!x.id||!moodNames[x.mood]||!Number.isInteger(Number(x.intensity))||Number(x.intensity)<1||Number(x.intensity)>5||!x.date||Number.isNaN(new Date(x.date).getTime())||typeof x.note!=='string'||ids.has(x.id))return;entries.push({id:x.id,date:new Date(x.date).toISOString(),mood:x.mood,intensity:Number(x.intensity),note:x.note.slice(0,800)});ids.add(x.id);});
  saveLocal();refresh();$('#dataStatus').textContent='Copia importada.'; 
 }catch(err){$('#dataStatus').textContent='No se pudo importar: revisa el archivo.';}
 e.target.value='';
});
$('#deleteAll').addEventListener('click',()=>{
 if(!confirm('¿Eliminar todos tus registros de este navegador?'))return;
 entries=[];saveLocal();refresh();$('#dataStatus').textContent='Se eliminaron los registros locales.';
});

if(VIEWS.includes('historial'))render();

entries=loadLocal();refresh();
