# UNMUTE 0.4.0 — Persistencia local y edición

## Cambios incorporados

- Los registros se guardan en `localStorage` y permanecen disponibles al volver a abrir la aplicación en el mismo navegador.
- Se incorpora el guardado de borradores mientras se escribe.
- Se añaden las opciones de editar y eliminar registros.
- Se informa que los datos se almacenan localmente y que el almacenamiento del navegador no está cifrado.

## Por qué se incorporaron

Dar continuidad al diario y permitir que la persona administre sus entradas sin depender de un servidor ni enviar sus experiencias personales a terceros.

## Archivos principales

- `index.html`: estructura y contenido de la interfaz.
- `css/styles.css`: estilos visuales y adaptación de la interfaz.
- `js/app.js`: navegación y comportamiento de las funciones incorporadas.

## Cómo probarla

Abre `index.html` en un navegador moderno. No requiere instalación ni servicios externos.

## Alcance y límites funcionales

La versión incorpora almacenamiento local, borradores y operaciones básicas de creación, edición y eliminación. Todavía no incluye búsqueda avanzada, indicadores ni copias JSON.

## Privacidad

Las entradas permanecen en el navegador. No hay backend, cuentas ni envío automático a servicios externos. Otras personas con acceso al mismo perfil del navegador podrían acceder a los datos.

## Comprobaciones realizadas

- Sintaxis JavaScript comprobada con `node --check`.
- No se detectaron IDs HTML duplicados.
- Se comprobaron las referencias locales a CSS y JavaScript.
- No se certificó la accesibilidad mediante una auditoría externa ni se realizó una prueba completa con lectores de pantalla.
