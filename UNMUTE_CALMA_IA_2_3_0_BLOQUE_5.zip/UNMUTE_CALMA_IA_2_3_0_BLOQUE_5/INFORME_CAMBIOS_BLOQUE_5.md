# UNMUTE 2.3.0 — Informe de cambios del Bloque 5
## Necesito ayuda + Contacto con seguimiento

**Versión de partida:** 2.2.0 — Bloque 4.  
**Versión actualizada:** 2.3.0 — Bloque 5.  
**Paquete de referencia:** `UNMUTE_BLOQUE_4.zip`.  
**Paquete actualizado:** `UNMUTE_BLOQUE_5.zip`.  
**Alcance:** vista Necesito ayuda, envío y seguimiento de Contacto, y gestión de mensajes en el panel administrativo existente.

---

## 1. Resumen

El Bloque 5 incorpora dos nuevas experiencias públicas y completa su integración administrativa:

1. **Necesito ayuda:** directorio colombiano con líneas de ayuda existentes, sus coberturas, teléfonos, fuentes y fechas de verificación; accesos a Pausa y Acompañar.
2. **Contacto:** formulario con consentimiento explícito, recepción del mensaje y referencia UUID real; consulta pública del estado.
3. **Administración:** sección de mensajes dentro del panel existente, con listado, filtros, detalle y cambio de estado.

Se conserva la navegación principal de cinco accesos, el diseño Calma orgánica, el diario local, la integración de IA y la autenticación administrativa. No se añaden tablas ni migraciones SQL.

## 2. Cambios incorporados

### 2.1. Nueva vista «Necesito ayuda»

**Archivos principales:** `public/js/help.js`, `public/index.html`, `public/js/app.js`, `public/css/styles.css`.

- Se añade la vista `#ayuda` dentro del menú Más; no se añade una sexta opción principal.
- Se muestran los recursos colombianos 123, 106, 141 y 155 leyendo `window.UNMUTE_HELP` desde el directorio existente.
- La línea 106 se identifica como Bogotá. WhatsApp solo se muestra para el recurso que ya contiene ese dato.
- Se presentan cobertura, descripción, horario, teléfono, fuente oficial y fecha de verificación cuando esos campos están disponibles.
- Los teléfonos utilizan enlaces `tel:` y WhatsApp abre el enlace externo con `noopener noreferrer`.
- Se conserva la nota para consultar la Secretaría de Salud o el sitio oficial de la alcaldía cuando se necesite un recurso local.
- Se evita geolocalización, IP, consultas de red, almacenamiento local y acceso al diario.
- Si un recurso no tiene los datos mínimos válidos, se omite sin ocultar los demás. Si el directorio no está disponible, se muestra un mensaje y no se inventan números.
- Se incorporan accesos a Pausa y Acompañar, con avisos que explican que la IA no es una profesional ni un servicio de emergencias y que no garantiza detectar crisis.

**Motivo:** ofrecer acceso claro a ayuda humana y recursos colombianos sin recopilar ubicación ni duplicar las actividades existentes.

### 2.2. Formulario público de Contacto

**Archivos principales:** `public/js/contact.js`, `public/index.html`, `public/css/styles.css`, `netlify/functions/contact.mjs`, `src/services/contact.service.mjs`.

- Se añade la vista `#contacto` dentro de Más.
- Campos: nombre y correo opcionales; categoría obligatoria (`consulta`, `sugerencia`, `reporte_tecnico`, `otro`); mensaje obligatorio de 10 a 2000 caracteres; consentimiento obligatorio y desmarcado por defecto.
- El formulario explica qué datos se envían, la finalidad y que no es un canal de emergencias.
- Se conserva el honeypot antispam y el tiempo de llenado.
- Se bloquean envíos simultáneos y no se realizan reintentos automáticos.
- Los errores se asocian con los campos mediante `aria-describedby` y `aria-invalid`; el texto se conserva ante un error.
- La interfaz confirma la recepción únicamente si el servidor devuelve HTTP 201, `saved: true` y un UUID válido.
- La referencia se puede copiar y sirve para abrir la consulta de seguimiento.
- La referencia no se guarda en `localStorage` ni en `sessionStorage`.
- Si se activa el honeypot, la API responde sin guardar el mensaje y sin producir una referencia falsa. La interfaz no afirma que el mensaje fue guardado.

**Motivo:** permitir que las personas contacten al equipo sin generar confirmaciones falsas ni recolectar información innecesaria.

### 2.3. Referencia real y respuesta del backend

**Archivos principales:** `src/services/contact.service.mjs` y `netlify/functions/contact.mjs`.

- `crearMensaje()` utiliza `Prefer: return=representation` para recibir la fila insertada.
- El servicio devuelve solo el ID y la fecha de creación.
- Si Supabase no confirma una fila con UUID válido, se devuelve un error 502 `insert_not_confirmed`.
- `POST /api/contact` devuelve `reference` y `received_at` solo cuando la inserción se confirmó.
- El consentimiento se sigue validando en el servidor. No se almacena un registro independiente de aceptación, porque el esquema actual no tiene esa columna y no se añadió una migración.

**Motivo:** garantizar que la referencia que ve la persona corresponde a un mensaje realmente guardado.

### 2.4. Endpoint público de seguimiento

**Archivo nuevo:** `netlify/functions/contact-status.mjs`.  
**Ruta:** `GET /api/contact/status?reference=UUID`.

- Valida el formato del UUID.
- Aplica rate limit persistente en Supabase usando el scope `contacto-estado` y `CONTACT_STATUS_LIMIT_PER_HOUR` (por defecto 30 por hora).
- Consulta solo `status` y `created_at` usando la clave de servicio.
- Construye la respuesta campo por campo: `status`, `label` y `received_at`.
- Traduce los estados sin cambiar sus valores internos: `new` → Recibido; `read` → En revisión; `resolved` → Respondido; `archived` → Cerrado.
- Un UUID inexistente o con estado desconocido devuelve 404 genérico.
- La función acepta solo GET, no permite modificar datos y evita registrar el UUID o el mensaje en logs.

**Privacidad:** conocer la referencia no permite consultar el mensaje, nombre, correo, categoría ni datos administrativos.

**Motivo:** permitir que la persona consulte el avance de su solicitud sin crear acceso público al contenido del mensaje.

### 2.5. Administración de mensajes

**Archivos principales:** `public/admin.html`, `public/js/admin.js`, `public/css/admin.css`.

- Se añade la sección **Mensajes de contacto** al panel administrativo existente.
- Permite listar y filtrar por estado, consultar el detalle del mensaje y cambiar el estado.
- Reutiliza `GET /api/admin/messages` y `PATCH /api/admin/messages/:id`.
- Mantiene los valores internos y presenta etiquetas en español: Recibido, En revisión, Respondido y Cerrado.
- Se muestran los datos proporcionados por la persona, incluida la fecha, categoría, nombre y correo cuando existan.
- El contenido se representa como texto, no como HTML.
- No se añade borrado de mensajes.
- Al cerrar sesión se conserva la limpieza administrativa existente.
- La autorización continúa en el servidor mediante `requerirAdmin`; no se crea otro login ni se relajan permisos.

**Motivo:** permitir la gestión de las consultas desde el panel existente sin duplicar autenticación ni exponer los mensajes al público.

## 3. Archivos nuevos y modificados

**Nuevos:**
- `netlify/functions/contact-status.mjs`
- `public/js/help.js`
- `public/js/contact.js`
- `tests/bloque5.test.mjs`
- `CHANGELOG_BLOQUE_5.md`
- `INFORME_CAMBIOS_BLOQUE_5.md`
- `VERSION.txt`

**Modificados:**
- `netlify/functions/contact.mjs`
- `src/services/contact.service.mjs`
- `src/config/environment.mjs`
- `.env.example`
- `public/index.html`
- `public/js/app.js`
- `public/css/styles.css`
- `public/admin.html`
- `public/js/admin.js`
- `public/css/admin.css`
- `scripts/check.mjs`
- `tests/api.test.mjs`
- `tests/bloque4.test.mjs`
- `tests/helpers/mock-services.mjs`
- `package.json`
- `CHANGELOG.md`
- `README.md`

**Eliminados:** ninguno.  
**Migraciones nuevas:** ninguna.

## 4. Base de datos y privacidad

Se reutiliza la tabla `contact_messages` existente, sus estados y la función SQL persistente `consume_rate_limit`. El backend inserta y consulta la referencia con la clave de servicio; la gestión administrativa continúa autenticada y protegida por RLS.

- El diario, borradores, emociones e historial no se envían a Contacto ni a Supabase como parte de este flujo.
- La referencia no se almacena en el navegador.
- El consentimiento de Contacto es obligatorio, pero no queda registrado como una columna independiente.
- No se definió periodo de conservación ni eliminación automática de mensajes.
- No se creó un canal de crisis: Contacto no sustituye emergencias ni atención profesional.

## 5. Pruebas reproducidas en esta revisión

| Comprobación | Resultado |
|---|---:|
| `npm test` | **93/93 aprobadas** |
| `npm run check` | **45 correctas, 0 errores, 1 advertencia** |
| `npm run seed:check` | **Correcto** |
| `npm run e2e` | **No ejecutable:** falta `tests/e2e-smoke.mjs` |
| Integridad del ZIP | **Correcta** |

Las 93 pruebas automatizadas utilizan servicios simulados. Cubren la vista de ayuda, validaciones del formulario, consentimiento, confirmación con UUID real, respuestas antispam, seguimiento, rate limit, aislamiento de datos y autorización administrativa.

El check reporta una advertencia porque `package.json` declara un comando E2E cuyo archivo no está incluido. No se declara una prueba E2E ejecutada.

## 6. Validaciones y pendientes

### Comprobado por código y pruebas simuladas
- El endpoint no devuelve contenido privado a quien conoce el UUID.
- La confirmación de envío depende de una inserción realmente confirmada.
- Los recursos de ayuda proceden del directorio existente, sin geolocalización.
- El acceso administrativo reutiliza los controles de autorización.
- No se añadieron migraciones ni se modificó RLS.

### Pendiente de servicios reales
- Probar en Supabase real el flujo envío → UUID → consulta de estado → cambio de estado administrativo.
- Confirmar `return=representation` y permisos en PostgREST/Supabase desplegado.
- Comprobar el rate limit persistente para seguimiento.
- Probar funciones y rutas en Netlify desplegado.

### Pendiente de revisión visual
- Revisar las vistas Necesito ayuda y Contacto en móvil, tableta y escritorio.
- Probar foco, teclado, contraste y lectores de pantalla en dispositivos/navegadores reales.
- Crear `tests/e2e-smoke.mjs` si se desea automatizar la prueba E2E.

### Decisiones futuras del propietario
- Si desea registrar el consentimiento de Contacto, será necesario aprobar un cambio de esquema y una migración.
- Definir la política de conservación y eliminación de mensajes antes de implementarla.
- El correo es opcional y no implica una respuesta por correo; el estado «Respondido» indica que el administrador marcó `resolved`, no que exista un canal de respuesta automático.

## 7. Integración

1. Usar este paquete como base de la siguiente versión.
2. No ejecutar migraciones nuevas: el Bloque 5 no añade ninguna.
3. Si se desea ajustar el límite de seguimiento, configurar `CONTACT_STATUS_LIMIT_PER_HOUR` en Netlify con alcance Functions.
4. Desplegar en Netlify y probar manualmente las vistas `#ayuda`, `#contacto` y `/admin` → «Mensajes de contacto».
5. Verificar el ciclo completo con Supabase real antes de abrir el flujo a usuarios.

---

**UNMUTE — Tu voz también merece ser escuchada.**
