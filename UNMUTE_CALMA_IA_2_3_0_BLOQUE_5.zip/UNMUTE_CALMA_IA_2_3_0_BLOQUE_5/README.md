# UNMUTE · Calma orgánica + IA

**Versión:** 2.3.0  
**Bloque:** 5 — Necesito ayuda + Contacto con seguimiento  
**Lema:** «Tu voz también merece ser escuchada».

UNMUTE es un diario emocional digital. El diario continúa siendo privado y local al navegador; las herramientas de Pausa y Acompañar son voluntarias. Esta versión incorpora un directorio de ayuda para Colombia y un flujo de contacto con referencia de seguimiento, integrado con el panel administrativo existente.

## Novedades de la versión 2.3.0

### Necesito ayuda
- Nueva vista secundaria desde **Más**, sin añadir una sexta opción a la navegación principal.
- Muestra los recursos 123, 106 (Bogotá), 141 y 155, utilizando únicamente los datos presentes en `public/js/help-directory.js`.
- Presenta cobertura, horario, teléfono, enlace `tel:`, WhatsApp únicamente cuando está definido para el recurso, fuente oficial y fecha de verificación.
- No usa GPS, geolocalización, dirección IP ni ubicación precisa.
- Incluye accesos a Pausa y Acompañar con aclaraciones sobre el alcance de la IA y la ayuda humana.

### Contacto y seguimiento
- Nueva vista pública **Contacto**, accesible desde Más.
- Formulario con nombre y correo opcionales, categoría, mensaje y consentimiento obligatorio, desmarcado por defecto.
- Envío mediante `POST /api/contact`.
- El servidor devuelve la referencia únicamente si Supabase confirma la inserción y devuelve el UUID real.
- La interfaz permite copiar la referencia y consultar el estado con `GET /api/contact/status?reference=UUID`.
- La consulta pública devuelve solamente estado y fecha de recepción; no permite leer el mensaje ni datos personales.
- Se conserva antispam, validación, rate limit persistente y protección ante envíos simultáneos.

### Administración de mensajes
- Nueva sección **Mensajes de contacto** en el panel administrativo existente.
- Permite listar, filtrar, leer el detalle y cambiar el estado.
- Reutiliza `GET /api/admin/messages` y `PATCH /api/admin/messages/:id`.
- Conserva autenticación y autorización en el servidor.
- No incorpora borrado de mensajes.

## Arquitectura

- **Frontend:** HTML, CSS y JavaScript en `public/`.
- **Backend:** Netlify Functions en `netlify/functions/`.
- **Datos y autenticación:** Supabase / PostgreSQL / Auth / RLS.
- **IA:** OpenAI desde el backend.
- **Servicios:** `src/services/`.
- **Librerías compartidas:** `src/lib/`.
- **Configuración:** `src/config/`.
- **Migraciones:** `supabase/migrations/`.
- **Pruebas:** `tests/`.
- **Despliegue previsto:** Netlify.

El Bloque 5 reutiliza las tablas, endpoints administrativos y mecanismos de autenticación ya existentes. No añade migraciones ni cambia las políticas RLS.

## Requisitos

- Node.js 20.12 o superior.
- Proyecto Supabase con las migraciones previas aplicadas.
- Variables privadas de Supabase para las operaciones persistentes.
- Clave de OpenAI y modelo habilitado para utilizar Acompañar.
- Sitio Netlify para desplegar el frontend y las funciones.

## Desarrollo local

1. Copia `.env.example` como `.env` y configura las variables requeridas. No compartas ni subas `.env`.
2. Instala dependencias si es necesario:

```bash
npm install
```

3. Inicia el servidor:

```bash
npm start
```

4. Abre `http://localhost:3000`. El panel se encuentra en `http://localhost:3000/admin`.

También puedes utilizar:

```bash
npm run dev
```

con Netlify CLI y las variables de entorno configuradas.

## Endpoints de contacto

| Método y ruta | Función |
|---|---|
| `POST /api/contact` | Recibe y valida una consulta. Devuelve `reference` solo con inserción confirmada. |
| `GET /api/contact/status?reference=UUID` | Devuelve únicamente estado público y fecha de recepción. |
| `GET /api/admin/messages` | Lista mensajes para una sesión administrativa válida. |
| `PATCH /api/admin/messages/:id` | Actualiza el estado de un mensaje con autorización. |

Estados internos y etiquetas públicas:
- `new` → Recibido.
- `read` → En revisión.
- `resolved` → Respondido.
- `archived` → Cerrado.

El UUID no es autenticación. Conocerlo permite consultar únicamente el estado y la fecha, nunca el contenido, nombre, correo o categoría.

## Directorio de ayuda

La vista utiliza el directorio existente y mantiene Colombia como país predeterminado. No se consulta ubicación del dispositivo. Las líneas, cobertura, horario, fuente y fecha deben mantenerse actualizadas en `public/js/help-directory.js`; no se deben inventar teléfonos ni extensiones de cobertura.

El recurso de ayuda no reemplaza los servicios de emergencia ni a profesionales. Acompañar con IA no es un canal de crisis, no llama a emergencias y no garantiza detectar situaciones de peligro.

## Migraciones

El Bloque 5 no añade migraciones SQL. Reutiliza `contact_messages`, los estados existentes y la función `consume_rate_limit`. No se deben ejecutar migraciones adicionales por esta versión.

## Pruebas

```bash
npm test
npm run check
npm run seed:check
npm run e2e
```

Resultados reproducidos en esta entrega:
- `npm test`: **93/93 pruebas aprobadas**.
- `npm run check`: **45 correctas, 0 errores y 1 advertencia**.
- `npm run seed:check`: correcto.
- `npm run e2e`: no ejecutable porque falta `tests/e2e-smoke.mjs`.

Las pruebas unitarias y de API utilizan servicios simulados. No prueban PostgreSQL/RLS, PostgREST, Supabase Auth, OpenAI ni el despliegue Netlify real. El changelog del Bloque 5 registra además que el backend se ejercitó por HTTP en el servidor local y que la UI fue revisada por pruebas estáticas y DOM simulado, no mediante una revisión visual completa en navegador.

## Privacidad y límites conocidos

- El diario, borradores, emociones y etiquetas permanecen en `localStorage`; no se envían a Contacto ni a OpenAI.
- Contacto almacena en Supabase los campos necesarios para gestionar la consulta. Nombre y correo son opcionales.
- El consentimiento de Contacto se exige para el envío, pero no se almacena como registro independiente en la base de datos.
- El seguimiento público devuelve únicamente estado y fecha.
- La referencia UUID no da acceso a los datos personales.
- No se ha definido un periodo de conservación ni una eliminación automática de los mensajes.
- `localStorage` no está cifrado.
- `store: false` en Acompañar no equivale a prometer retención cero del proveedor de IA.

El endpoint de seguimiento usa `CONTACT_STATUS_LIMIT_PER_HOUR` (por defecto 30 consultas por hora) y el mecanismo persistente de Supabase. Si ese control no está disponible, la solicitud debe fallar de forma controlada.

## Publicación

El proyecto está configurado para Netlify. Configura los secretos en el entorno de Functions y despliega la versión. Antes de dar por finalizado el despliegue, prueba el ciclo completo de contacto con Supabase real: enviar, obtener UUID, consultar estado y cambiar el estado desde la administración. Revisa además la vista Necesito ayuda en móvil y escritorio.

---

**UNMUTE — Tu voz también merece ser escuchada.**
