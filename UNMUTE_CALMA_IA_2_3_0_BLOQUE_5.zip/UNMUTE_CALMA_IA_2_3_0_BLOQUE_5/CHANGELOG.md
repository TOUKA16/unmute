# CHANGELOG · UNMUTE

## [2.3.0] · Bloque 5 · Necesito ayuda + Contacto con seguimiento
Base: `UNMUTE_BLOQUE_4.zip` (2.2.0). Detalle y resultados en `CHANGELOG_BLOQUE_5.md`.
- **Necesito ayuda** (Más): líneas 123, 106 (Bogotá), 141 y 155 tomadas solo de `help-directory.js`, con cobertura, horario, teléfono (`tel:`), WhatsApp solo en la 106, fuente y fecha de verificación. Accesos a Pausa y Acompañar con sus avisos de alcance.
- **Contacto** (Más): formulario sobre `POST /api/contact` (ahora devuelve la referencia = UUID real de `contact_messages`) y consulta pública `GET /api/contact/status?reference=UUID` que solo devuelve estado público y fecha de recepción, con límite de uso persistente.
- **Administración**: nueva sección «Mensajes de contacto» en el panel existente (listar, filtrar, leer y cambiar estado) sobre los endpoints `/api/admin/messages` ya existentes.
- Sin migraciones nuevas, sin cambios de RLS/permisos y sin tocar el diario, Acompañar ni la autenticación.

## [2.2.0] · Bloque 4 · Inicio educativo, biblioteca de Recursos y navegación principal
Base: `UNMUTE_BLOQUE_3.zip` (2.1.0). Detalle y resultados en `CHANGELOG_BLOQUE_4.md`.
- **Inicio**: dos tarjetas independientes (izquierda «Un minuto para aprender», derecha «Noticias de UNMUTE»; apiladas en móvil). El dato ahora se elige **al azar** con el `offset` y el `total` que ya devuelve `GET /api/facts/today` (sin API nueva); la noticia, al azar entre las de `GET /api/news`. «Ver otro dato» y «Ver otra noticia» nunca repiten el elemento actual si hay alternativas. «Leer noticia» abre el lector existente. Cada tarjeta tiene estados propios (cargando, contenido, vacío, error + reintentar).
- **Recursos**: nueva vista pública conectada a `GET /api/resources`, con búsqueda (sin tildes ni mayúsculas), filtros por las categorías reales del catálogo, restablecer filtros y estado vacío. Los botones solo apuntan a vistas que existen; sin destino real no hay botón.
- **Navegación**: cinco accesos principales (Inicio, Diario, Acompañar, Historia, Más). «Más» abre un menú accesible con Pausa, Noticias, Recursos y Ajustes.
- Sin cambios en backend, base de datos, migraciones, diario, chat, autenticación ni administración.

## [2.1.0] · Bloque 3 · Datos curiosos y sistema de noticias
Base: `UNMUTE_BLOQUE_2.zip` (2.0.2). Detalle y resultados de pruebas en `CHANGELOG_BLOQUE_3.md`.
- **Datos curiosos (admin)**: nueva sección con listar, crear, editar, borrador, publicar/despublicar y eliminar con confirmación, sobre la tabla `resources` y los endpoints existentes (sin cambios de backend: ya validaban fuente + fecha de revisión).
- **Un minuto para aprender**: tarjeta nueva en Inicio conectada a `/api/facts/today` (título, descripción, categoría y fuente; estable durante el día).
- **Noticias**: migración `003_news.sql` (tabla `news`, RLS, fecha de publicación por trigger), `GET /api/news` y `/api/news/:slug` (solo publicadas), `/api/admin/news…` (solo administradores), pestaña «Noticias del admin» y sección pública «Noticias».
- `netlify.toml`: `img-src` admite `https:` (imagen opcional de las noticias por URL). Scripts, estilos y conexiones siguen limitados al sitio.
- Pruebas nuevas: `tests/bloque3.test.mjs`. `scripts/check.mjs` conoce las funciones, el servicio y la migración nuevos.

## [2.0.2] · Bloque 2 · Protección de recursos y recuperación del panel administrativo
Base: `unmute-bloque1-v2_0_1.zip`. Alcance: solo las tres tareas siguientes. Detalle completo en `CHANGELOG_BLOQUE_2.md`.
- **Semilla fuera de `public/`**: `public/data/resources-seed.json` → `src/data/resources-seed.json` (contenido idéntico, 18 recursos). `scripts/build-seed.mjs` lee de la nueva ruta; `002_seed_resources.sql` regenerada (solo cambia el comentario de cabecera).
- **Ruta `/admin`**: nueva `public/admin.html` (+ `public/js/admin.js`, `public/css/admin.css`) con inicio de sesión, verificación de sesión en el servidor, panel inicial y cierre de sesión. `netlify.toml`: redirección también para `/admin/` y cabeceras `noindex`/`no-store` para las tres rutas. `server.js`: `/admin/` también sirve la página en local.
- **`scripts/check.mjs`**: nueva comprobación estática (`npm run check`).
- Pruebas nuevas: `tests/admin-page.test.mjs`, `tests/check.test.mjs`.

## [2.0.1] · Bloque 1 · Reparaciones críticas del backend
Base: `unmute-calma-ia-actualizado (1).zip` (16-nov-2026). Alcance: solo las dos reparaciones siguientes.

### Reparación 1 · Consentimiento del chat con IA
- `public/js/ai-chat.js`: la petición `POST /api/chat` ahora incluye `consent: consent.checked === true`, es decir, el estado REAL de la casilla de privacidad (`#aiConsent`). Nunca se escribe `consent: true` a mano.
- Sin consentimiento no se envía nada: el botón sigue desactivado, se explica el motivo mientras la persona escribe («Marca la casilla de privacidad para habilitar el envío.») y, si aun así se intenta enviar, se muestra un mensaje claro, se lleva el foco a la casilla y se conserva el texto escrito.
- Sin cambios en: HTML, estilos, personalidad de UNMUTE IA, límite de contexto (12 mensajes / 8500 caracteres), `store: false`, ni en el almacenamiento local del diario. El servidor sigue exigiendo `consent === true` (`src/lib/validation.mjs` sin modificar).

### Reparación 2 · Límites de uso seguros para producción
- `src/lib/rate-limit.mjs` reescrito: ya no existe el respaldo silencioso en memoria.
  - Con Supabase (modo normal) se usa solo `consume_rate_limit` (atómica, compartida entre instancias).
  - Si faltan credenciales, Supabase no responde, el RPC no existe/falla o devuelve una respuesta con forma inesperada → **HTTP 503** `rate_limit_unavailable`, mensaje genérico, sin detalles internos, y la solicitud no continúa (no llega a OpenAI, no se guarda el contacto, no se intenta autenticar).
  - Parámetros de límite no válidos (0, negativos, no enteros) también se rechazan con 503 en lugar de interpretarse como «sin límite».
  - Contador en memoria: solo con `RATE_LIMIT_DEV_MEMORY=true` y solo fuera de Netlify. Se ignora (con aviso en el registro) en producción, deploy previews, branch deploys y `netlify dev`. Se avisa por consola de que no es apto para producción.
- `src/config/environment.mjs`: nueva `isNetlifyRuntime()` y `rateLimit.devMemory`. Detecta Netlify por el objeto global `Netlify` y por variables de AWS Lambda; `NETLIFY`/`CONTEXT` solo como señal adicional, porque según la documentación de Netlify son variables de compilación y no llegan a las funciones en ejecución.
- `netlify/functions/health.mjs`: `services.rateLimit.mode` pasa a ser `database` | `unavailable` | `memory` (este último solo en local explícito); `status` pasa a `degraded` si es `unavailable`. (Dependencia mínima: el health reportaba un modo «memory» que ya no existe por defecto.)
- Límites y periodos sin cambios: chat 8/min y 80/día por persona, 3000/día global; contacto 5/h; login 10/15 min (`CHAT_LIMIT_*`, `CONTACT_LIMIT_PER_HOUR`, `LOGIN_LIMIT_PER_15_MIN`).
- Base de datos: **sin migración nueva**. Se revisó `consume_rate_limit` en `001_initial_schema.sql` (INSERT … ON CONFLICT DO UPDATE atómico, permisos solo para `service_role`) y es compatible con lo requerido.
- `.env.example` y `README.md`: documentan `RATE_LIMIT_DEV_MEMORY` y el nuevo comportamiento.

### Cambios de comportamiento a tener en cuenta
- Sin Supabase configurado, el chat, el contacto y el login responden 503 `rate_limit_unavailable` (antes seguían con límite en memoria). Para probar en local sin Supabase: `RATE_LIMIT_DEV_MEMORY=true` en `.env` y `npm start`.
- `netlify dev` cuenta como entorno Netlify: allí se necesita Supabase configurado (la opción en memoria se ignora).

### Pruebas
- Nuevas: `tests/chat-consent.test.mjs`, `tests/rate-limit.test.mjs`. Ampliado `tests/helpers/mock-services.mjs` (modos de fallo del RPC).
- Actualizadas en `tests/api.test.mjs` las 3 pruebas que codificaban el respaldo en memoria (ahora esperan 503).
