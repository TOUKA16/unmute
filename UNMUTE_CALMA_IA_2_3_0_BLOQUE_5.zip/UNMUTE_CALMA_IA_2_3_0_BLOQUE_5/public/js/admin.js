/* ==========================================================
   UNMUTE · Administración (acceso, resumen, datos curiosos y noticias)
   Esta página NO decide quién es administrador. Solo:
   · envía el correo y la contraseña a POST /api/admin/login,
   · guarda el token que devuelve el servidor y lo envía como «Authorization: Bearer»,
   · muestra el panel únicamente cuando GET /api/admin/session responde 200.
   Cada operación protegida vuelve a ser verificada por el servidor (token + rol 'admin' en Supabase).
   Sin librerías, sin innerHTML: todo lo que viene del servidor se escribe con textContent.
   ========================================================== */
(function () {
  'use strict';

  var CLAVE = 'unmute_admin_sesion'; // sessionStorage: solo esta pestaña; se borra al cerrarla
  var TIMEOUT_MS = 15000;
  var MAX_TIMER = 2147483647; // límite de setTimeout
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function $(id) { return document.getElementById(id); }
  var vistas = { cargando: $('v-cargando'), login: $('v-login'), error: $('v-error'), panel: $('v-panel') };
  var f = $('fLogin');
  var gestores = []; // gestores de datos curiosos y noticias (se definen más abajo)
  var estado = { token: null, expiraEn: 0, usuario: null, verificadoEn: null, temporizador: null, enviando: false, saliendo: false, verificando: false };

  /* ---------- Almacenamiento de la sesión (solo token y caducidad) ---------- */
  function leerSesion() {
    try {
      var s = JSON.parse(sessionStorage.getItem(CLAVE) || 'null');
      if (s && typeof s.token === 'string' && s.token && typeof s.expiraEn === 'number') return s;
    } catch (_e) { /* almacenamiento no disponible o contenido inválido */ }
    return null;
  }
  function guardarSesion(token, expiraEn) {
    try { sessionStorage.setItem(CLAVE, JSON.stringify({ token: token, expiraEn: expiraEn })); } catch (_e) { /* la sesión seguirá solo en memoria */ }
  }
  function borrarSesion() {
    try { sessionStorage.removeItem(CLAVE); } catch (_e) { /* nada que borrar */ }
    if (estado.temporizador) { clearTimeout(estado.temporizador); estado.temporizador = null; }
    estado.token = null; estado.expiraEn = 0; estado.usuario = null; estado.verificadoEn = null;
    gestores.forEach(function (g) { g.reiniciar(); }); // no queda contenido administrativo en pantalla tras salir
  }

  /* ---------- Vistas ---------- */
  function mostrar(nombre) {
    Object.keys(vistas).forEach(function (k) { vistas[k].hidden = k !== nombre; });
    var h1 = vistas[nombre].querySelector('h1');
    if (h1) h1.focus({ preventScroll: false });
  }
  function texto(el, valor) { el.textContent = valor; el.hidden = !valor; }
  function hora(ms) { return new Date(ms).toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' }); }

  function irAlLogin(aviso) {
    borrarSesion();
    f.reset();
    limpiarErrores();
    texto($('loginAviso'), aviso || '');
    mostrar('login');
  }

  /* ---------- Llamadas a la API ---------- */
  function api(ruta, opciones) {
    opciones = opciones || {};
    var ctl = new AbortController();
    var t = setTimeout(function () { ctl.abort(); }, TIMEOUT_MS);
    var cabeceras = {};
    if (opciones.cuerpo !== undefined) cabeceras['Content-Type'] = 'application/json';
    if (opciones.token) cabeceras.Authorization = 'Bearer ' + opciones.token;
    return fetch(ruta, {
      method: opciones.metodo || 'GET',
      headers: cabeceras,
      body: opciones.cuerpo !== undefined ? JSON.stringify(opciones.cuerpo) : undefined,
      cache: 'no-store',
      credentials: 'omit',
      signal: ctl.signal
    }).then(function (res) {
      return res.text().then(function (t) {
        var datos = null;
        try { datos = JSON.parse(t); } catch (_e) { /* respuesta sin JSON */ }
        return { status: res.status, datos: datos || {}, reintentarEn: Number(res.headers.get('Retry-After')) || 0 };
      });
    }).catch(function () {
      return { status: 0, datos: {}, reintentarEn: 0 }; // sin conexión, tiempo agotado o respuesta ilegible
    }).then(function (r) { clearTimeout(t); return r; });
  }

  function mensajeDe(r, porDefecto) {
    // Los mensajes de error del backend son públicos y controlados (AppError); los 500 usan el genérico.
    if (r.status >= 400 && r.status < 500 || r.status === 503) {
      if (typeof r.datos.error === 'string' && r.datos.error) return r.datos.error;
    }
    if (r.status === 0) return 'No hay conexión con el servidor. Revisa tu conexión e inténtalo de nuevo.';
    return porDefecto;
  }

  /* ---------- Formulario de inicio de sesión ---------- */
  function limpiarErrores() {
    ['admEmail', 'admPass'].forEach(function (id) { $(id).removeAttribute('aria-invalid'); });
    texto($('admEmailErr'), ''); texto($('admPassErr'), ''); texto($('loginError'), '');
  }
  function errorCampo(inputId, errId, msg) {
    $(inputId).setAttribute('aria-invalid', 'true');
    texto($(errId), msg);
  }
  function ocupado(si) {
    estado.enviando = si;
    var b = $('btnLogin');
    b.disabled = si;
    b.setAttribute('aria-busy', si ? 'true' : 'false');
    b.textContent = si ? 'Iniciando sesión…' : 'Iniciar sesión';
  }

  f.addEventListener('submit', function (e) {
    e.preventDefault();
    if (estado.enviando) return; // evita envíos duplicados (doble clic o Enter repetido)
    limpiarErrores();
    $('loginAviso').hidden = true;

    var email = $('admEmail').value.trim();
    var password = $('admPass').value;
    var primero = null;
    if (!EMAIL_RE.test(email) || email.length > 120) { errorCampo('admEmail', 'admEmailErr', 'Escribe un correo válido.'); primero = primero || $('admEmail'); }
    if (!password) { errorCampo('admPass', 'admPassErr', 'Escribe tu contraseña.'); primero = primero || $('admPass'); }
    if (primero) { primero.focus(); return; }

    ocupado(true);
    api('/api/admin/login', { metodo: 'POST', cuerpo: { email: email, password: password } }).then(function (r) {
      ocupado(false);
      if (r.status === 200 && r.datos.accessToken && r.datos.user) {
        $('admPass').value = ''; // la contraseña no se conserva ni un instante más de lo necesario
        var dur = Number(r.datos.expiresIn);
        var expiraEn = Date.now() + (dur > 0 ? dur : 3600) * 1000;
        guardarSesion(r.datos.accessToken, expiraEn);
        entrar(r.datos.accessToken, expiraEn, r.datos.user);
        return;
      }
      $('admPass').value = '';
      var campos = r.datos.fields || {};
      if (r.status === 400 && (campos.email || campos.password)) {
        if (campos.email) errorCampo('admEmail', 'admEmailErr', String(campos.email));
        if (campos.password) errorCampo('admPass', 'admPassErr', String(campos.password));
        (campos.email ? $('admEmail') : $('admPass')).focus();
        return;
      }
      var msg;
      if (r.status === 429) {
        var min = r.reintentarEn ? Math.max(1, Math.ceil(r.reintentarEn / 60)) : 0;
        msg = 'Demasiados intentos de inicio de sesión.' + (min ? ' Vuelve a intentarlo en unos ' + min + ' min.' : ' Espera unos minutos.');
      } else {
        msg = mensajeDe(r, 'No se pudo iniciar sesión. Inténtalo de nuevo en unos minutos.');
      }
      texto($('loginError'), msg);
      $('admPass').focus();
    });
  });

  /* ---------- Entrada al panel ---------- */
  function entrar(token, expiraEn, usuario) {
    estado.token = token; estado.expiraEn = expiraEn; estado.usuario = usuario; estado.verificadoEn = Date.now();
    if (estado.temporizador) clearTimeout(estado.temporizador);
    // Solo comodidad: el servidor rechaza el token vencido aunque este temporizador no existiera.
    estado.temporizador = setTimeout(function () { sesionVencida(); }, Math.min(Math.max(expiraEn - Date.now(), 0), MAX_TIMER));
    $('admUsuario').textContent = (usuario && usuario.email) || '';
    $('sesCuenta').textContent = (usuario && usuario.email) || '';
    pintarSesion();
    seleccionarSeccion('resumen');
    mostrar('panel');
  }

  function pintarSesion() {
    $('sesVerif').textContent = estado.verificadoEn ? 'Confirmada por el servidor a las ' + hora(estado.verificadoEn) : '—';
    $('sesVence').textContent = estado.expiraEn ? 'Hacia las ' + hora(estado.expiraEn) + ' (el servidor decide la validez real)' : '—';
  }

  function sesionVencida() {
    if (!vistas.panel.hidden || estado.token) irAlLogin('Tu sesión venció. Inicia sesión de nuevo.');
  }

  /* ---------- Navegación del panel ---------- */
  var SECCIONES = ['resumen', 'datos', 'noticias', 'mensajes', 'sesion'];
  function seleccionarSeccion(nombre) {
    document.querySelectorAll('.adm-nav [data-sec]').forEach(function (b) {
      if (b.dataset.sec === nombre) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    SECCIONES.forEach(function (n) { $('s-' + n).hidden = n !== nombre; });
    if (nombre === 'sesion') pintarSesion();
    if (nombre === 'resumen' && estado.token) cargarStats();
    gestores.forEach(function (g) { if (g.seccion === nombre) g.alMostrar(); });
  }
  document.querySelectorAll('.adm-nav [data-sec]').forEach(function (b) {
    b.addEventListener('click', function () { seleccionarSeccion(b.dataset.sec); });
  });

  /* ---------- Resumen (GET /api/admin/stats, protegido en el servidor) ---------- */
  var ETIQUETAS_RECURSOS = [['total', 'Total'], ['published', 'Publicados'], ['draft', 'Borradores'], ['archived', 'Archivados']];
  var ETIQUETAS_MENSAJES = [['total', 'Total'], ['new', 'Recibidos'], ['read', 'En revisión'], ['resolved', 'Respondidos'], ['archived', 'Cerrados']];

  function pintarLista(dl, datos, etiquetas) {
    dl.textContent = '';
    etiquetas.forEach(function (par) {
      var caja = document.createElement('div');
      var dt = document.createElement('dt'); dt.textContent = par[1];
      var dd = document.createElement('dd'); dd.textContent = String(Number.isFinite(datos[par[0]]) ? datos[par[0]] : 0);
      caja.appendChild(dt); caja.appendChild(dd); dl.appendChild(caja);
    });
  }

  function cargarStats() {
    var token = estado.token;
    var est = $('statsEstado');
    est.classList.remove('err');
    est.textContent = 'Cargando…';
    $('btnStats').disabled = true;
    return api('/api/admin/stats', { token: token }).then(function (r) {
      if (token !== estado.token) return; // la sesión cambió mientras tanto
      $('btnStats').disabled = false;
      if (!rechazoDeSesion(r)) {
        if (r.status === 200 && r.datos.resources && r.datos.messages) {
          pintarLista($('statsRecursos'), r.datos.resources, ETIQUETAS_RECURSOS);
          var fact = (r.datos.resources.byType && r.datos.resources.byType.fact) || {};
          var extra = document.createElement('div');
          var dt = document.createElement('dt'); dt.textContent = 'Datos curiosos publicados';
          var dd = document.createElement('dd'); dd.textContent = String(fact.published || 0);
          extra.appendChild(dt); extra.appendChild(dd); $('statsRecursos').appendChild(extra);
          pintarLista($('statsMensajes'), r.datos.messages, ETIQUETAS_MENSAJES);
          est.textContent = 'Actualizado a las ' + hora(Date.now()) + '.';
        } else {
          est.classList.add('err');
          est.textContent = mensajeDe(r, 'No se pudieron cargar los recuentos. Inténtalo de nuevo.');
        }
      }
    });
  }
  $('btnStats').addEventListener('click', cargarStats);

  /** Si el servidor dice que la sesión ya no vale (401) o que la cuenta ya no es admin (403), se sale del panel. */
  function rechazoDeSesion(r) {
    if (r.status === 401) { irAlLogin('Tu sesión venció o ya no es válida. Inicia sesión de nuevo.'); return true; }
    if (r.status === 403) { irAlLogin('Esta cuenta no tiene permisos de administración.'); return true; }
    return false;
  }

  /* ---------- Confirmación antes de eliminar ---------- */
  function confirmar(titulo, texto) {
    return new Promise(function (resolver) {
      var d = $('dlgConf');
      $('dlgConfT').textContent = titulo; $('dlgConfX').textContent = texto;
      function fin(valor) { d.removeEventListener('close', alCerrar); $('dlgConfSi').onclick = null; $('dlgConfNo').onclick = null; if (d.open) d.close(); resolver(valor); }
      function alCerrar() { fin(false); } // Esc o clic fuera: cuenta como cancelar
      d.addEventListener('close', alCerrar);
      $('dlgConfSi').onclick = function () { fin(true); };
      $('dlgConfNo').onclick = function () { fin(false); };
      d.showModal();
      $('dlgConfNo').focus();
    });
  }

  /* ---------- Gestor de contenido (datos curiosos y noticias comparten la misma lógica) ----------
     El servidor es quien valida y autoriza; aquí solo se adelanta la validación para dar mensajes rápidos. */
  var IMG_RE = /^https:\/\/[^\s<>"'\\]{3,490}$/i;
  var FUENTE_RE = /^https?:\/\/\S{3,500}$/i;
  var ICONO_RE = /^[a-z0-9-]{1,40}$/;
  var HTML_RE = /<\s*\/?\s*[a-z!?]/i;
  function fechaReal(v) {
    if (!/^\d{4}-\d{2}-\d{2}$/.test(v)) return false;
    var p = v.split('-').map(Number), d = new Date(Date.UTC(p[0], p[1] - 1, p[2]));
    return d.getUTCFullYear() === p[0] && d.getUTCMonth() === p[1] - 1 && d.getUTCDate() === p[2];
  }
  function fechaCorta(iso) {
    var d = new Date(iso.length === 10 ? iso + 'T12:00:00' : iso);
    return isNaN(d) ? '' : d.toLocaleDateString('es', { day: 'numeric', month: 'long', year: 'numeric' });
  }
  function normalizar(t) { return String(t).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }

  function crearGestor(cfg) {
    var P = cfg.prefijo;
    function g(sufijo) { return $(P + sufijo); }
    var datos = { items: [], cargado: false, cargando: false, enviando: false, editando: null };
    var estadoTxt = { published: cfg.textoPublicado, draft: 'Borrador', archived: 'Archivado' };

    function mensaje(txt, esError) { var m = g('Msg'); m.classList.toggle('err', !!esError); m.textContent = txt || ''; }
    function limpiarErroresForm() {
      cfg.campos.forEach(function (c) { var i = $(c.id); i.removeAttribute('aria-invalid'); texto($(c.id + 'Err'), ''); });
      texto(g('FormErr'), '');
    }
    function errorCampo(c, msg) { $(c.id).setAttribute('aria-invalid', 'true'); texto($(c.id + 'Err'), msg); }

    /* --- Lista e indicadores --- */
    function contar() {
      var r = { total: datos.items.length, published: 0, draft: 0, archived: 0 };
      datos.items.forEach(function (it) { if (r[it.status] !== undefined) r[it.status] += 1; });
      return r;
    }
    function pintarIndicadores() {
      var r = contar();
      var et = [['total', 'Total'], ['published', cfg.etqPublicados], ['draft', 'Borradores']];
      if (r.archived) et.push(['archived', 'Archivados']);
      pintarLista(g('Stats'), r, et);
    }
    function visibles() {
      var q = normalizar(g('Buscar').value.trim()), f = g('Filtro').value;
      return datos.items.filter(function (it) { return (!f || it.status === f) && (!q || normalizar(it.title).indexOf(q) !== -1); });
    }
    function boton(clase, txt, etiqueta, fn) {
      var b = document.createElement('button'); b.type = 'button'; b.className = clase; b.textContent = txt;
      b.setAttribute('aria-label', etiqueta); b.addEventListener('click', fn); return b;
    }
    function renderLista() {
      var ul = g('Lista'); ul.textContent = '';
      pintarIndicadores();
      var lista = visibles();
      if (!lista.length) {
        mensaje(datos.items.length ? 'Ninguna coincidencia con la búsqueda o el filtro.' : cfg.vacio, false);
        return;
      }
      mensaje(lista.length + (lista.length === 1 ? ' elemento.' : ' elementos.'), false);
      lista.forEach(function (it) {
        var li = document.createElement('li'); li.className = 'adm-item';
        var h = document.createElement('h3'); h.textContent = it.title; li.appendChild(h);
        var meta = document.createElement('p'); meta.className = 'meta';
        var e1 = document.createElement('span'); e1.className = 'etq' + (it.status === 'published' ? ' pub' : ''); e1.textContent = estadoTxt[it.status] || it.status; meta.appendChild(e1);
        var e2 = document.createElement('span'); e2.className = 'etq'; e2.textContent = it.category; meta.appendChild(e2);
        var fecha = cfg.fechaDe(it);
        if (fecha) { var e3 = document.createElement('span'); e3.textContent = fecha; meta.appendChild(e3); }
        li.appendChild(meta);
        var d = document.createElement('p'); d.className = 'suave'; d.textContent = it.description; li.appendChild(d);
        var acc = document.createElement('p'); acc.className = 'acciones';
        acc.appendChild(boton('btn-sec', 'Editar', 'Editar: ' + it.title, function () { abrirForm(it); }));
        if (it.status === 'published') acc.appendChild(boton('btn-sec', 'Despublicar', 'Despublicar: ' + it.title, function () { cambiarEstado(it, 'unpublish'); }));
        else acc.appendChild(boton('btn-sec', 'Publicar', 'Publicar: ' + it.title, function () { cambiarEstado(it, 'publish'); }));
        acc.appendChild(boton('btn-pel', 'Eliminar', 'Eliminar: ' + it.title, function () { eliminar(it); }));
        li.appendChild(acc);
        ul.appendChild(li);
      });
    }

    /* --- Carga --- */
    function cargar() {
      if (datos.cargando) return Promise.resolve();
      var token = estado.token;
      datos.cargando = true; mensaje('Cargando…', false); g('Refrescar').disabled = true;
      return api(cfg.endpoint + (cfg.consulta || ''), { token: token }).then(function (r) {
        if (token !== estado.token) return;
        datos.cargando = false; g('Refrescar').disabled = false;
        if (rechazoDeSesion(r)) return;
        if (r.status === 200 && Array.isArray(r.datos[cfg.clave])) {
          datos.items = r.datos[cfg.clave]; datos.cargado = true;
          if (cfg.alCargar) cfg.alCargar(datos.items);
          renderLista();
        } else {
          mensaje(mensajeDe(r, 'No se pudo cargar la lista. Inténtalo de nuevo.'), true);
        }
      });
    }

    /* --- Formulario --- */
    function valores() {
      var v = {};
      cfg.campos.forEach(function (c) { v[c.api] = $(c.id).value.trim(); });
      return v;
    }
    function botonesSegunEstado(item) {
      var publicada = !!item && item.status === 'published';
      g('Borrador').hidden = publicada; g('Publicar').hidden = publicada; g('Cambios').hidden = !publicada;
    }
    function abrirForm(item) {
      datos.editando = item || null;
      limpiarErroresForm();
      cfg.campos.forEach(function (c) {
        var v = item && item[c.api] != null ? String(item[c.api]) : '';
        $(c.id).value = v;
      });
      var slugCampo = cfg.campos.filter(function (c) { return c.api === 'slug'; })[0];
      if (slugCampo) $(slugCampo.id).disabled = !!item; // el identificador público no cambia una vez creado
      g('FormT').textContent = item ? cfg.tituloEditar : cfg.tituloNuevo;
      botonesSegunEstado(item);
      g('Form').hidden = false;
      g('FormT').focus();
    }
    function cerrarForm() { g('Form').hidden = true; datos.editando = null; limpiarErroresForm(); }

    function ocupadoForm(si) {
      datos.enviando = si;
      ['Borrador', 'Publicar', 'Cambios', 'Cancelar'].forEach(function (s) { g(s).disabled = si; });
      g('Form').setAttribute('aria-busy', si ? 'true' : 'false');
    }

    function guardar(destino) {
      if (datos.enviando) return;
      limpiarErroresForm();
      var v = valores();
      var statusFinal = destino === 'keep' ? (datos.editando ? datos.editando.status : 'draft') : destino;
      var errores = cfg.validar(v, statusFinal);
      var claves = Object.keys(errores);
      if (claves.length) {
        var primero = null;
        cfg.campos.forEach(function (c) { if (errores[c.api]) { errorCampo(c, errores[c.api]); primero = primero || $(c.id); } });
        primero.focus(); return;
      }
      var cuerpo = {};
      cfg.campos.forEach(function (c) {
        if (c.api === 'slug' && (datos.editando || !v.slug)) return; // al editar no se cambia; al crear vacío se genera en el servidor
        cuerpo[c.api] = v[c.api];
      });
      cuerpo.status = statusFinal;
      var token = estado.token, editando = datos.editando;
      if (!editando && cfg.extraAlCrear) Object.keys(cfg.extraAlCrear).forEach(function (k) { cuerpo[k] = cfg.extraAlCrear[k]; });
      ocupadoForm(true);
      var ruta = editando ? cfg.endpoint + '/' + editando.id : cfg.endpoint;
      api(ruta, { metodo: editando ? 'PATCH' : 'POST', cuerpo: cuerpo, token: token }).then(function (r) {
        if (token !== estado.token) return;
        ocupadoForm(false);
        if (rechazoDeSesion(r)) return;
        if ((r.status === 200 || r.status === 201) && r.datos[cfg.unico]) {
          var nuevo = r.datos[cfg.unico];
          if (editando) datos.items = datos.items.map(function (it) { return it.id === nuevo.id ? nuevo : it; });
          else datos.items.unshift(nuevo);
          if (cfg.alCargar) cfg.alCargar(datos.items);
          cerrarForm(); renderLista();
          mensaje((statusFinal === 'published' ? cfg.guardadoPub : 'Guardado como borrador.'), false);
          return;
        }
        var campos = r.datos.fields || {}, primero = null;
        cfg.campos.forEach(function (c) { if (campos[c.api]) { errorCampo(c, String(campos[c.api])); primero = primero || $(c.id); } });
        texto(g('FormErr'), (r.status === 400 && primero) ? (r.datos.error || 'Revisa los campos marcados.') : mensajeDe(r, 'No se pudo guardar. Inténtalo de nuevo.'));
        if (primero) primero.focus();
      });
    }

    function cambiarEstado(it, accion) {
      if (datos.enviando) return;
      var token = estado.token;
      datos.enviando = true; mensaje(accion === 'publish' ? 'Publicando…' : 'Despublicando…', false);
      api(cfg.endpoint + '/' + it.id + '/' + accion, { metodo: 'POST', token: token }).then(function (r) {
        if (token !== estado.token) return;
        datos.enviando = false;
        if (rechazoDeSesion(r)) return;
        if (r.status === 200 && r.datos[cfg.unico]) {
          var nuevo = r.datos[cfg.unico];
          datos.items = datos.items.map(function (x) { return x.id === nuevo.id ? nuevo : x; });
          if (datos.editando && datos.editando.id === nuevo.id) abrirForm(nuevo);
          renderLista();
          mensaje(accion === 'publish' ? cfg.guardadoPub : '«' + nuevo.title + '» volvió a borrador y ya no es público.', false);
        } else {
          var f = r.datos.fields || {};
          var detalle = Object.keys(f).map(function (k) { return f[k]; }).join(' ');
          mensaje((mensajeDe(r, 'No se pudo cambiar el estado. Inténtalo de nuevo.')) + (detalle ? ' ' + detalle : ''), true);
        }
      });
    }

    function eliminar(it) {
      if (datos.enviando) return;
      confirmar(cfg.tituloEliminar, '«' + it.title + '» se eliminará de forma permanente y dejará de estar disponible. Esta acción no se puede deshacer.').then(function (si) {
        if (!si) return;
        var token = estado.token;
        datos.enviando = true; mensaje('Eliminando…', false);
        api(cfg.endpoint + '/' + it.id, { metodo: 'DELETE', token: token }).then(function (r) {
          if (token !== estado.token) return;
          datos.enviando = false;
          if (rechazoDeSesion(r)) return;
          if (r.status === 200) {
            datos.items = datos.items.filter(function (x) { return x.id !== it.id; });
            if (datos.editando && datos.editando.id === it.id) cerrarForm();
            if (cfg.alCargar) cfg.alCargar(datos.items);
            renderLista();
            mensaje('Se eliminó «' + it.title + '».', false);
          } else {
            mensaje(mensajeDe(r, 'No se pudo eliminar. Inténtalo de nuevo.'), true);
          }
        });
      });
    }

    /* --- Eventos --- */
    g('Nuevo').addEventListener('click', function () { abrirForm(null); });
    g('Cancelar').addEventListener('click', cerrarForm);
    g('Refrescar').addEventListener('click', cargar);
    g('Buscar').addEventListener('input', renderLista);
    g('Filtro').addEventListener('change', renderLista);
    g('Form').addEventListener('submit', function (e) {
      e.preventDefault();
      var b = e.submitter;
      var destino = b && !b.hidden && b.dataset && b.dataset.destino ? b.dataset.destino : null;
      // Con Enter (sin botón claro) se conserva el estado actual: una noticia publicada nunca vuelve a borrador por accidente.
      if (!destino) destino = datos.editando && datos.editando.status === 'published' ? 'keep' : 'draft';
      guardar(destino);
    });

    var api_ = {
      seccion: cfg.seccion,
      alMostrar: function () { if (!datos.cargado) cargar(); },
      reiniciar: function () {
        datos.items = []; datos.cargado = false; datos.cargando = false; datos.enviando = false; datos.editando = null;
        g('Lista').textContent = ''; g('Stats').textContent = ''; g('Buscar').value = ''; g('Filtro').value = '';
        cerrarForm(); mensaje('', false);
      }
    };
    gestores.push(api_);
    return api_;
  }

  /* --- Datos curiosos: tabla «resources» con resource_type = 'fact' --- */
  crearGestor({
    seccion: 'datos', prefijo: 'dc', endpoint: '/api/admin/resources', consulta: '?type=fact', clave: 'resources', unico: 'resource',
    extraAlCrear: { resource_type: 'fact' },
    textoPublicado: 'Publicado', etqPublicados: 'Publicados',
    vacio: 'Todavía no hay datos curiosos. Crea el primero con «Nuevo dato curioso».',
    tituloNuevo: 'Nuevo dato curioso', tituloEditar: 'Editar dato curioso', tituloEliminar: '¿Eliminar este dato curioso?',
    guardadoPub: 'Dato curioso publicado. Ya puede aparecer en «Un minuto para aprender».',
    campos: [
      { api: 'title', id: 'dcTitulo' }, { api: 'description', id: 'dcDesc' }, { api: 'content', id: 'dcContenido' },
      { api: 'category', id: 'dcCategoria' }, { api: 'source_url', id: 'dcFuente' }, { api: 'reviewed_at', id: 'dcRevision' },
      { api: 'icon', id: 'dcIcono' }, { api: 'image_url', id: 'dcImagen' }, { api: 'slug', id: 'dcSlug' }
    ],
    fechaDe: function (it) { return it.reviewed_at ? 'Revisado el ' + fechaCorta(it.reviewed_at) : 'Sin fecha de revisión'; },
    alCargar: function (items) { // sugerencias de categoría a partir de lo que ya existe
      var dl = $('dcCats'); dl.textContent = '';
      var vistas = {};
      items.forEach(function (it) { if (it.category && !vistas[it.category]) { vistas[it.category] = 1; var o = document.createElement('option'); o.value = it.category; dl.appendChild(o); } });
    },
    validar: function (v, destino) {
      var e = {};
      if (v.title.length < 3) e.title = 'Escribe un título de al menos 3 caracteres.'; else if (v.title.length > 140) e.title = 'El título admite hasta 140 caracteres.';
      if (!v.description) e.description = 'Escribe una descripción.'; else if (v.description.length > 600) e.description = 'La descripción admite hasta 600 caracteres.';
      if (v.content.length > 8000) e.content = 'El contenido admite hasta 8000 caracteres.';
      if (!v.category) e.category = 'Indica una categoría.'; else if (v.category.length > 60) e.category = 'La categoría admite hasta 60 caracteres.';
      if (v.source_url && !FUENTE_RE.test(v.source_url)) e.source_url = 'La fuente debe ser un enlace http o https.';
      if (v.reviewed_at && !fechaReal(v.reviewed_at)) e.reviewed_at = 'Usa una fecha válida.';
      if (v.icon && !ICONO_RE.test(v.icon)) e.icon = 'El icono usa solo minúsculas, números y guiones.';
      if (v.image_url && !IMG_RE.test(v.image_url)) e.image_url = 'La imagen debe ser un enlace https.';
      if (v.slug && !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(v.slug)) e.slug = 'Usa solo minúsculas, números y guiones.';
      if (destino === 'published') {
        if (!v.source_url) e.source_url = 'Un dato curioso publicado necesita una fuente.';
        if (!v.reviewed_at) e.reviewed_at = 'Indica la fecha en que revisaste el dato contra su fuente.';
      }
      return e;
    }
  });

  /* --- Noticias del admin: tabla «news» --- */
  var CATEGORIAS_NOTICIAS = ['Novedades de UNMUTE', 'Bienestar emocional', 'Autocuidado', 'Actualizaciones', 'Recursos educativos', 'Información importante'];
  crearGestor({
    seccion: 'noticias', prefijo: 'nt', endpoint: '/api/admin/news', clave: 'news', unico: 'news',
    textoPublicado: 'Publicada', etqPublicados: 'Publicadas',
    vacio: 'Todavía no hay noticias. Crea la primera con «Nueva noticia».',
    tituloNuevo: 'Nueva noticia', tituloEditar: 'Editar noticia', tituloEliminar: '¿Eliminar esta noticia?',
    guardadoPub: 'Noticia publicada. Ya se puede leer en la sección «Noticias».',
    campos: [
      { api: 'title', id: 'ntTitulo' }, { api: 'description', id: 'ntDesc' }, { api: 'content', id: 'ntContenido' },
      { api: 'category', id: 'ntCategoria' }, { api: 'image_url', id: 'ntImagen' }, { api: 'slug', id: 'ntSlug' }
    ],
    fechaDe: function (it) { return it.published_at ? 'Publicada el ' + fechaCorta(it.published_at) : ''; },
    validar: function (v, destino) {
      var e = {};
      if (v.title.length < 3) e.title = 'Escribe un título de al menos 3 caracteres.'; else if (v.title.length > 140) e.title = 'El título admite hasta 140 caracteres.';
      if (!v.description) e.description = 'Escribe una descripción breve.'; else if (v.description.length > 300) e.description = 'La descripción breve admite hasta 300 caracteres.';
      if (v.content.length > 8000) e.content = 'El contenido admite hasta 8000 caracteres.';
      if (CATEGORIAS_NOTICIAS.indexOf(v.category) === -1) e.category = 'Elige una categoría de la lista.';
      if (v.image_url && !IMG_RE.test(v.image_url)) e.image_url = 'La imagen debe ser un enlace https.';
      if (v.slug && !/^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(v.slug)) e.slug = 'Usa solo minúsculas, números y guiones.';
      ['title', 'description', 'content'].forEach(function (k) { if (!e[k] && HTML_RE.test(v[k])) e[k] = 'Escribe texto sin etiquetas HTML.'; });
      if (destino === 'published' && !v.content && !e.content) e.content = 'Escribe el contenido antes de publicar la noticia.';
      return e;
    }
  });

  /* ---------- Cerrar sesión ---------- */
  $('btnSalir').addEventListener('click', function () {
    if (estado.saliendo) return;
    estado.saliendo = true;
    var b = $('btnSalir');
    b.disabled = true;
    api('/api/admin/logout', { metodo: 'POST', token: estado.token }).then(function (r) {
      estado.saliendo = false;
      b.disabled = false;
      // La sesión local se borra siempre; si el servidor no respondió, se avisa con honestidad.
      irAlLogin(r.status === 200 ? 'Cerraste sesión.' : 'Cerraste sesión en este navegador. No pudimos avisar al servidor; si usas un equipo compartido, vuelve a intentarlo más tarde.');
    });
  });

  /* ---------- Mensajes de contacto (GET /api/admin/messages · PATCH /api/admin/messages/:id) ----------
     La autorización la decide el servidor (requerirAdmin). Los valores enviados son los estados internos
     (new, read, resolved, archived); aquí solo se traducen a etiquetas. Todo texto se escribe con textContent.
     No hay botón de eliminar: el alcance de este panel es leer y cambiar el estado. */
  var ETQ_ESTADO = { new: 'Recibido', read: 'En revisión', resolved: 'Respondido', archived: 'Cerrado' };
  var ETQ_CATEGORIA = { consulta: 'Consulta', sugerencia: 'Sugerencia', reporte_tecnico: 'Reporte técnico', otro: 'Otro' };
  var mensajes = { items: [], abierto: null, cargando: false, guardando: false };

  function msgAviso(id, txt, esError) { var m = $(id); m.classList.toggle('err', !!esError); m.textContent = txt || ''; }
  function msgFecha(iso) { var d = new Date(iso); return isNaN(d) ? '' : d.toLocaleString('es', { day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' }); }

  function msgPintarLista() {
    var ul = $('msgLista'); ul.textContent = '';
    mensajes.items.forEach(function (m) {
      var li = document.createElement('li'); li.className = 'adm-item';
      var h = document.createElement('h3'); h.textContent = m.name || 'Sin nombre'; li.appendChild(h);
      var meta = document.createElement('p'); meta.className = 'meta';
      [ETQ_ESTADO[m.status] || m.status, ETQ_CATEGORIA[m.category] || m.category, msgFecha(m.created_at)].forEach(function (t, i) {
        if (!t) return; var sp = document.createElement('span'); sp.className = i < 2 ? 'etq' : 'suave'; sp.textContent = t; meta.appendChild(sp);
      });
      li.appendChild(meta);
      var ex = document.createElement('p'); ex.className = 'adm-extracto'; ex.textContent = String(m.message || '').slice(0, 140) + (String(m.message || '').length > 140 ? '…' : ''); li.appendChild(ex);
      var acc = document.createElement('p'); acc.className = 'acciones';
      var b = document.createElement('button'); b.type = 'button'; b.className = 'btn-sec'; b.textContent = 'Abrir mensaje';
      b.setAttribute('aria-label', 'Abrir mensaje de ' + (m.name || 'una persona sin nombre') + ', ' + (ETQ_ESTADO[m.status] || m.status));
      b.addEventListener('click', function () { msgAbrir(m.id); });
      acc.appendChild(b); li.appendChild(acc); ul.appendChild(li);
    });
  }
  function msgCargar() {
    var token = estado.token;
    if (!token || mensajes.cargando) return;
    mensajes.cargando = true; msgAviso('msgMsg', 'Cargando mensajes…');
    var filtro = $('msgFiltro').value;
    api('/api/admin/messages' + (filtro ? '?status=' + encodeURIComponent(filtro) : ''), { token: token }).then(function (r) {
      mensajes.cargando = false;
      if (token !== estado.token) return;
      if (rechazoDeSesion(r)) return;
      if (r.status === 200 && Array.isArray(r.datos.messages)) {
        mensajes.items = r.datos.messages; msgPintarLista();
        msgAviso('msgMsg', mensajes.items.length ? mensajes.items.length + (mensajes.items.length === 1 ? ' mensaje.' : ' mensajes.') : 'No hay mensajes con este filtro.');
      } else msgAviso('msgMsg', mensajeDe(r, 'No se pudieron cargar los mensajes. Inténtalo de nuevo.'), true);
    });
  }
  function msgAbrir(id) {
    var m = mensajes.items.filter(function (x) { return x.id === id; })[0];
    if (!m) return;
    mensajes.abierto = id;
    $('msgDFecha').textContent = msgFecha(m.created_at) || '—';
    $('msgDCat').textContent = ETQ_CATEGORIA[m.category] || m.category || '—';
    $('msgDNombre').textContent = m.name || 'No indicado';
    $('msgDCorreo').textContent = m.email || 'No indicado';
    $('msgDId').textContent = m.id;
    $('msgDTexto').textContent = m.message || '';
    $('msgDEstado').value = m.status; msgAviso('msgDMsg', '');
    $('msgDetalle').hidden = false; $('msgDetalleT').focus();
  }
  function msgCerrar() { mensajes.abierto = null; $('msgDetalle').hidden = true; ['msgDFecha', 'msgDCat', 'msgDNombre', 'msgDCorreo', 'msgDId', 'msgDTexto'].forEach(function (i) { $(i).textContent = ''; }); msgAviso('msgDMsg', ''); }
  function msgGuardar() {
    var token = estado.token, id = mensajes.abierto, nuevo = $('msgDEstado').value;
    if (!token || !id || mensajes.guardando) return;
    mensajes.guardando = true; $('msgDGuardar').disabled = true; msgAviso('msgDMsg', 'Guardando…');
    api('/api/admin/messages/' + encodeURIComponent(id), { metodo: 'PATCH', token: token, cuerpo: { status: nuevo } }).then(function (r) {
      mensajes.guardando = false; $('msgDGuardar').disabled = false;
      if (token !== estado.token) return;
      if (rechazoDeSesion(r)) return;
      if (r.status === 200 && r.datos.message && r.datos.message.status === nuevo) {
        mensajes.items.forEach(function (m) { if (m.id === id) m.status = nuevo; });
        msgPintarLista(); msgAviso('msgDMsg', 'Estado actualizado: ' + ETQ_ESTADO[nuevo] + '.');
      } else msgAviso('msgDMsg', mensajeDe(r, 'No se pudo cambiar el estado. Inténtalo de nuevo.'), true);
    });
  }
  $('msgFiltro').addEventListener('change', function () { msgCerrar(); msgCargar(); });
  $('msgRefrescar').addEventListener('click', msgCargar);
  $('msgDGuardar').addEventListener('click', msgGuardar);
  $('msgDCerrar').addEventListener('click', msgCerrar);
  gestores.push({
    seccion: 'mensajes',
    alMostrar: msgCargar,
    reiniciar: function () { mensajes.items = []; mensajes.cargando = false; mensajes.guardando = false; msgCerrar(); $('msgLista').textContent = ''; $('msgFiltro').value = ''; msgAviso('msgMsg', ''); $('msgDGuardar').disabled = false; }
  });

  /* ---------- Comprobación de la sesión al cargar ---------- */
  function verificar() {
    if (estado.verificando) return;
    var guardada = leerSesion();
    if (!guardada) { irAlLogin(''); return; }
    if (guardada.expiraEn <= Date.now()) { irAlLogin('Tu sesión venció. Inicia sesión de nuevo.'); return; }
    estado.verificando = true;
    texto($('cargandoTxt'), 'Comprobando tu sesión…');
    mostrar('cargando');
    api('/api/admin/session', { token: guardada.token }).then(function (r) {
      estado.verificando = false;
      if (r.status === 200 && r.datos.ok && r.datos.user) { entrar(guardada.token, guardada.expiraEn, r.datos.user); return; }
      if (r.status === 401) { irAlLogin('Tu sesión venció o ya no es válida. Inicia sesión de nuevo.'); return; }
      if (r.status === 403) { irAlLogin('Esta cuenta no tiene permisos de administración.'); return; }
      // Fallo temporal (sin conexión, 429, 5xx): no se borra la sesión; se ofrece reintentar.
      $('errorTxt').textContent = mensajeDe(r, 'El servidor no respondió como se esperaba. Inténtalo de nuevo en un momento.');
      mostrar('error');
    });
  }
  $('btnReintentar').addEventListener('click', verificar);
  $('btnOtraSesion').addEventListener('click', function () { irAlLogin(''); });

  // Al volver a la pestaña, se reconfirma con el servidor (la sesión pudo vencer o cerrarse en otro sitio).
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState !== 'visible' || vistas.panel.hidden || !estado.token) return;
    var token = estado.token;
    if (estado.expiraEn <= Date.now()) { sesionVencida(); return; }
    api('/api/admin/session', { token: token }).then(function (r) {
      if (token !== estado.token) return;
      if (r.status === 200) { estado.verificadoEn = Date.now(); pintarSesion(); return; }
      rechazoDeSesion(r); // los fallos temporales se ignoran aquí: no se expulsa a nadie por un corte breve
    });
  });

  verificar();
})();
