# UNMUTE 0.1.0 — Concepto y presentación

## Cambios incorporados

- Se establece la identidad visual y el propósito de UNMUTE como diario emocional digital.
- Se presenta el lema «Tu voz también merece ser escuchada» y los ejes iniciales de la experiencia: sentir, escribir y reflexionar.
- Se incorpora una primera vista de presentación y una maqueta del registro emocional.

## Por qué se incorporaron

Definir con claridad el propósito y la propuesta de valor antes de incorporar interacciones y almacenamiento.

## Archivos principales

- `index.html`: estructura y contenido de la interfaz.
- `css/styles.css`: estilos visuales y adaptación de la interfaz.
- `js/app.js`: navegación y comportamiento de las funciones incorporadas.

## Cómo probarla

Abre `index.html` en un navegador moderno. No requiere instalación ni servicios externos.

## Alcance y límites funcionales

La aplicación presenta el concepto y la interfaz inicial. El formulario es demostrativo y todavía no conserva registros.

## Privacidad

No se transmiten entradas a servidores. Esta versión no incorpora backend ni cuentas.

## Comprobaciones realizadas

- Sintaxis JavaScript comprobada con `node --check`.
- No se detectaron IDs HTML duplicados.
- Se comprobaron las referencias locales a CSS y JavaScript.
- No se certificó la accesibilidad mediante una auditoría externa ni se realizó una prueba completa con lectores de pantalla.
