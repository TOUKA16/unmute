'use strict';
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const VIEWS=['inicio','registrar'];
function navigate(name){
 if(!VIEWS.includes(name)) return;
 $$('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+name));
 $$('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
}
document.addEventListener('click',e=>{
 const target=e.target.closest('[data-view],[data-go]');
 if(!target)return;
 navigate(target.dataset.view||target.dataset.go);
});

// Primera maqueta: no guarda datos ni procesa formularios.
