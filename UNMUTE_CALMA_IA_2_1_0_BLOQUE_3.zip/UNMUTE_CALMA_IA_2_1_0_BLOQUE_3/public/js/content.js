/* ==========================================================
   UNMUTE · Contenido público del servidor: «Un minuto para aprender» y «Noticias»
   · GET /api/facts/today?date=AAAA-MM-DD  → el mismo dato durante todo el día (la fecha es la del dispositivo).
   · GET /api/news y GET /api/news/:slug   → solo noticias publicadas, leídas de Supabase en cada consulta.
   No toca el diario ni el almacenamiento local. Todo texto del servidor se escribe con textContent (sin HTML).
   ========================================================== */
(function () {
  'use strict';
  var TIMEOUT_MS = 12000;
  function $(id) { return document.getElementById(id); }
  function el(tag, clase, texto) { var e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; }

  /** GET JSON con tiempo máximo; nunca lanza: devuelve {status, datos}. status 0 = sin conexión. */
  function pedir(ruta) {
    var ctl = new AbortController();
    var t = setTimeout(function () { ctl.abort(); }, TIMEOUT_MS);
    return fetch(ruta, { cache: 'no-cache', credentials: 'omit', headers: { Accept: 'application/json' }, signal: ctl.signal })
      .then(function (res) { return res.json().catch(function () { return {}; }).then(function (d) { return { status: res.status, datos: d || {} }; }); })
      .catch(function () { return { status: 0, datos: {} }; })
      .then(function (r) { clearTimeout(t); return r; });
  }
  function fechaLarga(iso) {
    var d = new Date(iso);
    return isNaN(d) ? '' : new Intl.DateTimeFormat('es', { day: 'numeric', month: 'long', year: 'numeric' }).format(d);
  }
  function urlSegura(u) { return typeof u === 'string' && /^https?:\/\/\S+$/i.test(u); }
  function dominio(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (_e) { return u; } }

  /* ---------- Un minuto para aprender ---------- */
  var minutoCargando = false, minutoListo = false;
  function fechaLocal() {
    var d = new Date(), p = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function cargarMinuto() {
    if (minutoCargando || minutoListo) return;
    minutoCargando = true;
    $('minutoEstado').hidden = false; $('minutoEstado').classList.remove('err');
    $('minutoEstado').textContent = 'Cargando el dato de hoy…';
    $('minutoAcc').hidden = true;
    pedir('/api/facts/today?date=' + fechaLocal()).then(function (r) {
      minutoCargando = false;
      var f = r.status === 200 && r.datos.fact;
      if (!f) {
        $('minutoCuerpo').hidden = true;
        $('minutoEstado').classList.add('err');
        $('minutoEstado').textContent = r.status === 404
          ? 'Todavía no hay un dato publicado para hoy.'
          : 'Hoy no pudimos cargar este dato. Tu diario y el resto de UNMUTE funcionan con normalidad.';
        $('minutoAcc').hidden = false;
        return;
      }
      minutoListo = true;
      $('minutoCat').textContent = f.category || '';
      $('minutoCat').hidden = !f.category;
      $('minutoTitulo').textContent = f.title || '';
      $('minutoDesc').textContent = f.description || '';
      var fuente = $('minutoFuente'); fuente.textContent = '';
      if (urlSegura(f.source_url)) {
        fuente.appendChild(document.createTextNode('Fuente: '));
        var a = el('a', null, dominio(f.source_url));
        a.href = f.source_url; a.target = '_blank'; a.rel = 'noopener noreferrer';
        fuente.appendChild(a);
        if (f.reviewed_at) fuente.appendChild(document.createTextNode(' · Revisado el ' + fechaLarga(f.reviewed_at + 'T12:00:00')));
      }
      fuente.hidden = !fuente.textContent;
      $('minutoEstado').hidden = true;
      $('minutoCuerpo').hidden = false;
    });
  }
  $('minutoOtra').addEventListener('click', cargarMinuto);

  /* ---------- Noticias ---------- */
  var nCargando = false;
  function ponerImagen(img, url) {
    img.hidden = true;
    img.removeAttribute('src');
    if (!/^https:\/\/\S+$/i.test(url || '')) return;
    img.referrerPolicy = 'no-referrer';
    img.onerror = function () { img.hidden = true; }; // si la imagen no carga, la noticia se lee igual
    img.onload = function () { img.hidden = false; };
    img.src = url;
  }
  function tarjeta(n) {
    var art = el('article', 'noticia');
    var img = el('img', 'noticia-img'); img.alt = ''; img.loading = 'lazy'; img.decoding = 'async';
    art.appendChild(img);
    ponerImagen(img, n.image_url);
    var cuerpo = el('div', 'noticia-cuerpo');
    var meta = el('p', 'meta');
    meta.appendChild(el('span', 'etq', n.category || ''));
    if (n.published_at) meta.appendChild(document.createTextNode(' ' + fechaLarga(n.published_at)));
    cuerpo.appendChild(meta);
    cuerpo.appendChild(el('h2', null, n.title));
    cuerpo.appendChild(el('p', null, n.description));
    var b = el('button', 'btn-sec', 'Leer noticia'); b.type = 'button';
    b.setAttribute('aria-label', 'Leer noticia: ' + n.title);
    b.addEventListener('click', function () { abrir(n.slug, b); });
    cuerpo.appendChild(b);
    art.appendChild(cuerpo);
    return art;
  }
  function cargarNoticias() {
    if (nCargando) return;
    nCargando = true;
    var est = $('nEstado'); est.classList.remove('err'); est.textContent = 'Cargando noticias…';
    $('nActualizar').disabled = true;
    pedir('/api/news').then(function (r) {
      nCargando = false; $('nActualizar').disabled = false;
      var lista = $('nLista'); lista.textContent = '';
      if (r.status !== 200 || !Array.isArray(r.datos.news)) {
        est.classList.add('err');
        est.textContent = r.status === 0 ? 'No hay conexión con el servidor. Revisa tu conexión e inténtalo de nuevo.' : 'No pudimos cargar las noticias en este momento. Inténtalo de nuevo en unos minutos.';
        return;
      }
      if (!r.datos.news.length) { est.textContent = 'Todavía no hay noticias publicadas. Vuelve más tarde.'; return; }
      est.textContent = '';
      r.datos.news.forEach(function (n) { lista.appendChild(tarjeta(n)); });
    });
  }
  $('nActualizar').addEventListener('click', cargarNoticias);

  var dlg = $('lectorNoticia');
  function abrir(slug, origen) {
    $('nTit').textContent = 'Cargando…'; $('nMeta').textContent = ''; $('nTxt').textContent = ''; ponerImagen($('nImg'), '');
    if (!dlg.open) dlg.showModal();
    pedir('/api/news/' + encodeURIComponent(slug)).then(function (r) {
      var n = r.status === 200 && r.datos.news;
      if (!n) {
        $('nTit').textContent = 'No pudimos abrir esta noticia';
        $('nTxt').textContent = r.status === 404 ? 'Ya no está publicada. Actualiza la lista para ver las noticias vigentes.' : 'Inténtalo de nuevo en unos minutos.';
        return;
      }
      $('nTit').textContent = n.title;
      $('nMeta').textContent = [n.category, n.published_at ? fechaLarga(n.published_at) : ''].filter(Boolean).join(' · ');
      $('nTxt').textContent = n.content || n.description; // texto plano: los saltos de línea se conservan por CSS
      ponerImagen($('nImg'), n.image_url);
    });
    dlg.addEventListener('close', function () { if (origen && document.body.contains(origen)) origen.focus(); }, { once: true });
  }
  $('nCerrar').addEventListener('click', function () { dlg.close(); });

  /* ---------- Cuándo cargar ---------- */
  function alEntrar(v) {
    if (v === 'inicio') cargarMinuto();
    if (v === 'noticias') cargarNoticias(); // en cada visita: siempre se consulta el servidor
  }
  document.addEventListener('unmute:vista', function (e) { alEntrar(e.detail); });
  var actual = document.querySelector('nav.principal a[aria-current="page"]'); // app.js ya mostró la vista inicial
  if (actual) alEntrar(actual.dataset.v);
})();
