# INFORME DE CAMBIOS · UNMUTE 2.1.0
## Bloque 3: datos curiosos y sistema de noticias

**Base de comparación:** paquete UNMUTE 2.0.2 · Bloque 2.  
**Versión del proyecto:** 2.1.0.  
**Alcance:** nuevas experiencias de datos curiosos y noticias, panel de administración, publicación pública y su persistencia en Supabase.

## 1. Funcionalidades incorporadas

### Datos curiosos
- Se completa la pestaña **Datos curiosos** del panel administrativo.
- Desde el panel se pueden listar, buscar por título, filtrar por estado, crear, editar, guardar borradores, publicar, despublicar y eliminar datos.
- Cada dato reutiliza `resources` con `resource_type = 'fact'`.
- El backend mantiene la condición editorial de publicación: un dato necesita tanto `source_url` como `reviewed_at`.
- Se incorpora en Inicio la tarjeta **Un minuto para aprender**, conectada a `/api/facts/today`.
- El dato se determina por la fecha del dispositivo, por lo que recargar la página no lo cambia durante ese día.

### Noticias
- Se incorpora la pestaña **Noticias del admin** con búsqueda, filtros, indicadores, formulario de alta y edición, publicación, despublicación y eliminación con confirmación.
- Se añaden `src/services/news.service.mjs`, `netlify/functions/news.mjs` y `netlify/functions/admin-news.mjs`.
- La API pública ofrece `GET /api/news` y `GET /api/news/:slug`; solo muestra noticias publicadas y las ordena desde la más reciente.
- La API administrativa permite gestionar noticias y exige una sesión de administrador validada en el backend.
- La lista pública omite el texto completo; el contenido se solicita al abrir una noticia.
- La interfaz presenta el texto como texto plano mediante `textContent`; el servidor rechaza etiquetas HTML y URLs de imagen que no sean HTTPS.
- La fecha de publicación la establece un trigger de base de datos. No se acepta la fecha enviada por el navegador.

### Persistencia y seguridad
- Se añade `supabase/migrations/003_news.sql`, que crea una tabla `news` separada de `resources`, restricciones de contenido, índice, trigger de fechas y políticas RLS.
- La lectura pública usa la clave anónima y filtra por estado publicado.
- La gestión se hace con el token de la persona administradora y las políticas RLS; el nuevo servicio no usa la clave de servicio para administrar noticias.
- La política CSP permite imágenes HTTPS externas en `img-src`, manteniendo las demás restricciones de scripts y estilos.
- Los cambios del bloque no incorporan el diario personal a las solicitudes del chat ni lo envían a los nuevos endpoints.

## 2. Archivos principales

**Nuevos**
- `supabase/migrations/003_news.sql`
- `src/services/news.service.mjs`
- `netlify/functions/news.mjs`
- `netlify/functions/admin-news.mjs`
- `public/js/content.js`
- `tests/bloque3.test.mjs`
- `CHANGELOG_BLOQUE_3.md`

**Modificados**
- `public/index.html` y `public/js/app.js`: sección pública Noticias y navegación/evento de vistas.
- `public/js/content.js`: tarjeta de dato del día y lector de noticias.
- `public/admin.html`, `public/js/admin.js` y `public/css/admin.css`: formularios y gestión administrativa.
- `src/lib/validation.mjs`: validaciones para noticias.
- `src/lib/supabase.mjs`: mensajes de error neutrales.
- `netlify.toml`: CSP para imágenes HTTPS.
- `scripts/check.mjs` y `tests/helpers/mock-services.mjs`: comprobaciones y soporte de datos simulados.
- `README.md`, `CHANGELOG.md` y `package.json`: documentación y versión 2.1.0.

## 3. Pruebas ejecutadas en este entorno

| Comprobación | Resultado |
|---|---:|
| `npm test` | **70/70 pruebas aprobadas** |
| `npm run check` | **44 correctas, 0 errores, 1 advertencia** (45 comprobaciones) |
| `npm run seed:check` | **Correcto** |
| `npm run e2e` | **No ejecutable**: falta `tests/e2e-smoke.mjs` |

Las pruebas de noticias cubren el ciclo de borrador, publicación, edición, despublicación y eliminación; orden cronológico; validaciones; acceso público y administrativo; separación entre contenido público y borradores; y lectura desde clientes simulados independientes. También se mantiene la batería de regresión de los bloques anteriores.

## 4. Límites de la verificación

- Las pruebas automatizadas utilizan Supabase y OpenAI simulados. No acreditan que la migración SQL, el trigger ni las políticas RLS se comporten correctamente en un proyecto PostgreSQL real.
- La migración `003_news.sql` debe ejecutarse en Supabase después de `001` y `002`.
- No se verificó un despliegue real de Netlify ni el flujo de autenticación contra credenciales reales.
- No se comprobó la carga de imágenes externas HTTPS con una conexión de producción.
- `npm run e2e` sigue declarado en `package.json`, pero el script al que apunta no se encuentra en el paquete.

## 5. Pasos necesarios antes de publicar

1. Ejecutar `003_news.sql` en el proyecto Supabase correspondiente.
2. Verificar que la cuenta que administrará el contenido tenga el rol `admin`.
3. Configurar las variables privadas de Supabase y, si se habilita la IA, OpenAI en el entorno de funciones de Netlify.
4. Desplegar y probar `/api/health`, `/admin`, la gestión de datos y noticias, y su lectura pública desde más de un dispositivo.
5. Completar la revisión de privacidad, seguridad y requisitos legales antes de abrir el producto a personas usuarias.

**Resultado:** el Bloque 3 está integrado en el paquete y supera las pruebas automatizadas y comprobaciones estáticas ejecutadas. La publicación real queda condicionada a aplicar la migración y validar el entorno Supabase/Netlify de destino.
