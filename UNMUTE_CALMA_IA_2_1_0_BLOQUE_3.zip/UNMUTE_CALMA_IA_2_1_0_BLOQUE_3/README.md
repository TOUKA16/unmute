# UNMUTE · Calma orgánica + IA
## Versión 2.1.0 · Bloque 3: datos curiosos y noticias

UNMUTE combina un diario emocional de uso personal con herramientas opcionales de acompañamiento, recursos educativos y contenido editorial. Esta versión incorpora la gestión de datos curiosos y un sistema de noticias públicas, conectado a Supabase y administrable desde el panel privado.

El proyecto utiliza una arquitectura de frontend estático, Netlify Functions, Supabase (PostgreSQL, Auth y RLS) y OpenAI desde el backend.

## Qué incluye esta versión

### Diario y acompañamiento
- El diario y sus entradas permanecen en el almacenamiento local del navegador.
- Las entradas del diario no se adjuntan al chat ni se envían automáticamente a Supabase.
- El chat con IA requiere consentimiento explícito y utiliza una conversación temporal de la pestaña.
- La clave de OpenAI se utiliza desde el backend, nunca desde el navegador.
- Se mantiene el control de límites de uso persistente en Supabase. En producción no hay un respaldo silencioso en memoria.

### Datos curiosos
- Nueva sección **Datos curiosos** en el panel de administración.
- Permite buscar, filtrar, crear, editar, guardar borradores, publicar, despublicar y eliminar.
- Reutiliza la tabla `resources` con `resource_type = 'fact'`.
- Un dato solo se puede publicar cuando tiene una fuente y una fecha de revisión.
- La tarjeta **Un minuto para aprender** aparece en Inicio y obtiene el dato del endpoint `/api/facts/today`.
- El dato permanece estable durante el día para una misma fecha del dispositivo.

### Noticias
- Nueva sección **Noticias del admin** con búsqueda, filtro por estado, indicadores y gestión completa de noticias.
- Las noticias se almacenan en una tabla propia `news`, separada del catálogo de recursos.
- Se pueden crear como borrador, editar, publicar, despublicar y eliminar.
- La fecha de publicación la fija la base de datos al publicar, no el navegador.
- La sección pública **Noticias** presenta solo contenido publicado, ordenado desde lo más reciente.
- La lista pública no entrega el contenido completo; cada noticia se abre mediante su identificador público.
- El texto se muestra como texto plano, sin HTML.

## Requisitos

- Node.js **20.12 o superior**.
- Un proyecto Supabase para autenticación y base de datos.
- Una clave de API de OpenAI y un modelo habilitado para esa cuenta, si se desea activar el acompañamiento con IA.
- Una cuenta de Netlify para el despliegue.

## Ejecutar localmente

1. Copia `.env.example` como `.env` y completa las variables necesarias. No compartas ese archivo ni lo subas al repositorio.
2. Abre una terminal en la carpeta que contiene `package.json`.
3. Ejecuta:

```bash
npm start
```

4. Abre `http://localhost:3000`. El panel está en `http://localhost:3000/admin`.

El servidor local sirve `public/` y ejecuta las mismas funciones de `netlify/functions/`. No necesita instalar dependencias para arrancar con `npm start`.

Para usar el entorno de desarrollo de Netlify:

```bash
npm run dev
```

Este comando utiliza `npx netlify-cli dev`; requiere acceso a Netlify CLI y debe disponer de las variables de entorno apropiadas.

## Configurar Supabase

Ejecuta las migraciones en este orden desde **Supabase → SQL Editor**:

1. `supabase/migrations/001_initial_schema.sql`
2. `supabase/migrations/002_seed_resources.sql`
3. `supabase/migrations/003_news.sql`

La migración `003_news.sql` crea la tabla de noticias, sus restricciones, el trigger de fecha de publicación y las políticas RLS. Es necesaria para que funcionen los endpoints de noticias.

Para acceder al panel, crea o utiliza una cuenta en Supabase Auth y asígnale el rol `admin` según las instrucciones incluidas al final de `001_initial_schema.sql`. El servidor verifica la identidad y el rol; la interfaz no decide quién es administrador.

La semilla del catálogo está en `src/data/resources-seed.json`, fuera de la carpeta pública. Para comprobar que el SQL de la semilla coincide con el JSON:

```bash
npm run seed:check
```

Para regenerar el SQL a partir del archivo JSON:

```bash
npm run seed:build
```

## Desplegar en Netlify

El archivo `netlify.toml` configura `public/` como carpeta pública y `netlify/functions/` como directorio de funciones.

1. Sube el proyecto a un repositorio privado.
2. Conecta el repositorio con Netlify.
3. Comprueba que el comando de build esté vacío y que la carpeta de publicación sea `public` (según `netlify.toml`).
4. En las variables de entorno de Netlify, con alcance **Functions**, configura los secretos y credenciales:
   - `SUPABASE_URL`
   - `SUPABASE_ANON_KEY` o `SUPABASE_PUBLISHABLE_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY` o `SUPABASE_SECRET_KEY`
   - `OPENAI_API_KEY` y `OPENAI_MODEL` para activar el chat con IA.
5. Ejecuta las migraciones de Supabase antes de probar las funciones correspondientes.
6. Despliega y verifica `/api/health`, `/admin`, el inicio de sesión administrativo, los recursos, el dato del día y las noticias.

Nunca coloques claves privadas en `public/`, HTML, CSS, JavaScript de navegador ni en el repositorio. La clave `service_role` / `secret` debe permanecer únicamente en el entorno de funciones.

## Comprobaciones

Comandos disponibles:

```bash
npm test
npm run check
npm run seed:check
```

`npm test` ejecuta las pruebas automatizadas con servicios simulados. Estas pruebas comprueban rutas, validaciones, permisos, reglas de publicación, privacidad del diario y flujos funcionales. No sustituyen una prueba contra un proyecto Supabase o un despliegue real.

En esta entrega, `npm run check` informa de una advertencia: `package.json` declara `npm run e2e`, pero el archivo `tests/e2e-smoke.mjs` no está incluido. Por tanto, ese comando no constituye una prueba E2E ejecutable en este paquete.

## Privacidad y límites

- El contenido del diario se conserva en el almacenamiento local del navegador. Ese almacenamiento no está cifrado por esta aplicación y alguien con acceso al dispositivo podría verlo.
- El diario no se envía automáticamente al chat ni a la base de datos.
- Cuando se acepta el aviso y se envía un mensaje al chat, se remite el contexto reciente de esa conversación al backend y después al proveedor de IA. La aplicación solicita `store: false`; esto no equivale a garantizar retención cero por parte del proveedor.
- El hosting y los proveedores pueden procesar metadatos conforme a sus políticas. Revisa sus condiciones y controles de retención antes de usar información emocional real.
- Los mensajes enviados mediante el formulario de contacto se almacenan en la base de datos para que puedan ser gestionados desde el panel. No son entradas del diario.
- El panel administrativo no ofrece acceso al diario personal.
- UNMUTE IA no es un servicio clínico, no diagnostica y puede equivocarse. No garantiza detectar crisis ni sustituye ayuda profesional o atención urgente.
- Antes de abrir el producto al público hacen falta, entre otros aspectos, una política de privacidad definitiva, revisión legal aplicable, procedimientos de incidentes, pruebas de seguridad y evaluación de respuestas ante situaciones adversas.

Consulta `CHANGELOG_BLOQUE_3.md` y `INFORME_CAMBIOS_BLOQUE_3.md` para conocer el alcance y las comprobaciones de esta versión.
