# UNMUTE · Calma orgánica + IA

**Versión:** 2.0.2  
**Bloque:** 2 — Protección de recursos y panel administrativo  
**Lema:** «Tu voz también merece ser escuchada».

UNMUTE es un diario emocional digital. El diario y sus borradores permanecen en el navegador; Acompañar con IA es una herramienta complementaria que solo procesa los mensajes que la persona decide enviar después de aceptar el aviso.

Esta versión conserva las reparaciones del Bloque 1 y añade el resguardo de la semilla editorial fuera de la carpeta pública, un acceso administrativo inicial protegido y una comprobación estática del proyecto.

## Cambios de la versión 2.0.2

- La semilla `resources-seed.json` se mueve de `public/data/` a `src/data/`, para que los borradores no estén disponibles mediante una URL pública.
- El generador `scripts/build-seed.mjs` utiliza la nueva ubicación y la migración 002 se mantiene sincronizada.
- Se incorpora `public/admin.html` con inicio de sesión, verificación de sesión, panel inicial y cierre de sesión.
- `/admin`, `/admin/` y `/admin.html` conducen a la página administrativa.
- Se añaden cabeceras `noindex` y `no-store` para las rutas administrativas.
- Se incorpora `scripts/check.mjs` y el comando `npm run check`.

El detalle completo está en `CHANGELOG_BLOQUE_2.md` y `INFORME_CAMBIOS_BLOQUE_2.md`.

## Arquitectura

- **Frontend:** HTML, CSS y JavaScript en `public/`.
- **Backend:** Netlify Functions en `netlify/functions/`.
- **Datos y autenticación:** Supabase / PostgreSQL / Auth / RLS.
- **IA:** OpenAI desde el backend.
- **Configuración:** `src/config/`.
- **Librerías comunes:** `src/lib/`.
- **Servicios:** `src/services/`.
- **Semilla privada de contenido:** `src/data/resources-seed.json`.
- **Migraciones:** `supabase/migrations/`.
- **Pruebas:** `tests/`.

## Desarrollo local

Requisitos: Node.js 20.12 o superior.

1. Copia `.env.example` como `.env` y configura las variables necesarias.
2. Instala dependencias si tu entorno lo requiere:

```bash
npm install
```

3. Inicia el servidor local:

```bash
npm start
```

4. Abre `http://localhost:3000`.

Sin Supabase configurado, las operaciones que requieren base de datos (catálogo, administración y límites de producción) responden con errores controlados. Para pruebas locales aisladas se permite `RATE_LIMIT_DEV_MEMORY=true`, pero solo fuera de Netlify y nunca como protección de producción.

## Panel administrativo

Abre `http://localhost:3000/admin`, `http://localhost:3000/admin/` o `http://localhost:3000/admin.html`. El panel requiere Supabase configurado y una cuenta con rol `admin`. El servidor comprueba el rol; no se confía en permisos declarados por el navegador.

El panel de esta versión incluye inicio de sesión, verificación de sesión, resumen estadístico y cierre de sesión. Los endpoints administrativos de recursos y mensajes ya existen, pero esta versión todavía no incorpora editores visuales completos para gestionar todo el catálogo o las noticias.

Para crear la primera cuenta administradora, sigue el paso manual documentado al final de `supabase/migrations/001_initial_schema.sql`.

## Semilla del catálogo

El archivo fuente se encuentra en `src/data/resources-seed.json`, fuera de `public/`. Contiene 18 recursos: 16 publicados y 2 borradores. El frontend no debe descargar la semilla directamente.

Para regenerar o comprobar la migración:

```bash
npm run seed:build
npm run seed:check
```

El endpoint público del catálogo devuelve únicamente recursos publicados cuando Supabase está configurado.

## Pruebas

```bash
npm test
npm run check
npm run seed:check
```

- `npm test`: pruebas de API, página administrativa, consentimiento y límites; utilizan servicios simulados.
- `npm run check`: comprobación estática de archivos, funciones, migraciones, semilla, rutas, CSP, referencias locales, sintaxis y búsqueda de secretos evidentes.
- `npm run seed:check`: comprueba que la semilla JSON y la migración SQL estén sincronizadas.
- `npm run e2e`: está declarado, pero en esta entrega no existe `tests/e2e-smoke.mjs`; no debe presentarse como una prueba ejecutada correctamente.

## Publicación en Netlify

Este proyecto está configurado para **Netlify**: `public/` es el directorio de publicación y `netlify/functions/` contiene las funciones serverless.

1. Sube el proyecto a un repositorio GitHub sin `.env` ni secretos.
2. Conecta el repositorio a Netlify.
3. Configura las variables privadas del archivo `.env.example` en la configuración de entorno de Netlify, con alcance de Functions.
4. Ejecuta las migraciones de Supabase en orden, si aún no se han aplicado.
5. Comprueba `/api/health`, `/admin` y las APIs desde el despliegue HTTPS.

No publiques las claves `OPENAI_API_KEY` ni `SUPABASE_SERVICE_ROLE_KEY` en el frontend o en Git. La suscripción de ChatGPT no incluye automáticamente consumo de API de OpenAI.

## Privacidad y límites conocidos

- El diario y los borradores permanecen en `localStorage`; no se adjuntan automáticamente a Acompañar.
- El almacenamiento local no está cifrado. Otra persona con acceso al mismo perfil del navegador puede acceder a los registros.
- Acompañar envía al backend y al proveedor de IA los mensajes elegidos por la persona tras aceptar el aviso. `store: false` no es una garantía de retención cero del proveedor.
- El login guarda el token administrativo en `sessionStorage` de la pestaña y lo verifica con el servidor; no existe renovación automática del token en esta versión.
- Si Supabase no está disponible, las operaciones protegidas por rate limit rechazan la solicitud con HTTP 503. El contador en memoria solo puede habilitarse expresamente para desarrollo local mediante `RATE_LIMIT_DEV_MEMORY=true` y se ignora en Netlify.
- El hosting puede conservar metadatos de solicitudes. Revisa las políticas y condiciones del proveedor antes de tratar mensajes emocionales reales.
- `docs/` todavía no contiene documentación técnica adicional; el README y los changelogs registran el estado del bloque.

UNMUTE IA no es terapeuta, no diagnostica y no es un servicio de emergencias. Puede equivocarse. Ante peligro inmediato, prioriza los servicios de emergencia y la ayuda humana.

---

**UNMUTE — Tu voz también merece ser escuchada.**
