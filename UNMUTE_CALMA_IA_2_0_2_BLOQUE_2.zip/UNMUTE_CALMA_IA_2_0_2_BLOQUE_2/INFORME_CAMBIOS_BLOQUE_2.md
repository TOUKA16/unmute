# UNMUTE 2.0.2 — Informe de cambios del Bloque 2
## Protección de recursos y recuperación del panel administrativo

**Versión de partida:** 2.0.1 — Bloque 1  
**Versión resultante:** 2.0.2 — Bloque 2  
**Base comparada:** `UNMUTE_CALMA_IA_2_0_1_BLOQUE_1.zip`  
**Alcance:** tres tareas: proteger la semilla, habilitar el acceso administrativo inicial y añadir comprobaciones estáticas.

---

## 1. Resumen

El Bloque 2 conserva las reparaciones de consentimiento del chat y rate limit seguro del Bloque 1. Añade una primera interfaz administrativa protegida, elimina la exposición pública del archivo JSON de recursos y proporciona una comprobación estática reproducible del proyecto.

No se modificó la lógica del chat, su consentimiento ni el servicio de límites de uso en este bloque.

## 2. Cambios incorporados y motivo

### 2.1. Semilla de recursos fuera de `public/`

**Cambio:**
- Se mueve `public/data/resources-seed.json` a `src/data/resources-seed.json`.
- Se actualiza `scripts/build-seed.mjs` para leer desde la nueva ubicación.
- Se regenera `supabase/migrations/002_seed_resources.sql`; el cambio SQL es únicamente el comentario de origen. Las 18 filas y el SQL ejecutable permanecen iguales.
- Se elimina `public/data/` al quedar vacío.

**Motivo:** evitar que los borradores editoriales incluidos en la semilla se puedan descargar directamente desde una URL pública. La comparación byte a byte confirma que el JSON trasladado conserva el mismo contenido.

**Contenido de la semilla:** 18 recursos: 16 publicados (10 datos curiosos, 5 herramientas y 1 guía) y 2 borradores. El endpoint público debe entregar solo los publicados.

### 2.2. Página administrativa inicial en `/admin`

**Archivos añadidos:**
- `public/admin.html`
- `public/js/admin.js`
- `public/css/admin.css`

**Funciones incorporadas:**
- Inicio de sesión con correo y contraseña.
- Validación de campos y presentación de errores comprensibles.
- Indicador de carga y prevención de envíos duplicados.
- Verificación de sesión mediante `GET /api/admin/session`.
- Almacenamiento del token en `sessionStorage` de la pestaña, con caducidad.
- Vista de reintento ante fallos temporales sin borrar automáticamente la sesión local.
- Resumen basado en `GET /api/admin/stats`.
- Cierre de sesión mediante `POST /api/admin/logout` y limpieza local.

**Rutas:** `/admin`, `/admin/` y `/admin.html` sirven la página administrativa.

**Seguridad:** el servidor continúa verificando sesión y rol `admin` para cada operación protegida. El frontend usa `textContent` para datos recibidos y no decide permisos por su cuenta. La CSP existente se mantiene; por eso estilos y scripts están en archivos externos.

**Límite funcional:** el panel es una primera versión con acceso, sesión y resumen. No incorpora todavía editores visuales completos de recursos, datos curiosos o noticias.

**Motivo:** permitir el acceso administrativo real sin reconstruir la autenticación o duplicar el backend existente.

### 2.3. Rutas y cabeceras de administración

**Cambio:**
- `netlify.toml` añade la redirección `/admin/` → `/admin.html`.
- Las rutas `/admin`, `/admin/` y `/admin.html` reciben `X-Robots-Tag: noindex, nofollow` y `Cache-Control: no-store`.
- `server.js` sirve `/admin/` de forma equivalente en local.

**Motivo:** ofrecer rutas coherentes para el acceso administrativo y reducir indexación y almacenamiento en caché de la página.

### 2.4. Comprobación estática `npm run check`

**Archivo añadido:** `scripts/check.mjs`.

Comprueba, entre otros aspectos:
- Archivos esenciales y `.gitignore`.
- Presencia y configuración de las funciones Netlify.
- Migraciones SQL y generador de semilla.
- Ubicación privada de `src/data/resources-seed.json` y ausencia de la semilla en `public/`.
- Correspondencia entre el JSON y la migración 002.
- Página administrativa y sus recursos.
- Redirecciones y cabeceras de Netlify.
- Referencias locales de HTML y compatibilidad con la CSP.
- Sintaxis de JavaScript/MJS y búsqueda de secretos evidentes.

El script es de solo lectura y admite `--root` para comprobar otra carpeta.

**Motivo:** detectar errores estructurales antes de integrar o desplegar nuevas versiones.

## 3. Archivos creados, movidos y modificados

### Creados

- `public/admin.html`
- `public/js/admin.js`
- `public/css/admin.css`
- `scripts/check.mjs`
- `tests/admin-page.test.mjs`
- `tests/check.test.mjs`
- `CHANGELOG_BLOQUE_2.md`
- `INFORME_CAMBIOS_BLOQUE_2.md`
- `VERSION.txt`

### Movidos

- `public/data/resources-seed.json` → `src/data/resources-seed.json` (contenido idéntico byte a byte).

### Modificados

- `scripts/build-seed.mjs`
- `supabase/migrations/002_seed_resources.sql` (solo comentario de origen).
- `netlify.toml`
- `server.js`
- `package.json` (versión 2.0.2; comandos existentes conservados).
- `README.md`
- `CHANGELOG.md`

### Conservados sin cambios funcionales

- `public/index.html`, `public/js/app.js`, `public/js/ai-chat.js`.
- `src/lib/rate-limit.mjs` y `src/config/environment.mjs`.
- Endpoints de chat, contacto, recursos y autenticación preexistentes.
- Migración 001 y los servicios existentes.

## 4. Pruebas realizadas

### Reproducidas en esta revisión

| Comando / comprobación | Resultado |
|---|---:|
| `npm test` | 61/61 aprobadas |
| `npm run check` | 40 correctas, 0 errores, 1 advertencia |
| `npm run seed:check` | Semilla al día |
| `npm run e2e` | Pendiente: falta `tests/e2e-smoke.mjs` |
| Integridad del ZIP | Correcta |
| Comparación del JSON trasladado | Idéntico byte a byte |

La advertencia de `npm run check` corresponde al comando E2E declarado sin su archivo de destino. No se creó una prueba E2E ficticia.

### Comprobación local HTTP realizada en esta revisión

Con el servidor local iniciado sin credenciales reales:

| Ruta | Resultado |
|---|---|
| `/admin` | 200 |
| `/admin/` | 200 |
| `/admin.html` | 200 |
| `/data/resources-seed.json` | 404 |
| `/src/data/resources-seed.json` | 404 |
| `/api/health` | 200, estado degradado por falta de servicios configurados |
| `/api/admin/session` | 503 controlado, Supabase no configurado |
| `/api/resources` | 503 controlado, Supabase no configurado |

El changelog original registra adicionalmente 31/31 comprobaciones de navegador con Chromium/Playwright usando Supabase simulado. Ese resultado procede de la ejecución documentada por el bloque; no equivale a una prueba con Supabase o Netlify reales.

## 5. Qué no se ha validado en servicios reales

- Inicio de sesión con una cuenta de Supabase Auth real.
- Políticas RLS en el proyecto Supabase del propietario.
- Despliegue en Netlify y aplicación efectiva de redirecciones y cabeceras.
- Acceso administrativo publicado mediante HTTPS.

## 6. Límites y pendientes

1. El token administrativo no tiene renovación automática; al vencer se solicita iniciar sesión de nuevo.
2. `sessionStorage` es accesible por JavaScript de la misma pestaña; se mantiene la CSP estricta y el renderizado seguro con `textContent`.
3. Los encabezados `noindex` y `no-store` para `/admin*` deben confirmarse en el despliegue Netlify real.
4. Despliegues o commits anteriores pueden seguir exponiendo la antigua ruta del JSON si aún están publicados; el nuevo despliegue deja de servirla.
5. Si la migración 002 ya se ejecutó en Supabase, no hace falta repetirla por el cambio de comentario.
6. `npm run e2e` sigue pendiente porque no se incluyó `tests/e2e-smoke.mjs`.
7. La carpeta `docs/` permanece vacía.
8. El panel aún no dispone de editores visuales completos para todas las áreas administrativas.

## 7. Integración

1. Usar este paquete como base de la siguiente etapa.
2. No repetir la migración 002 si ya está aplicada; el único cambio es el comentario.
3. Desplegar la versión actualizada para que la semilla deje de estar disponible en la ruta pública antigua.
4. Configurar las variables privadas en Netlify y probar `/admin` con una cuenta autorizada.
5. Ejecutar `npm test`, `npm run check` y `npm run seed:check` después de integrar.

---

**UNMUTE — Tu voz también merece ser escuchada.**
