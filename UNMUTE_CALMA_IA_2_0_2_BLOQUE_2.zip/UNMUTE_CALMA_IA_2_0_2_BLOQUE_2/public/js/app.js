/* ==========================================================
   UNMUTE · app.js
   Todo ocurre en este navegador: sin cuentas, sin servidor.
   Entradas: unmute_v2_entradas · Borrador: unmute_v2_borrador
   Preferencias: unmute_v2_prefs · Formato anterior (solo lectura): unmute_registros_v1
   ========================================================== */
(function(){
'use strict';
const $ = (s, r = document) => r.querySelector(s), $$ = (s, r = document) => [...r.querySelectorAll(s)];
function el(t, c, x, a){
  const e = document.createElement(t);
  if(c) e.className = c;
  if(x != null) e.textContent = x;
  if(a) for(const k in a) e.setAttribute(k, a[k]);
  return e;
}
const uid = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2, 10);
const norm = (s) => String(s).normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
const p2 = (n) => String(n).padStart(2, '0');
const dia = (iso) => { const d = new Date(iso); return d.getFullYear() + '-' + p2(d.getMonth() + 1) + '-' + p2(d.getDate()); };
const fFecha = (iso) => new Intl.DateTimeFormat('es', {weekday: 'long', day: 'numeric', month: 'long', year: 'numeric'}).format(new Date(iso));
const fHora = (iso) => new Intl.DateTimeFormat('es', {hour: '2-digit', minute: '2-digit'}).format(new Date(iso));

const K = {ent: 'unmute_v2_entradas', bor: 'unmute_v2_borrador', pref: 'unmute_v2_prefs', v1: 'unmute_registros_v1'};
const EMO = {muyfeliz: 'Muy feliz', feliz: 'Feliz', neutral: 'Neutral', triste: 'Triste', mal: 'Mal', enojado: 'Enojado', ansioso: 'Ansioso', cansado: 'Cansado'};
const MAXT = 20000, MAXTIT = 120, PAGE = 25;
const PREF0 = {tema: 'sistema', reducir: false, sinefectos: false, texto: 'normal', enfoque: false, recientes: []};
let entradas = [], borrador = null, prefs = {...PREF0}, protegido = false, avisoFijo = '';
const MSG_NO = 'No se pudo guardar en este navegador (almacenamiento lleno o bloqueado). Lo que escribes sigue aquí mientras no cierres la página: copia tu texto o descarga una copia desde Ajustes.';

/* ---------- Avisos ---------- */
function aviso(m){ const b = $('#aviso'); b.textContent = [avisoFijo, m].filter(Boolean).join(' '); b.hidden = !b.textContent; }
let tT;
function toast(m){ const t = $('#toast'); t.textContent = m; t.classList.add('on'); clearTimeout(tT); tT = setTimeout(() => t.classList.remove('on'), 3800); }

/* ---------- Lectura y escritura seguras ---------- */
function leer(k){ try{ return JSON.parse(localStorage.getItem(k)); }catch(e){ return null; } }
function escribir(k, v){ try{ localStorage.setItem(k, JSON.stringify(v)); return true; }catch(e){ return false; } }
function limpiarTags(a){
  if(!Array.isArray(a)) return [];
  const s = new Set(), o = [];
  a.forEach((t) => {
    if(typeof t !== 'string') return;
    t = t.trim().replace(/\s+/g, ' ').slice(0, 30);
    const k = norm(t);
    if(t && !s.has(k) && o.length < 12){ s.add(k); o.push(t); }
  });
  return o;
}
function valE(x){
  if(!x || typeof x !== 'object') return null;
  const c = new Date(x.creado); if(isNaN(c)) return null;
  const t = typeof x.texto === 'string' ? x.texto.slice(0, MAXT) : '', ti = typeof x.titulo === 'string' ? x.titulo.trim().slice(0, MAXTIT) : '';
  const m = EMO[x.mood] ? x.mood : null, n = Math.round(Number(x.intensidad));
  if(!(t.trim() || ti || m)) return null;
  const o = {id: (typeof x.id === 'string' && x.id && x.id.length < 80) ? x.id : uid(), creado: c.toISOString(), titulo: ti, texto: t, mood: m, intensidad: (m && n >= 1 && n <= 5) ? n : null, etiquetas: limpiarTags(x.etiquetas), favorito: x.favorito === true};
  const md = x.modificado ? new Date(x.modificado) : null;
  if(md && !isNaN(md)) o.modificado = md.toISOString();
  return o;
}
const migrar1 = (r) => (r && typeof r === 'object') ? {id: r.id, creado: r.fecha, modificado: r.editado, titulo: '', texto: r.texto, mood: r.mood, intensidad: r.intensidad, etiquetas: [], favorito: false} : null;
function respaldar(raw, msg){
  try{ localStorage.setItem(K.ent + '_copia_' + Date.now(), raw); avisoFijo = msg + ' Se guardó una copia sin modificar en este navegador.'; }
  catch(e){ protegido = true; avisoFijo = msg + ' No se pudo hacer una copia, así que no se guardarán cambios hasta resolverlo; puedes descargar lo que ves desde Ajustes.'; }
}
function sanear(a, raw){
  const ids = new Set(), out = [];
  a.forEach((x) => { const e = valE(x); if(!e) return; if(ids.has(e.id)) e.id = uid(); ids.add(e.id); out.push(e); });
  if(out.length < a.length) respaldar(raw, 'Se omitieron ' + (a.length - out.length) + ' entradas con formato inesperado.');
  return out;
}
function sanB(d){
  if(!d || typeof d !== 'object') return null;
  const t = typeof d.texto === 'string' ? d.texto.slice(0, MAXT) : '', ti = typeof d.titulo === 'string' ? d.titulo.slice(0, MAXTIT) : '';
  if(!t.trim() && !ti.trim()) return null;
  const m = EMO[d.mood] ? d.mood : null, n = Math.round(Number(d.intensidad));
  return {id: (typeof d.id === 'string' && d.id) ? d.id.slice(0, 80) : uid(), titulo: ti, texto: t, mood: m, intensidad: (m && n >= 1 && n <= 5) ? n : null, etiquetas: limpiarTags(d.etiquetas), editando: d.editando === true};
}
function sanP(p){
  const o = {...PREF0};
  if(['claro', 'oscuro', 'sistema'].includes(p.tema)) o.tema = p.tema;
  if(['pequeno', 'normal', 'grande'].includes(p.texto)) o.texto = p.texto;
  o.reducir = p.reducir === true; o.sinefectos = p.sinefectos === true; o.enfoque = p.enfoque === true;
  o.recientes = Array.isArray(p.recientes) ? p.recientes.filter(Number.isInteger).slice(-12) : [];
  return o;
}
function guardarEntradas(){
  if(protegido){ aviso(MSG_NO); return false; }
  const ok = escribir(K.ent, {v: 2, entradas}); aviso(ok ? '' : MSG_NO); return ok;
}
function persistirBorrador(){
  if(!borrador){ try{ localStorage.removeItem(K.bor); }catch(e){} return true; }
  return escribir(K.bor, borrador);
}
const guardarPrefs = () => escribir(K.pref, prefs);
function cargarTodo(){
  let raw = null;
  try{ raw = localStorage.getItem(K.ent); }
  catch(e){ protegido = true; avisoFijo = 'Este navegador no permite guardar datos locales (¿ventana privada o permisos bloqueados?). Puedes escribir, pero las entradas se perderán al cerrar la página: descarga una copia desde Ajustes antes de salir.'; return; }
  if(raw !== null){
    try{ const o = JSON.parse(raw), a = Array.isArray(o) ? o : o && o.entradas; if(!Array.isArray(a)) throw new Error('formato'); entradas = sanear(a, raw); }
    catch(e){ respaldar(raw, 'No se pudieron leer tus entradas guardadas.'); }
  }else{
    let v1 = null; try{ v1 = localStorage.getItem(K.v1); }catch(e){}
    if(v1){
      try{ const a = JSON.parse(v1); if(!Array.isArray(a)) throw new Error('formato'); entradas = sanear(a.map(migrar1), v1); guardarEntradas(); }
      catch(e){ respaldar(v1, 'No se pudieron leer tus registros anteriores.'); }
    }
  }
  borrador = sanB(leer(K.bor));
  const p = leer(K.pref); if(p && typeof p === 'object') prefs = sanP(p);
}

/* ---------- Diálogo de confirmación reutilizable (<dialog> nativo) ---------- */
function preguntar(o){
  return new Promise((res) => {
    const d = $('#dlg'), inp = $('#dlgI'), bar = $('#dlgB');
    $('#dlgT').textContent = o.t; $('#dlgX').textContent = o.x || '';
    $('#dlgL').replaceChildren(...(o.l || []).map((s) => el('li', 0, s)));
    $('#dlgIL').hidden = !o.tipear; inp.value = ''; if(o.tipear) $('#dlgIN').textContent = o.tipear;
    bar.replaceChildren(...o.a.map((a) => { const b = el('button', a.k || 'btn-sec', a.t, {type: 'button'}); if(a.s) b.dataset.s = '1'; b.onclick = () => d.close(a.v); return b; }));
    const sync = () => { if(o.tipear) $$('[data-s]', bar).forEach((b) => { b.disabled = norm(inp.value.trim()) !== norm(o.tipear); }); };
    inp.oninput = sync; sync();
    d.returnValue = ''; d.addEventListener('close', () => res(d.returnValue), {once: true}); d.showModal();
    (o.tipear ? inp : bar.firstChild).focus();
  });
}

/* ===== Parte B: frases, pistas, check-in y editor ===== */

/* Reglas de la biblioteca: sin promesas («todo va a salir bien»), sin moralejas,
   sin positividad forzada, sin hablar como profesional ni como persona.
   Se elige una al iniciar cada experiencia de escritura (no cambia mientras escribes)
   y no se repiten las últimas 12 mostradas. */
const FRASES = [
  'No todas las emociones necesitan una solución inmediata.', 'Sentir algo difícil no significa estar haciendo algo mal.',
  'No tienes que entenderlo todo para empezar a escribir.', 'Puedes ir a tu propio ritmo.',
  'Aquí no necesitas tener las palabras perfectas.', 'Lo que sientes merece ser escuchado, incluso si todavía no sabes nombrarlo.',
  'No tienes que convertir cada emoción en una lección.', 'Puedes escribir mucho, poco o no escribir hoy.',
  'No existe una forma correcta de sentir.', 'Tus emociones no son un examen que tengas que aprobar.',
  'Puedes reconocer lo que sientes sin juzgarte por ello.', 'A veces, una frase basta para empezar.',
  'No tienes que resolver hoy todo lo que te preocupa.', 'También está bien no saber qué necesitas.',
  'Puedes darte un momento antes de encontrar una respuesta.', 'No tienes que justificar cada cosa que sientes.',
  'Lo que escribas no necesita ser bonito para ser importante.', 'No estás obligado a encontrarle un sentido a todo.',
  'Puedes cambiar de opinión sobre lo que sientes.', 'Hay espacio para la incertidumbre.',
  'Puedes empezar por lo que pasó, por lo que piensas o por lo que no entiendes.', 'No necesitas sentirte bien para merecer un momento de calma.',
  'Es válido necesitar distancia, compañía o simplemente silencio.', 'No tienes que escribir todos los días para volver a este espacio.',
  'Hoy también puedes elegir no profundizar.', 'Puedes observar una emoción sin convertirla en toda tu identidad.',
  'Tus sentimientos pueden cambiar, y no tienes que anticipar cómo.', 'A veces, nombrar una pequeña parte es suficiente.',
  'No necesitas llegar a una conclusión al final de cada entrada.', 'Este momento puede ser imperfecto y seguir siendo tuyo.',
  'Puedes dejar una idea a medio escribir y volver cuando quieras.', 'No tienes que comparar tu día de hoy con el de ayer.',
  'Escucharte puede empezar por reconocer que estás cansado.', 'No todo lo que piensas necesita una respuesta inmediata.',
  'Puedes hacer una pausa antes de continuar.', 'Este espacio está pensado para expresarte sin exigirte respuestas.'
];
const PISTAS = {
  'Para soltar pensamientos': ['¿Qué no has podido dejar de pensar hoy?', '¿Qué te gustaría sacar de tu cabeza por un momento?', '¿Qué parte del día se te quedó dando vueltas?'],
  'Para reconocer necesidades': ['¿Qué necesitas ahora mismo, aunque sea algo pequeño?', '¿Qué te está faltando últimamente?', '¿Qué te ayudaría a sentirte un poco más acompañado?'],
  'Para observar el día': ['¿Qué momento recuerdas con más claridad?', '¿Qué te sorprendió de ti hoy?', '¿Hubo algo que te dio un poco de tranquilidad?'],
  'Para días confusos': ['¿Qué sabes de este momento y qué sigue siendo incierto?', '¿Qué estás sintiendo físicamente?', 'Si no tuvieras que encontrar una respuesta, ¿qué escribirías?'],
  'Para cerrar una entrada': ['¿Hay algo que quieras recordar de lo que acabas de escribir?', '¿Qué te gustaría dejar aquí por hoy?', '¿Prefieres cerrar con una idea, una pregunta o sin conclusión?']
};
let ed = {id: null, editando: false, mood: null, intensidad: null, etiquetas: []}, edAbierto = false, fraseDiario = null, enfoqueOn = false, guardando = false, tG = null, pIdx = -1;

function frase(){
  let i, n = 0;
  do{ i = Math.floor(Math.random() * FRASES.length); }while(prefs.recientes.includes(i) && ++n < 60);
  prefs.recientes = [...prefs.recientes, i].slice(-12); guardarPrefs();
  return '«' + FRASES[i] + '»';
}
const chipRadio = (name, val, txt) => { const l = el('label', 'chip'); l.append(el('input', 0, null, {type: 'radio', name, value: val}), el('span', 0, txt)); return l; };
Object.keys(EMO).forEach((k) => $('#ciEmo').append(chipRadio('ciEmo', k, EMO[k])));
[1, 2, 3, 4, 5].forEach((n) => $('#ciInt').append(chipRadio('ciInt', n, String(n))));
Object.keys(PISTAS).forEach((c) => $('#pCat').append(el('option', 0, c, {value: c})));

function estado(m, err){ const e = $('#edEstado'); e.textContent = m; e.classList.toggle('err', !!err); }
function nuevoEditor(){
  ed = {id: uid(), editando: false, mood: null, intensidad: null, etiquetas: []}; enfoqueOn = prefs.enfoque;
  $('#edTitulo').value = ''; $('#edTexto').value = ''; estado('');
  $('#pista').hidden = true; $('#edPista').setAttribute('aria-expanded', 'false');
}
function finFlujo(){ clearTimeout(tG); edAbierto = false; fraseDiario = null; borrador = null; persistirBorrador(); nuevoEditor(); aplicarFoco(); }
function leerEditor(){ return {id: ed.id, titulo: $('#edTitulo').value.trim().slice(0, MAXTIT), texto: $('#edTexto').value.slice(0, MAXT), mood: ed.mood, intensidad: ed.mood ? ed.intensidad : null, etiquetas: [...ed.etiquetas], editando: ed.editando}; }
function cargarEnEditor(b){
  ed = {id: b.id, editando: b.editando, mood: b.mood, intensidad: b.intensidad, etiquetas: [...b.etiquetas]};
  $('#edTitulo').value = b.titulo; $('#edTexto').value = b.texto; edAbierto = true; enfoqueOn = prefs.enfoque;
}

/* Borrador automático: espera 0,9 s tras dejar de escribir */
function guardarBorrador(){
  clearTimeout(tG);
  if(!edAbierto) return;
  const d = leerEditor();
  if(!d.titulo && !d.texto.trim()){ borrador = null; persistirBorrador(); estado(''); return; }
  estado('Guardando…'); borrador = d;
  const ok = persistirBorrador();
  estado(ok ? 'Borrador guardado en este dispositivo' : 'No se pudo guardar. Copia tu texto o vuelve a intentarlo.', !ok);
}
const programar = () => { clearTimeout(tG); tG = setTimeout(guardarBorrador, 900); };
$('#edTitulo').addEventListener('input', () => { estado('Escribiendo…'); programar(); });
$('#edTexto').addEventListener('input', () => { estado('Escribiendo…'); programar(); });

/* Check-in opcional */
function pintarCi(){
  $$('#ciEmo input').forEach((i) => { i.checked = i.value === ed.mood; });
  $$('#ciInt input').forEach((i) => { i.checked = ed.mood && Number(i.value) === ed.intensidad; });
  $('#ciIntBox').hidden = !ed.mood;
}
function mostrarCheckin(sabe){
  $('#checkin').hidden = false; $('#editor').hidden = true;
  $$('[data-ci=sabe],[data-ci=nosabe]').forEach((b) => b.setAttribute('aria-expanded', String(!!sabe && b.dataset.ci === 'sabe')));
  $('#ci-sabe').hidden = !sabe; $('#ci-nosabe').hidden = true;
  if(sabe) pintarCi();
}
$$('[data-ci]').forEach((b) => b.addEventListener('click', () => {
  const k = b.dataset.ci;
  if(k === 'sabe' || k === 'nosabe'){
    $('#ci-sabe').hidden = k !== 'sabe'; $('#ci-nosabe').hidden = k !== 'nosabe';
    $$('[data-ci=sabe],[data-ci=nosabe]').forEach((x) => x.setAttribute('aria-expanded', String(x.dataset.ci === k)));
    if(k === 'sabe') pintarCi();
  }else{ ed.mood = null; ed.intensidad = null; mostrarEditor(); }
}));
$('#ciEmo').addEventListener('change', () => { $('#ciIntBox').hidden = false; });
$('#ciQuitar').onclick = () => { $$('#ciEmo input,#ciInt input').forEach((i) => { i.checked = false; }); $('#ciIntBox').hidden = true; };
$('#ciSigue').onclick = () => {
  const m = $('#ciEmo input:checked'), n = $('#ciInt input:checked');
  ed.mood = m ? m.value : null; ed.intensidad = (m && n) ? Number(n.value) : null; mostrarEditor(); programar();
};
$$('[data-ini]').forEach((b) => b.addEventListener('click', () => {
  mostrarEditor(); const t = $('#edTexto');
  t.value = t.value.trim() ? t.value + '\n\n' + b.dataset.ini : b.dataset.ini;
  t.focus(); t.setSelectionRange(t.value.length, t.value.length); estado('Escribiendo…'); programar();
}));

/* Editor */
function aplicarFoco(){
  document.body.classList.toggle('enfoque', enfoqueOn && edAbierto && vista === 'diario');
  const b = $('#edFoco'); b.setAttribute('aria-pressed', String(enfoqueOn)); b.textContent = enfoqueOn ? 'Salir del modo sin distracciones' : 'Modo sin distracciones';
}
$('#edFoco').onclick = () => { enfoqueOn = !enfoqueOn; aplicarFoco(); $('#edTexto').focus(); };
function pintarSel(){
  const p = $('#edSel'); p.replaceChildren();
  const b = (t, f) => { const x = el('button', 'btn-quiet', t, {type: 'button'}); x.onclick = f; return x; };
  if(ed.mood){
    p.append('Registrarás: ' + EMO[ed.mood] + (ed.intensidad ? ' · intensidad ' + ed.intensidad + ' de 5' : '') + ' ',
      b('Cambiar', () => mostrarCheckin(true)), b('Quitar', () => { ed.mood = null; ed.intensidad = null; pintarSel(); programar(); }));
  }else p.append(b('Añadir cómo me siento (opcional)', () => mostrarCheckin(true)));
}
function pintarTags(){
  $('#edTagsList').replaceChildren(...ed.etiquetas.map((t) => {
    const b = el('button', 'tag', '#' + t + ' ×', {type: 'button', 'aria-label': 'Quitar etiqueta ' + t});
    b.onclick = () => { ed.etiquetas = ed.etiquetas.filter((x) => x !== t); pintarTags(); programar(); }; return b;
  }));
}
function agregarTag(){
  const i = $('#edTagIn'), v = limpiarTags([...ed.etiquetas, i.value]);
  if(v.length > ed.etiquetas.length){ ed.etiquetas = v; pintarTags(); programar(); }
  i.value = '';
}
$('#edTagAdd').onclick = agregarTag;
$('#edTagIn').onkeydown = (e) => { if(e.key === 'Enter' || e.key === ','){ e.preventDefault(); agregarTag(); } };
function mostrarEditor(){
  edAbierto = true; $('#checkin').hidden = true; $('#editor').hidden = false;
  $('#edModo').textContent = ed.editando ? 'Editando una entrada guardada' : 'Entrada nueva';
  $('#edCancelar').hidden = !ed.editando;
  pintarSel(); pintarTags(); aplicarFoco(); $('#edTexto').focus({preventScroll: true});
}
function entrarDiario(){
  if(!edAbierto){
    if(borrador){ cargarEnEditor(borrador); estado('Borrador recuperado.'); }
    else if(!ed.id) nuevoEditor();
  }
  const f = $('#fraseDiario'); f.hidden = ed.editando;
  if(!ed.editando) f.textContent = fraseDiario || (fraseDiario = frase());
  if(edAbierto) mostrarEditor(); else mostrarCheckin(false);
}

/* Pistas: una pregunta cada vez */
function otraPista(){
  const l = PISTAS[$('#pCat').value]; let i;
  do{ i = Math.floor(Math.random() * l.length); }while(l.length > 1 && i === pIdx);
  pIdx = i; $('#pTxt').textContent = l[i];
}
$('#edPista').onclick = () => {
  const p = $('#pista'), abrir = p.hidden; p.hidden = !abrir; $('#edPista').setAttribute('aria-expanded', String(abrir));
  if(abrir){ pIdx = -1; if(!$('#pCat').value) $('#pCat').selectedIndex = Math.floor(Math.random() * $('#pCat').options.length); otraPista(); }
};
$('#pCat').onchange = () => { pIdx = -1; otraPista(); };
$('#pOtra').onclick = otraPista;
$('#pOcultar').onclick = () => { $('#pista').hidden = true; $('#edPista').setAttribute('aria-expanded', 'false'); $('#edTexto').focus(); };

/* Guardar: la entrada conserva el id del borrador, así que guardar dos veces no duplica */
function guardarEntrada(){
  if(guardando) return;
  const d = leerEditor();
  if(!d.titulo && !d.texto.trim() && !d.mood){ estado('Escribe algo para guardar, o vuelve cuando quieras.'); return; }
  guardando = true; $('#edGuardar').disabled = true;
  const ahora = new Date().toISOString(), i = entradas.findIndex((x) => x.id === d.id);
  if(i >= 0) Object.assign(entradas[i], {titulo: d.titulo, texto: d.texto, mood: d.mood, intensidad: d.intensidad, etiquetas: d.etiquetas, modificado: ahora});
  else entradas.push({id: d.id, creado: ahora, titulo: d.titulo, texto: d.texto, mood: d.mood, intensidad: d.intensidad, etiquetas: d.etiquetas, favorito: false});
  const ok = guardarEntradas(); finFlujo();
  toast(ok ? 'Entrada guardada.' : 'Entrada guardada solo en esta página: no se pudo guardar en el navegador.');
  location.hash = '#historia';
  setTimeout(() => { guardando = false; $('#edGuardar').disabled = false; }, 600);
}
$('#edGuardar').onclick = guardarEntrada;
$('#edDescartar').onclick = async () => {
  const edit = ed.editando;
  if(!(await preguntar({t: '¿Descartar este borrador?', x: edit ? 'Se descartarán tus cambios. La entrada original se queda como está.' : 'Se borrará lo que escribiste en esta entrada. No se puede deshacer.', a: [{t: 'Seguir escribiendo', v: ''}, {t: 'Descartar borrador', v: 'ok', k: 'btn-pel'}]}))) return;
  finFlujo(); if(edit) location.hash = '#historia'; else mostrarCheckin(false);
};
$('#edCancelar').onclick = async () => {
  const d = leerEditor(), e = entradas.find((x) => x.id === d.id);
  const cambio = !e || e.titulo !== d.titulo || e.texto !== d.texto || e.mood !== d.mood || (e.intensidad || null) !== (d.intensidad || null) || e.etiquetas.join('|') !== d.etiquetas.join('|');
  if(cambio && !(await preguntar({t: '¿Descartar los cambios?', x: 'Los cambios de esta edición no se guardarán. La entrada original se queda como está.', a: [{t: 'Seguir editando', v: ''}, {t: 'Descartar cambios', v: 'ok', k: 'btn-pel'}]}))) return;
  finFlujo(); location.hash = '#historia';
};
async function editarEntrada(id){
  const e = entradas.find((x) => x.id === id); if(!e) return;
  const trabajo = edAbierto ? (ed.id !== id && ($('#edTitulo').value.trim() || $('#edTexto').value.trim())) : (borrador && borrador.id !== id);
  if(trabajo && !(await preguntar({t: 'Tienes un borrador sin guardar', x: 'Si editas esta entrada ahora, ese borrador se descartará.', a: [{t: 'Mejor no', v: ''}, {t: 'Descartar borrador y editar', v: 'ok', k: 'btn-pel'}]}))) return;
  if(edAbierto && ed.id === id){ location.hash = '#diario'; return; }
  if(!edAbierto && borrador && borrador.id === id){ cargarEnEditor(borrador); location.hash = '#diario'; return; }
  finFlujo();
  ed = {id: e.id, editando: true, mood: e.mood, intensidad: e.intensidad, etiquetas: [...e.etiquetas]};
  $('#edTitulo').value = e.titulo; $('#edTexto').value = e.texto; edAbierto = true;
  location.hash = '#diario';
}

/* ===== Parte C: Historia, Pausa, Ajustes, navegación ===== */
let vista = '';
const VISTAS = ['inicio', 'diario', 'acompanar', 'historia', 'pausa', 'ajustes'];
const firma = (e) => e.creado + '|' + e.titulo + '|' + e.texto;
function entrarInicio(){ $('#fraseInicio').textContent = frase(); $('#retomar').hidden = !borrador; }

/* ---------- Historia: búsqueda, filtros, favoritas y etiquetas ---------- */
const hf = {q: '', desde: '', hasta: '', emo: '', tag: '', fav: false, orden: 'desc'};
let limite = PAGE, tF = null, lecId = null;
Object.keys(EMO).forEach((k) => $('#hEmo').append(el('option', 0, EMO[k], {value: k})));
function todasTags(){
  const s = new Map();
  entradas.forEach((e) => e.etiquetas.forEach((t) => { if(!s.has(norm(t))) s.set(norm(t), t); }));
  return [...s.values()].sort((a, b) => a.localeCompare(b, 'es'));
}
function llenarTags(){
  const t = todasTags(), s = $('#hTag'), v = s.value;
  $('#tagsDL').replaceChildren(...t.map((x) => el('option', 0, null, {value: x})));
  s.replaceChildren(el('option', 0, 'Todas', {value: ''}), ...t.map((x) => el('option', 0, x, {value: x})));
  s.value = t.includes(v) ? v : ''; hf.tag = s.value;
}
function filtradas(){
  const q = norm(hf.q.trim()), tg = norm(hf.tag);
  const l = entradas.filter((e) => (!q || norm(e.titulo + ' ' + e.texto + ' ' + e.etiquetas.join(' ')).includes(q)) && (!hf.emo || e.mood === hf.emo) && (!tg || e.etiquetas.some((t) => norm(t) === tg)) && (!hf.fav || e.favorito) && (!hf.desde || dia(e.creado) >= hf.desde) && (!hf.hasta || dia(e.creado) <= hf.hasta));
  l.sort((a, b) => a.creado.localeCompare(b.creado));
  return hf.orden === 'desc' ? l.reverse() : l;
}
function vacio(t, href, btn){
  const d = el('div', 'vacio'); d.append(el('p', 0, t));
  if(href){ const w = el('p'); w.append(el('a', 'btn', btn, {href})); d.append(w); }
  return d;
}
function tarjeta(e){
  const a = el('article', 'entrada'), h = el('h3'), b = el('button', 'titulo-e', e.titulo || 'Entrada sin título', {type: 'button'}), m = el('p', 'meta');
  b.onclick = () => abrirLector(e.id); h.append(b);
  m.append(el('time', 0, fFecha(e.creado) + ' · ' + fHora(e.creado), {datetime: e.creado}));
  if(e.favorito) m.append(' · ★ Favorita');
  a.append(h, m);
  const f = e.texto.replace(/\s+/g, ' ').trim();
  if(f) a.append(el('p', 'frag', f.length > 170 ? f.slice(0, 170) + '…' : f));
  const c = [];
  if(e.mood) c.push(el('span', 'etq emo', EMO[e.mood] + (e.intensidad ? ' · intensidad ' + e.intensidad + ' de 5' : '')));
  e.etiquetas.forEach((t) => c.push(el('span', 'etq', '#' + t)));
  if(c.length){ const w = el('p', 'tags'); w.append(...c); a.append(w); }
  return a;
}
function mostrarHistoria(){
  llenarTags();
  const L = $('#hLista'), n = entradas.length; L.replaceChildren(); $('#hMas').hidden = true;
  if(!n){ $('#hInfo').textContent = ''; L.append(vacio('Todavía no hay entradas. Cuando quieras, una sola frase es suficiente para empezar.', '#diario', 'Escribir una entrada')); return; }
  const l = filtradas();
  $('#hInfo').textContent = l.length === n ? n + (n === 1 ? ' entrada.' : ' entradas.') : 'Mostrando ' + l.length + ' de ' + n + ' entradas.';
  if(!l.length){
    const v = vacio('No encontramos entradas con esa búsqueda o esos filtros. Prueba con otras palabras o quita algún filtro.'), b = el('button', 'btn-sec', 'Quitar filtros', {type: 'button'});
    b.onclick = limpiarFiltros; v.append(b); L.append(v); return;
  }
  L.append(...l.slice(0, limite).map(tarjeta));
  if(l.length > limite){ $('#hMas').hidden = false; $('#hMas').textContent = 'Mostrar más (' + (l.length - limite) + ')'; }
}
function leerFiltros(){
  hf.q = $('#hBuscar').value; hf.desde = $('#hDesde').value; hf.hasta = $('#hHasta').value; hf.emo = $('#hEmo').value;
  hf.tag = $('#hTag').value; hf.fav = $('#hFav').checked; hf.orden = $('#hOrden').value; limite = PAGE; mostrarHistoria();
}
function limpiarFiltros(){
  ['#hBuscar', '#hDesde', '#hHasta'].forEach((s) => { $(s).value = ''; });
  $('#hEmo').value = ''; $('#hTag').value = ''; $('#hFav').checked = false; $('#hOrden').value = 'desc'; leerFiltros();
}
['#hBuscar', '#hDesde', '#hHasta'].forEach((s) => $(s).addEventListener('input', () => { clearTimeout(tF); tF = setTimeout(leerFiltros, 180); }));
['#hEmo', '#hTag', '#hFav', '#hOrden'].forEach((s) => $(s).addEventListener('change', leerFiltros));
$('#hLimpiar').onclick = limpiarFiltros;
$('#hMas').onclick = () => { limite += PAGE; mostrarHistoria(); $('#hMas').focus(); };

/* ---------- Lector de una entrada ---------- */
const ent = () => entradas.find((x) => x.id === lecId);
function pintarLector(){
  const e = ent(); if(!e) return;
  $('#lTit').textContent = e.titulo || 'Entrada sin título';
  $('#lMeta').textContent = 'Escrita el ' + fFecha(e.creado) + ' a las ' + fHora(e.creado) + (e.modificado ? ' · Editada el ' + fFecha(e.modificado) + ' a las ' + fHora(e.modificado) : '');
  const m = $('#lEmo'); m.parentElement.hidden = !e.mood; m.textContent = e.mood ? EMO[e.mood] + (e.intensidad ? ' · intensidad ' + e.intensidad + ' de 5' : '') : '';
  $('#lTxt').textContent = e.texto || '(Esta entrada no tiene texto.)';
  $('#lFav').setAttribute('aria-pressed', String(e.favorito));
  $('#lTags').replaceChildren(...e.etiquetas.map((t) => {
    const b = el('button', 'tag', '#' + t + ' ×', {type: 'button', 'aria-label': 'Quitar etiqueta ' + t});
    b.onclick = () => { e.etiquetas = e.etiquetas.filter((x) => x !== t); cambioMeta(); }; return b;
  }));
}
function cambioMeta(){ guardarEntradas(); pintarLector(); mostrarHistoria(); }
function abrirLector(id){ lecId = id; pintarLector(); $('#lector').showModal(); }
$('#lFav').onclick = () => { const e = ent(); if(e){ e.favorito = !e.favorito; cambioMeta(); } };
function addTagL(){ const e = ent(), i = $('#lTagIn'); if(e){ e.etiquetas = limpiarTags([...e.etiquetas, i.value]); cambioMeta(); } i.value = ''; }
$('#lTagAdd').onclick = addTagL;
$('#lTagIn').onkeydown = (e) => { if(e.key === 'Enter' || e.key === ','){ e.preventDefault(); addTagL(); } };
$('#lCerrar').onclick = () => $('#lector').close();
$('#lEdit').onclick = () => { $('#lector').close(); editarEntrada(lecId); };
$('#lDel').onclick = async () => {
  const e = ent(); if(!e) return;
  const ok = await preguntar({t: '¿Eliminar esta entrada?', x: 'Se borrará «' + (e.titulo || 'Entrada sin título') + '», escrita el ' + fFecha(e.creado) + '. No se puede deshacer.', a: [{t: 'Cancelar', v: ''}, {t: 'Eliminar entrada', v: 'ok', k: 'btn-pel'}]});
  if(!ok) return;
  entradas = entradas.filter((x) => x.id !== e.id); const g = guardarEntradas();
  $('#lector').close(); mostrarHistoria(); $('#t-historia').focus();
  toast(g ? 'Entrada eliminada.' : 'Entrada eliminada solo en esta página: no se pudo guardar el cambio.');
};

/* ---------- Pausa ---------- */
let rT = null, rN = 0, gI = -1, wI = null, wR = 0;
function respirar(on, silencio){
  clearTimeout(rT);
  const c = $('#rCirc'), t = $('#rTxt'), b = $('#rBtn'); c.className = ''; b.setAttribute('aria-pressed', String(on)); b.textContent = on ? 'Detener' : 'Empezar';
  if(!on){ t.textContent = silencio ? 'Cuando quieras, empieza. Respira a tu ritmo.' : 'Hecho. Puedes volver cuando quieras.'; return; }
  rN = 0;
  const paso = () => {
    const inh = rN % 2 === 0; c.className = inh ? 'in' : 'out';
    t.textContent = inh ? 'Inhala' : (rN >= 5 ? 'Exhala. Continúa a tu ritmo' : 'Exhala');
    rT = setTimeout(() => { rN++; paso(); }, inh ? 4500 : 6000);
  };
  paso();
}
$('#rBtn').onclick = () => respirar($('#rBtn').getAttribute('aria-pressed') !== 'true');
const PASOS = ['Observa a tu alrededor y encuentra tres cosas que puedes ver.', 'Ahora nota dos cosas que puedes sentir físicamente: la ropa, el suelo, el aire en tu piel.', 'Por último, escucha y encuentra un sonido, el más cercano o el más lejano.'];
function salirG(m){ gI = -1; $('#gTxt').textContent = m || 'Un ejercicio breve para observar lo que te rodea. Puedes adaptarlo o dejarlo cuando quieras.'; $('#gBtn').textContent = 'Empezar'; $('#gSalir').hidden = true; }
$('#gBtn').onclick = () => {
  gI++;
  if(gI < PASOS.length){ $('#gTxt').textContent = 'Paso ' + (gI + 1) + ' de 3. ' + PASOS[gI]; $('#gBtn').textContent = gI < PASOS.length - 1 ? 'Siguiente' : 'Terminar'; $('#gSalir').hidden = false; }
  else salirG('Gracias por darte este momento. Puedes volver cuando quieras.');
};
$('#gSalir').onclick = () => salirG();
function wFin(m){ clearInterval(wI); wI = null; $('#wBtn').textContent = 'Empezar temporizador'; if(m) $('#wEstado').textContent = m; }
$('#wBtn').onclick = () => {
  if(wI){ wFin('Temporizador detenido. Tu texto sigue aquí.'); return; }
  const d = Number($('#wDur').value); $('#wTxt').focus();
  if(!d){ $('#wEstado').textContent = 'Sin temporizador: escribe el tiempo que quieras.'; return; }
  wR = d; $('#wEstado').textContent = 'Empezaste. Escribe sin editar ni corregir.';
  const pintar = () => { $('#wBtn').textContent = 'Detener · ' + Math.floor(wR / 60) + ':' + p2(wR % 60); }; pintar();
  wI = setInterval(() => { wR--; if(wR <= 0) wFin('El tiempo terminó. Puedes seguir escribiendo si quieres.'); else pintar(); }, 1000);
};
$('#wGuardar').onclick = () => {
  const t = $('#wTxt').value.trim();
  if(!t){ $('#wEstado').textContent = 'Escribe algo primero para poder guardarlo.'; return; }
  entradas.push({id: uid(), creado: new Date().toISOString(), titulo: '', texto: t.slice(0, MAXT), mood: null, intensidad: null, etiquetas: [], favorito: false});
  const ok = guardarEntradas(); $('#wTxt').value = ''; wFin(ok ? 'Guardado como entrada en tu diario.' : 'Guardado solo en esta página: no se pudo guardar en el navegador.');
  toast('Entrada guardada.');
};
$('#wVaciar').onclick = async () => {
  if(!$('#wTxt').value.trim()) return;
  if(await preguntar({t: '¿Vaciar el texto?', x: 'Este texto no está guardado en ningún sitio. Si lo vacías, no podrás recuperarlo.', a: [{t: 'Cancelar', v: ''}, {t: 'Vaciar texto', v: 'ok', k: 'btn-pel'}]})){ $('#wTxt').value = ''; wFin('Texto vaciado.'); }
};

/* ---------- Ajustes ---------- */
function aplicarPrefs(){
  const h = document.documentElement;
  h.dataset.tema = prefs.tema === 'sistema' ? (matchMedia('(prefers-color-scheme:dark)').matches ? 'oscuro' : 'claro') : prefs.tema;
  h.dataset.texto = prefs.texto; h.dataset.calma = prefs.reducir ? '1' : ''; h.dataset.efectos = prefs.sinefectos ? 'off' : 'on';
}
matchMedia('(prefers-color-scheme:dark)').addEventListener('change', () => { if(prefs.tema === 'sistema') aplicarPrefs(); });
function pintarAjustes(){
  $$('input[name=tema]').forEach((r) => { r.checked = r.value === prefs.tema; });
  $$('input[name=texto]').forEach((r) => { r.checked = r.value === prefs.texto; });
  $('#pReducir').checked = prefs.reducir; $('#pEfectos').checked = prefs.sinefectos; $('#pEnfoque').checked = prefs.enfoque;
}
$$('input[name=tema],input[name=texto]').forEach((r) => { r.onchange = () => { prefs[r.name] = r.value; aplicarPrefs(); guardarPrefs(); }; });
[['#pReducir', 'reducir'], ['#pEfectos', 'sinefectos'], ['#pEnfoque', 'enfoque']].forEach(([s, k]) => { $(s).onchange = (e) => { prefs[k] = e.target.checked; aplicarPrefs(); guardarPrefs(); }; });
$$('[data-priv]').forEach((b) => { b.onclick = () => $('#dlgPriv').showModal(); });
$('#privCerrar').onclick = () => $('#dlgPriv').close();

/* ---------- Copia, importación y borrado ---------- */
$('#bExport').onclick = () => {
  if(!entradas.length){ toast('Aún no hay entradas para descargar.'); return; }
  const data = {app: 'UNMUTE', v: 2, exportado: new Date().toISOString(), entradas, prefs: {tema: prefs.tema, reducir: prefs.reducir, sinefectos: prefs.sinefectos, texto: prefs.texto, enfoque: prefs.enfoque}};
  const a = el('a', 0, null, {href: URL.createObjectURL(new Blob([JSON.stringify(data, null, 2)], {type: 'application/json'})), download: 'unmute-copia-' + dia(new Date().toISOString()) + '.json'});
  document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1500);
  toast('Copia descargada. Guárdala en un lugar seguro.');
};
$('#bImport').onclick = () => $('#fImport').click();
$('#fImport').onchange = async (ev) => {
  const f = ev.target.files[0]; ev.target.value = ''; if(!f) return;
  let arr = null;
  try{
    if(f.size > 8e6) throw new Error('grande');
    const j = JSON.parse(await f.text());
    if(Array.isArray(j)) arr = j.map((x) => (x && x.creado) ? x : migrar1(x));
    else if(j && j.app === 'UNMUTE' && Array.isArray(j.entradas)) arr = j.entradas;
    else if(j && j.app === 'UNMUTE' && Array.isArray(j.registros)) arr = j.registros.map(migrar1);
  }catch(x){ arr = null; }
  if(!arr){ toast('Ese archivo no es una copia compatible de UNMUTE. No se cambió nada.'); return; }
  const ids = new Set(entradas.map((x) => x.id)), sig = new Set(entradas.map(firma)), nuevos = [], todas = [], ids2 = new Set(); let dup = 0, mal = 0;
  arr.forEach((x) => {
    const v = valE(x); if(!v){ mal++; return; }
    if(!ids2.has(v.id)){ ids2.add(v.id); todas.push(v); }
    if(ids.has(v.id) || sig.has(firma(v))){ dup++; return; }
    ids.add(v.id); sig.add(firma(v)); nuevos.push(v);
  });
  if(!nuevos.length){ toast(dup ? 'Todas las entradas del archivo ya estaban en tu diario. No se cambió nada.' : 'El archivo no contiene entradas válidas. No se cambió nada.'); return; }
  const r = await preguntar({t: 'Importar copia', x: 'Revisa el resumen. Nada cambia hasta que elijas una opción.', l: [nuevos.length + ' entradas nuevas', dup + ' ya existen y se omitirán', mal + ' con formato inválido se omitirán', 'Las preferencias del archivo no se importan'], a: [{t: 'Cancelar', v: ''}, {t: 'Combinar con mis entradas', v: 'merge', k: 'btn'}, {t: 'Reemplazar todo', v: 'replace', k: 'btn-pel'}]});
  if(r === 'merge') entradas = entradas.concat(nuevos);
  else if(r === 'replace'){
    if(!(await preguntar({t: '¿Reemplazar tus entradas?', x: 'Tus ' + entradas.length + ' entradas actuales se sustituirán por las ' + todas.length + ' del archivo. Antes se guardará una copia interna de lo que tienes ahora.', a: [{t: 'Cancelar', v: ''}, {t: 'Sí, reemplazar', v: 'ok', k: 'btn-pel'}]}))) return;
    try{ localStorage.setItem(K.ent + '_copia_' + Date.now(), JSON.stringify({v: 2, entradas})); }catch(e){}
    entradas = todas;
  }else return;
  const ok = guardarEntradas(); mostrarHistoria();
  toast(ok ? 'Importación completada.' : 'Importado solo en esta página: no se pudo guardar en el navegador.');
};
$('#bBorrador').onclick = async () => {
  if(!borrador && !$('#edTexto').value.trim() && !$('#edTitulo').value.trim()){ toast('No tienes ningún borrador guardado.'); return; }
  if(!(await preguntar({t: '¿Eliminar tu borrador?', x: 'Se borrará el texto que no has guardado como entrada. No se puede deshacer.', a: [{t: 'Cancelar', v: ''}, {t: 'Eliminar borrador', v: 'ok', k: 'btn-pel'}]}))) return;
  finFlujo(); toast('Borrador eliminado.');
};
$('#bTodo').onclick = async () => {
  const r = await preguntar({t: '¿Eliminar todos tus datos?', x: 'Se borrarán de este navegador todas tus entradas, tu borrador, tus preferencias y las copias internas de UNMUTE. No se puede deshacer. Te recomendamos descargar antes una copia, aunque no es obligatorio.', tipear: 'ELIMINAR', a: [{t: 'Cancelar', v: ''}, {t: 'Eliminar todo', v: 'ok', k: 'btn-pel', s: 1}]});
  if(!r) return;
  try{ Object.keys(localStorage).filter((k) => k.startsWith('unmute_')).forEach((k) => localStorage.removeItem(k)); }
  catch(e){ toast('No se pudieron borrar los datos de este navegador.'); return; }
  entradas = []; prefs = {...PREF0, recientes: []}; protegido = false; avisoFijo = ''; aviso('');
  finFlujo(); aplicarPrefs(); pintarAjustes(); mostrarHistoria(); toast('Se eliminaron todos tus datos de UNMUTE.');
};

/* ---------- Navegación e inicio ---------- */
function ir(v){
  if(!VISTAS.includes(v)) v = 'inicio';
  if(vista === 'diario' && edAbierto) guardarBorrador();
  if(vista === 'pausa'){ respirar(false, true); wFin(); }
  vista = v;
  VISTAS.forEach((n) => { $('#v-' + n).hidden = n !== v; });
  $$('nav.principal a').forEach((a) => { if(a.dataset.v === v) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current'); });
  ({inicio: entrarInicio, diario: entrarDiario, historia: mostrarHistoria, ajustes: pintarAjustes}[v] || (() => {}))();
  aplicarFoco();
  const h = $('#t-' + v); document.title = h.textContent + ' · UNMUTE'; window.scrollTo(0, 0); h.focus({preventScroll: true});
}
cargarTodo(); aplicarPrefs(); aviso('');
$('#gTxt').setAttribute('aria-live', 'polite');
window.addEventListener('hashchange', () => ir(location.hash.slice(1)));
window.addEventListener('beforeunload', () => guardarBorrador());
document.addEventListener('visibilitychange', () => { if(document.hidden) guardarBorrador(); });
ir(location.hash.slice(1) || 'inicio');
})();
