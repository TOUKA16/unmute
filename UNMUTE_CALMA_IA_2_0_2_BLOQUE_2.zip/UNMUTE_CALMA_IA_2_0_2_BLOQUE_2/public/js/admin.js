/* ==========================================================
   UNMUTE · Administración (versión inicial: acceso y panel base)
   Esta página NO decide quién es administrador. Solo:
   · envía el correo y la contraseña a POST /api/admin/login,
   · guarda el token que devuelve el servidor y lo envía como «Authorization: Bearer»,
   · muestra el panel únicamente cuando GET /api/admin/session responde 200.
   Cada operación protegida vuelve a ser verificada por el servidor (token + rol 'admin' en Supabase).
   Sin librerías, sin innerHTML: todo lo que viene del servidor se escribe con textContent.
   ========================================================== */
(function () {
  'use strict';

  var CLAVE = 'unmute_admin_sesion'; // sessionStorage: solo esta pestaña; se borra al cerrarla
  var TIMEOUT_MS = 15000;
  var MAX_TIMER = 2147483647; // límite de setTimeout
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

  function $(id) { return document.getElementById(id); }
  var vistas = { cargando: $('v-cargando'), login: $('v-login'), error: $('v-error'), panel: $('v-panel') };
  var f = $('fLogin');
  var estado = { token: null, expiraEn: 0, usuario: null, verificadoEn: null, temporizador: null, enviando: false, saliendo: false, verificando: false };

  /* ---------- Almacenamiento de la sesión (solo token y caducidad) ---------- */
  function leerSesion() {
    try {
      var s = JSON.parse(sessionStorage.getItem(CLAVE) || 'null');
      if (s && typeof s.token === 'string' && s.token && typeof s.expiraEn === 'number') return s;
    } catch (_e) { /* almacenamiento no disponible o contenido inválido */ }
    return null;
  }
  function guardarSesion(token, expiraEn) {
    try { sessionStorage.setItem(CLAVE, JSON.stringify({ token: token, expiraEn: expiraEn })); } catch (_e) { /* la sesión seguirá solo en memoria */ }
  }
  function borrarSesion() {
    try { sessionStorage.removeItem(CLAVE); } catch (_e) { /* nada que borrar */ }
    if (estado.temporizador) { clearTimeout(estado.temporizador); estado.temporizador = null; }
    estado.token = null; estado.expiraEn = 0; estado.usuario = null; estado.verificadoEn = null;
  }

  /* ---------- Vistas ---------- */
  function mostrar(nombre) {
    Object.keys(vistas).forEach(function (k) { vistas[k].hidden = k !== nombre; });
    var h1 = vistas[nombre].querySelector('h1');
    if (h1) h1.focus({ preventScroll: false });
  }
  function texto(el, valor) { el.textContent = valor; el.hidden = !valor; }
  function hora(ms) { return new Date(ms).toLocaleTimeString('es', { hour: '2-digit', minute: '2-digit' }); }

  function irAlLogin(aviso) {
    borrarSesion();
    f.reset();
    limpiarErrores();
    texto($('loginAviso'), aviso || '');
    mostrar('login');
  }

  /* ---------- Llamadas a la API ---------- */
  function api(ruta, opciones) {
    opciones = opciones || {};
    var ctl = new AbortController();
    var t = setTimeout(function () { ctl.abort(); }, TIMEOUT_MS);
    var cabeceras = {};
    if (opciones.cuerpo !== undefined) cabeceras['Content-Type'] = 'application/json';
    if (opciones.token) cabeceras.Authorization = 'Bearer ' + opciones.token;
    return fetch(ruta, {
      method: opciones.metodo || 'GET',
      headers: cabeceras,
      body: opciones.cuerpo !== undefined ? JSON.stringify(opciones.cuerpo) : undefined,
      cache: 'no-store',
      credentials: 'omit',
      signal: ctl.signal
    }).then(function (res) {
      return res.text().then(function (t) {
        var datos = null;
        try { datos = JSON.parse(t); } catch (_e) { /* respuesta sin JSON */ }
        return { status: res.status, datos: datos || {}, reintentarEn: Number(res.headers.get('Retry-After')) || 0 };
      });
    }).catch(function () {
      return { status: 0, datos: {}, reintentarEn: 0 }; // sin conexión, tiempo agotado o respuesta ilegible
    }).then(function (r) { clearTimeout(t); return r; });
  }

  function mensajeDe(r, porDefecto) {
    // Los mensajes de error del backend son públicos y controlados (AppError); los 500 usan el genérico.
    if (r.status >= 400 && r.status < 500 || r.status === 503) {
      if (typeof r.datos.error === 'string' && r.datos.error) return r.datos.error;
    }
    if (r.status === 0) return 'No hay conexión con el servidor. Revisa tu conexión e inténtalo de nuevo.';
    return porDefecto;
  }

  /* ---------- Formulario de inicio de sesión ---------- */
  function limpiarErrores() {
    ['admEmail', 'admPass'].forEach(function (id) { $(id).removeAttribute('aria-invalid'); });
    texto($('admEmailErr'), ''); texto($('admPassErr'), ''); texto($('loginError'), '');
  }
  function errorCampo(inputId, errId, msg) {
    $(inputId).setAttribute('aria-invalid', 'true');
    texto($(errId), msg);
  }
  function ocupado(si) {
    estado.enviando = si;
    var b = $('btnLogin');
    b.disabled = si;
    b.setAttribute('aria-busy', si ? 'true' : 'false');
    b.textContent = si ? 'Iniciando sesión…' : 'Iniciar sesión';
  }

  f.addEventListener('submit', function (e) {
    e.preventDefault();
    if (estado.enviando) return; // evita envíos duplicados (doble clic o Enter repetido)
    limpiarErrores();
    $('loginAviso').hidden = true;

    var email = $('admEmail').value.trim();
    var password = $('admPass').value;
    var primero = null;
    if (!EMAIL_RE.test(email) || email.length > 120) { errorCampo('admEmail', 'admEmailErr', 'Escribe un correo válido.'); primero = primero || $('admEmail'); }
    if (!password) { errorCampo('admPass', 'admPassErr', 'Escribe tu contraseña.'); primero = primero || $('admPass'); }
    if (primero) { primero.focus(); return; }

    ocupado(true);
    api('/api/admin/login', { metodo: 'POST', cuerpo: { email: email, password: password } }).then(function (r) {
      ocupado(false);
      if (r.status === 200 && r.datos.accessToken && r.datos.user) {
        $('admPass').value = ''; // la contraseña no se conserva ni un instante más de lo necesario
        var dur = Number(r.datos.expiresIn);
        var expiraEn = Date.now() + (dur > 0 ? dur : 3600) * 1000;
        guardarSesion(r.datos.accessToken, expiraEn);
        entrar(r.datos.accessToken, expiraEn, r.datos.user);
        return;
      }
      $('admPass').value = '';
      var campos = r.datos.fields || {};
      if (r.status === 400 && (campos.email || campos.password)) {
        if (campos.email) errorCampo('admEmail', 'admEmailErr', String(campos.email));
        if (campos.password) errorCampo('admPass', 'admPassErr', String(campos.password));
        (campos.email ? $('admEmail') : $('admPass')).focus();
        return;
      }
      var msg;
      if (r.status === 429) {
        var min = r.reintentarEn ? Math.max(1, Math.ceil(r.reintentarEn / 60)) : 0;
        msg = 'Demasiados intentos de inicio de sesión.' + (min ? ' Vuelve a intentarlo en unos ' + min + ' min.' : ' Espera unos minutos.');
      } else {
        msg = mensajeDe(r, 'No se pudo iniciar sesión. Inténtalo de nuevo en unos minutos.');
      }
      texto($('loginError'), msg);
      $('admPass').focus();
    });
  });

  /* ---------- Entrada al panel ---------- */
  function entrar(token, expiraEn, usuario) {
    estado.token = token; estado.expiraEn = expiraEn; estado.usuario = usuario; estado.verificadoEn = Date.now();
    if (estado.temporizador) clearTimeout(estado.temporizador);
    // Solo comodidad: el servidor rechaza el token vencido aunque este temporizador no existiera.
    estado.temporizador = setTimeout(function () { sesionVencida(); }, Math.min(Math.max(expiraEn - Date.now(), 0), MAX_TIMER));
    $('admUsuario').textContent = (usuario && usuario.email) || '';
    $('sesCuenta').textContent = (usuario && usuario.email) || '';
    pintarSesion();
    seleccionarSeccion('resumen');
    mostrar('panel');
    cargarStats();
  }

  function pintarSesion() {
    $('sesVerif').textContent = estado.verificadoEn ? 'Confirmada por el servidor a las ' + hora(estado.verificadoEn) : '—';
    $('sesVence').textContent = estado.expiraEn ? 'Hacia las ' + hora(estado.expiraEn) + ' (el servidor decide la validez real)' : '—';
  }

  function sesionVencida() {
    if (!vistas.panel.hidden || estado.token) irAlLogin('Tu sesión venció. Inicia sesión de nuevo.');
  }

  /* ---------- Navegación del panel ---------- */
  function seleccionarSeccion(nombre) {
    document.querySelectorAll('.adm-nav [data-sec]').forEach(function (b) {
      if (b.dataset.sec === nombre) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current');
    });
    $('s-resumen').hidden = nombre !== 'resumen';
    $('s-sesion').hidden = nombre !== 'sesion';
    if (nombre === 'sesion') pintarSesion();
  }
  document.querySelectorAll('.adm-nav [data-sec]').forEach(function (b) {
    b.addEventListener('click', function () { seleccionarSeccion(b.dataset.sec); });
  });

  /* ---------- Resumen (GET /api/admin/stats, protegido en el servidor) ---------- */
  var ETIQUETAS_RECURSOS = [['total', 'Total'], ['published', 'Publicados'], ['draft', 'Borradores'], ['archived', 'Archivados']];
  var ETIQUETAS_MENSAJES = [['total', 'Total'], ['new', 'Nuevos'], ['read', 'Leídos'], ['resolved', 'Resueltos'], ['archived', 'Archivados']];

  function pintarLista(dl, datos, etiquetas) {
    dl.textContent = '';
    etiquetas.forEach(function (par) {
      var caja = document.createElement('div');
      var dt = document.createElement('dt'); dt.textContent = par[1];
      var dd = document.createElement('dd'); dd.textContent = String(Number.isFinite(datos[par[0]]) ? datos[par[0]] : 0);
      caja.appendChild(dt); caja.appendChild(dd); dl.appendChild(caja);
    });
  }

  function cargarStats() {
    var token = estado.token;
    var est = $('statsEstado');
    est.classList.remove('err');
    est.textContent = 'Cargando…';
    $('btnStats').disabled = true;
    return api('/api/admin/stats', { token: token }).then(function (r) {
      if (token !== estado.token) return; // la sesión cambió mientras tanto
      $('btnStats').disabled = false;
      if (!rechazoDeSesion(r)) {
        if (r.status === 200 && r.datos.resources && r.datos.messages) {
          pintarLista($('statsRecursos'), r.datos.resources, ETIQUETAS_RECURSOS);
          var fact = (r.datos.resources.byType && r.datos.resources.byType.fact) || {};
          var extra = document.createElement('div');
          var dt = document.createElement('dt'); dt.textContent = 'Datos curiosos publicados';
          var dd = document.createElement('dd'); dd.textContent = String(fact.published || 0);
          extra.appendChild(dt); extra.appendChild(dd); $('statsRecursos').appendChild(extra);
          pintarLista($('statsMensajes'), r.datos.messages, ETIQUETAS_MENSAJES);
          est.textContent = 'Actualizado a las ' + hora(Date.now()) + '.';
        } else {
          est.classList.add('err');
          est.textContent = mensajeDe(r, 'No se pudieron cargar los recuentos. Inténtalo de nuevo.');
        }
      }
    });
  }
  $('btnStats').addEventListener('click', cargarStats);

  /** Si el servidor dice que la sesión ya no vale (401) o que la cuenta ya no es admin (403), se sale del panel. */
  function rechazoDeSesion(r) {
    if (r.status === 401) { irAlLogin('Tu sesión venció o ya no es válida. Inicia sesión de nuevo.'); return true; }
    if (r.status === 403) { irAlLogin('Esta cuenta no tiene permisos de administración.'); return true; }
    return false;
  }

  /* ---------- Cerrar sesión ---------- */
  $('btnSalir').addEventListener('click', function () {
    if (estado.saliendo) return;
    estado.saliendo = true;
    var b = $('btnSalir');
    b.disabled = true;
    api('/api/admin/logout', { metodo: 'POST', token: estado.token }).then(function (r) {
      estado.saliendo = false;
      b.disabled = false;
      // La sesión local se borra siempre; si el servidor no respondió, se avisa con honestidad.
      irAlLogin(r.status === 200 ? 'Cerraste sesión.' : 'Cerraste sesión en este navegador. No pudimos avisar al servidor; si usas un equipo compartido, vuelve a intentarlo más tarde.');
    });
  });

  /* ---------- Comprobación de la sesión al cargar ---------- */
  function verificar() {
    if (estado.verificando) return;
    var guardada = leerSesion();
    if (!guardada) { irAlLogin(''); return; }
    if (guardada.expiraEn <= Date.now()) { irAlLogin('Tu sesión venció. Inicia sesión de nuevo.'); return; }
    estado.verificando = true;
    texto($('cargandoTxt'), 'Comprobando tu sesión…');
    mostrar('cargando');
    api('/api/admin/session', { token: guardada.token }).then(function (r) {
      estado.verificando = false;
      if (r.status === 200 && r.datos.ok && r.datos.user) { entrar(guardada.token, guardada.expiraEn, r.datos.user); return; }
      if (r.status === 401) { irAlLogin('Tu sesión venció o ya no es válida. Inicia sesión de nuevo.'); return; }
      if (r.status === 403) { irAlLogin('Esta cuenta no tiene permisos de administración.'); return; }
      // Fallo temporal (sin conexión, 429, 5xx): no se borra la sesión; se ofrece reintentar.
      $('errorTxt').textContent = mensajeDe(r, 'El servidor no respondió como se esperaba. Inténtalo de nuevo en un momento.');
      mostrar('error');
    });
  }
  $('btnReintentar').addEventListener('click', verificar);
  $('btnOtraSesion').addEventListener('click', function () { irAlLogin(''); });

  // Al volver a la pestaña, se reconfirma con el servidor (la sesión pudo vencer o cerrarse en otro sitio).
  document.addEventListener('visibilitychange', function () {
    if (document.visibilityState !== 'visible' || vistas.panel.hidden || !estado.token) return;
    var token = estado.token;
    if (estado.expiraEn <= Date.now()) { sesionVencida(); return; }
    api('/api/admin/session', { token: token }).then(function (r) {
      if (token !== estado.token) return;
      if (r.status === 200) { estado.verificadoEn = Date.now(); pintarSesion(); return; }
      rechazoDeSesion(r); // los fallos temporales se ignoran aquí: no se expulsa a nadie por un corte breve
    });
  });

  verificar();
})();
