/* UNMUTE · Genera supabase/migrations/002_seed_resources.sql a partir de src/data/resources-seed.json
   (una sola fuente de verdad, FUERA de public/: contiene borradores que no deben poder descargarse desde el navegador).
   Uso:  npm run seed:build   → escribe el SQL
         npm run seed:check   → falla si el SQL no coincide con el JSON */
import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const raiz = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const ORIGEN = path.join(raiz, 'src', 'data', 'resources-seed.json');
const DESTINO = path.join(raiz, 'supabase', 'migrations', '002_seed_resources.sql');
const COLUMNAS = ['slug', 'title', 'description', 'content', 'category', 'resource_type', 'icon', 'action_url', 'source_url', 'reviewed_at', 'status', 'featured'];

const sql = (v) => (v === null || v === undefined ? 'null' : typeof v === 'boolean' ? String(v) : `'${String(v).replace(/'/g, "''")}'`);

export function generarSql(recursos) {
  const filas = recursos.map((r) => `  (${COLUMNAS.map((c) => sql(r[c])).join(', ')})`).join(',\n');
  return `-- UNMUTE · Migración 002 · Contenido inicial del catálogo y datos curiosos
-- GENERADO con «npm run seed:build» desde src/data/resources-seed.json. No lo edites a mano.
-- Es seguro ejecutarlo más de una vez: «on conflict do nothing» respeta lo que ya hayas editado desde el panel de administración.
-- Los datos curiosos fueron comprobados contra su fuente el 2026-11-16; conviene que una persona del equipo los vuelva a revisar.

insert into public.resources
  (${COLUMNAS.join(', ')})
values
${filas}
on conflict (slug) do nothing;
`;
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const recursos = JSON.parse(await readFile(ORIGEN, 'utf8'));
  const esperado = generarSql(recursos);
  if (process.argv.includes('--check')) {
    const actual = await readFile(DESTINO, 'utf8').catch(() => '');
    if (actual !== esperado) { console.error('002_seed_resources.sql no coincide con resources-seed.json. Ejecuta: npm run seed:build'); process.exit(1); }
    console.log('Semilla al día.');
  } else {
    await writeFile(DESTINO, esperado, 'utf8');
    console.log(`Escrito ${path.relative(raiz, DESTINO)} (${recursos.length} recursos).`);
  }
}
