/* ==========================================================
   UNMUTE · Comprobación estática del proyecto  →  npm run check
   Solo LEE archivos: no modifica nada, no necesita credenciales y no llama a servicios externos.
   Termina con código 1 si alguna comprobación FALLA. Las advertencias (⚠) no hacen fallar el comando.
   Opción para pruebas: --root <carpeta>  (comprueba otra copia del proyecto).
   Qué NO demuestra: que Supabase, OpenAI o Netlify funcionen de verdad. Eso se prueba aparte.
   ========================================================== */
import { readFile, readdir, stat } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import vm from 'node:vm';
import { fileURLToPath, pathToFileURL } from 'node:url';

const i = process.argv.indexOf('--root');
const RAIZ = i > -1 && process.argv[i + 1] ? path.resolve(process.argv[i + 1]) : path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const IGNORAR = new Set(['node_modules', '.netlify', '.git', '.temp', 'coverage', 'test-results', 'playwright-report', 'e2e-screenshots']);

/* ---------- Utilidades ---------- */
const abs = (rel) => path.join(RAIZ, rel);
const esArchivo = async (rel) => (await stat(abs(rel)).catch(() => null))?.isFile() ?? false;
const esCarpeta = async (rel) => (await stat(abs(rel)).catch(() => null))?.isDirectory() ?? false;
const leer = (rel) => readFile(abs(rel), 'utf8');

/** Lista recursiva (rutas relativas con «/»), ignorando node_modules, .netlify, .git, etc. */
async function listar(rel = '') {
  const salida = [];
  for (const e of await readdir(abs(rel), { withFileTypes: true }).catch(() => [])) {
    if (IGNORAR.has(e.name)) continue;
    const r = rel ? `${rel}/${e.name}` : e.name;
    if (e.isDirectory()) salida.push(...(await listar(r))); else if (e.isFile()) salida.push(r);
  }
  return salida;
}

const resultados = [];
let grupo = '';
const registrar = (nivel) => (nombre, detalle = '') => resultados.push({ grupo, nivel, nombre, detalle });
const ok = registrar('ok'); const fallo = registrar('fallo'); const aviso = registrar('aviso');
/** Registra ok o fallo según una condición. */
const verificar = (condicion, nombre, detalleFallo = '') => (condicion ? ok(nombre) : fallo(nombre, detalleFallo));

/* ---------- 1. Archivos esenciales ---------- */
const ESENCIALES = [
  'package.json', 'netlify.toml', 'server.js', '.env.example', '.gitignore', 'README.md', 'CHANGELOG.md',
  'public/index.html', 'public/css/styles.css', 'public/js/app.js', 'public/js/ai-chat.js', 'public/js/help-directory.js', 'public/js/theme-init.js',
  'src/config/environment.mjs', 'src/lib/errors.mjs', 'src/lib/http.mjs', 'src/lib/rate-limit.mjs', 'src/lib/supabase.mjs', 'src/lib/validation.mjs',
  'src/services/ai.service.mjs', 'src/services/auth.service.mjs', 'src/services/contact.service.mjs', 'src/services/resources.service.mjs', 'src/services/news.service.mjs',
  'tests/api.test.mjs'
];
async function archivosEsenciales() {
  const faltan = [];
  for (const f of ESENCIALES) if (!(await esArchivo(f))) faltan.push(f);
  verificar(!faltan.length, `Archivos esenciales del proyecto (${ESENCIALES.length - faltan.length}/${ESENCIALES.length})`, `Faltan: ${faltan.join(', ')}`);
  const gi = (await esArchivo('.gitignore')) ? await leer('.gitignore') : '';
  verificar(/^\.env$/m.test(gi) && /^node_modules\/?$/m.test(gi), '.gitignore protege .env y node_modules', 'Añade «.env» y «node_modules/» a .gitignore');
}

/* ---------- 2. Funciones de Netlify ---------- */
const FUNCIONES = ['health', 'chat', 'resources', 'contact', 'admin-auth', 'admin-resources', 'admin-messages', 'news', 'admin-news'];
async function funcionesNetlify() {
  for (const nombre of FUNCIONES) {
    const rel = `netlify/functions/${nombre}.mjs`;
    if (!(await esArchivo(rel))) { fallo(`Función ${nombre}`, `Falta ${rel}`); continue; }
    const src = await leer(rel);
    const problemas = [];
    if (!/export\s+default\b/.test(src)) problemas.push('sin «export default»');
    const ruta = /export\s+const\s+config\s*=\s*\{[^}]*path\s*:\s*(\[[^\]]*\]|'[^']*'|"[^"]*")/.exec(src);
    if (!ruta) problemas.push('sin «export const config = { path }»');
    else if (!/\/api\//.test(ruta[1])) problemas.push('su ruta no empieza por /api/');
    verificar(!problemas.length, `Función ${nombre}`, `${rel}: ${problemas.join('; ')}`);
  }
}

/* ---------- 3. Migraciones SQL ---------- */
async function migraciones() {
  const sql = (await listar('supabase/migrations')).filter((f) => f.endsWith('.sql'));
  for (const requerida of ['supabase/migrations/001_initial_schema.sql', 'supabase/migrations/002_seed_resources.sql', 'supabase/migrations/003_news.sql']) {
    verificar(sql.includes(requerida), `Migración ${path.basename(requerida)} existe`, `Falta ${requerida}`);
  }
  for (const f of sql) {
    const texto = await leer(f);
    verificar(texto.trim().length > 0 && /^\d{3}_[a-z0-9_]+\.sql$/.test(path.basename(f)), `Migración ${path.basename(f)} con nombre válido y contenido`, `${f} está vacía o su nombre no sigue «NNN_nombre.sql»`);
  }
}

/* ---------- 4. Semilla del catálogo ---------- */
async function semilla() {
  const NUEVA = 'src/data/resources-seed.json';
  verificar(await esArchivo('scripts/build-seed.mjs'), 'Generador de semilla (scripts/build-seed.mjs) existe', 'Falta scripts/build-seed.mjs');

  const enPublic = (await listar('public')).filter((f) => /seed/i.test(path.basename(f)) && f.endsWith('.json'));
  verificar(!enPublic.length && !(await esCarpeta('public/data')), 'Ninguna semilla JSON dentro de public/ (los borradores no se pueden descargar)', `Hay semilla pública: ${enPublic.join(', ') || 'public/data/'}`);

  if (!(await esArchivo(NUEVA))) { fallo(`Semilla en ${NUEVA}`, `Falta ${NUEVA}`); return; }
  let datos;
  try { datos = JSON.parse(await leer(NUEVA)); } catch (e) { fallo(`${NUEVA} es JSON válido`, e.message); return; }
  const slugs = Array.isArray(datos) ? datos.map((r) => r?.slug) : [];
  const incompletos = Array.isArray(datos) ? datos.filter((r) => !r?.slug || !r?.title || !r?.status || !r?.resource_type).length : 1;
  verificar(Array.isArray(datos) && datos.length > 0 && !incompletos && new Set(slugs).size === slugs.length,
    `${NUEVA} existe y es válido (${slugs.length} recursos, slugs únicos)`, 'Debe ser una lista no vacía con slug, title, status y resource_type, sin slugs repetidos');

  const generador = (await esArchivo('scripts/build-seed.mjs')) ? await leer('scripts/build-seed.mjs') : '';
  const origen = /const\s+ORIGEN\s*=\s*([^\n]+)/.exec(generador)?.[1] ?? '';
  verificar(/'src'\s*,\s*'data'/.test(origen) && !/'public'/.test(origen), 'El generador lee la semilla desde src/data/', `ORIGEN actual: ${origen.trim() || 'no encontrado'}`);

  const referencias = [];
  for (const f of (await listar('public')).filter((x) => /\.(html|js|css|json|txt)$/.test(x))) if (/resources-seed/.test(await leer(f))) referencias.push(f);
  verificar(!referencias.length, 'Nada en public/ hace referencia a resources-seed', `Referencias en: ${referencias.join(', ')}`);

  try {
    const { generarSql } = await import(pathToFileURL(abs('scripts/build-seed.mjs')).href);
    const actual = await leer('supabase/migrations/002_seed_resources.sql');
    verificar(generarSql(datos) === actual, 'La migración 002 coincide con la semilla JSON', 'Ejecuta: npm run seed:build');
  } catch (e) { fallo('La migración 002 coincide con la semilla JSON', `No se pudo comparar: ${e.message}`); }
}

/* ---------- 5. Página administrativa ---------- */
async function administracion() {
  for (const f of ['public/admin.html', 'public/js/admin.js', 'public/css/admin.css']) verificar(await esArchivo(f), `Existe ${f}`, `Falta ${f}`);
  if (await esArchivo('public/admin.html')) {
    const html = await leer('public/admin.html');
    verificar(/src="\/js\/admin\.js"/.test(html) && /href="\/css\/admin\.css"/.test(html), 'admin.html carga admin.js y admin.css con rutas absolutas (también válidas en /admin/)', 'admin.html debe enlazar /js/admin.js y /css/admin.css con «/» inicial: en /admin/ las rutas relativas darían 404');
    verificar(!/(?:href|src)="(?!\/|https?:|#|data:|mailto:)[^"]+"/.test(html.replace(/<!--[\s\S]*?-->/g, '')), 'admin.html no usa rutas relativas (fallarían en /admin/)', 'Usa rutas que empiecen por «/»');
  }
  if (await esArchivo('public/js/admin.js')) {
    const js = (await leer('public/js/admin.js')).replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, ''); // sin comentarios
    verificar(!/innerHTML|outerHTML|insertAdjacentHTML|document\.write/.test(js), 'admin.js no inserta HTML (usa textContent)', 'Se encontró innerHTML/insertAdjacentHTML/document.write');
    verificar(!/SERVICE_ROLE|isAdmin|is_admin/i.test(js), 'admin.js no maneja claves de servicio ni decide permisos', 'admin.js menciona claves de servicio o isAdmin');
  }
}

/* ---------- 6. Configuración de Netlify ---------- */
const bloques = (toml, etiqueta) => toml.split(`[[${etiqueta}]]`).slice(1).map((b) => b.split(/\n\[\[/)[0]);
const campo = (bloque, nombre) => new RegExp(`^\\s*${nombre}\\s*=\\s*"([^"\\n]*)"`, 'm').exec(bloque)?.[1];
async function configuracionNetlify() {
  if (!(await esArchivo('netlify.toml'))) { fallo('netlify.toml existe', 'Falta netlify.toml'); return; }
  const toml = await leer('netlify.toml');
  verificar(/^\s*publish\s*=\s*"public"/m.test(toml) && /^\s*functions\s*=\s*"netlify\/functions"/m.test(toml), 'netlify.toml publica «public» y usa netlify/functions', 'Revisa [build] publish y functions');

  const redirecciones = bloques(toml, 'redirects').map((b) => ({ from: campo(b, 'from'), to: campo(b, 'to'), status: campo(b, 'status') ?? /^\s*status\s*=\s*(\d+)/m.exec(b)?.[1] }));
  for (const desde of ['/admin', '/admin/']) {
    const r = redirecciones.find((x) => x.from === desde);
    verificar(r && r.to === '/admin.html' && String(r.status) === '200', `Redirección ${desde} → /admin.html (200)`, `Falta o es incorrecta la redirección de ${desde}`);
  }
  const peligrosas = redirecciones.filter((r) => r.from && (r.from === '/*' || r.from.startsWith('/api')));
  verificar(!peligrosas.length, 'Ninguna redirección intercepta /api/*', `Redirecciones sospechosas: ${peligrosas.map((r) => r.from).join(', ')}`);

  const cabeceras = bloques(toml, 'headers').map((b) => ({ para: campo(b, 'for'), texto: b }));
  const global = cabeceras.find((c) => c.para === '/*')?.texto ?? '';
  verificar(/Content-Security-Policy\s*=\s*"[^"]*script-src 'self'/.test(global) && /X-Content-Type-Options/.test(global) && /X-Frame-Options/.test(global),
    'Cabeceras de seguridad globales (CSP, nosniff, X-Frame-Options)', 'Falta CSP con script-src \'self\', X-Content-Type-Options o X-Frame-Options en el bloque «/*»');
  const rutasAdmin = ['/admin', '/admin/', '/admin.html'];
  const sinNoIndex = rutasAdmin.filter((r) => { const t = cabeceras.find((c) => c.para === r)?.texto ?? ''; return !(/X-Robots-Tag\s*=\s*"noindex/.test(t) && /Cache-Control\s*=\s*"no-store"/.test(t)); });
  verificar(!sinNoIndex.length, 'Administración con noindex y sin caché', `Faltan cabeceras para: ${sinNoIndex.join(', ')}`);
}

/* ---------- 7. HTML: referencias locales y compatibilidad con la CSP ---------- */
async function paginasHtml() {
  const toml = (await esArchivo('netlify.toml')) ? await leer('netlify.toml') : '';
  const rutasReescritas = new Set(bloques(toml, 'redirects').map((b) => campo(b, 'from')).filter(Boolean));
  for (const rel of (await listar('public')).filter((f) => f.endsWith('.html'))) {
    const html = (await leer(rel)).replace(/<!--[\s\S]*?-->/g, '');
    const rotas = [];
    for (const m of html.matchAll(/\b(?:href|src)\s*=\s*"([^"]*)"/g)) {
      const ref = m[1].trim();
      if (!ref || /^(https?:|\/\/|#|mailto:|tel:|data:|javascript:|\/api\/)/i.test(ref)) continue;
      const limpia = ref.split(/[?#]/)[0];
      if (limpia === '/' || rutasReescritas.has(limpia)) continue;
      const destino = limpia.startsWith('/') ? `public${limpia}` : path.posix.join(path.posix.dirname(rel), limpia);
      if (!(await esArchivo(destino))) rotas.push(ref);
    }
    verificar(!rotas.length, `${rel}: referencias locales existentes`, `No existen: ${rotas.join(', ')}`);

    const enLinea = [];
    if (/<script(?![^>]*\bsrc\s*=)[^>]*>/i.test(html)) enLinea.push('<script> sin src');
    if (/<style[\s>]/i.test(html) || /\sstyle\s*=/i.test(html)) enLinea.push('estilos en línea');
    if (/\son[a-z]+\s*=\s*["']/i.test(html)) enLinea.push('manejadores on…=');
    verificar(!enLinea.length, `${rel}: sin código en línea (compatible con la CSP)`, `La CSP lo bloquearía: ${enLinea.join(', ')}`);
  }
}

/* ---------- 8. Sintaxis de JavaScript ---------- */
async function sintaxis() {
  const todos = (await listar()).filter((f) => /\.(m?js)$/.test(f));
  const navegador = todos.filter((f) => f.startsWith('public/')); // se cargan con <script src> (script clásico)
  const node = todos.filter((f) => !f.startsWith('public/'));      // ESM de Node ("type": "module")
  const errores = [];
  for (const f of navegador) {
    try { new vm.Script(await leer(f), { filename: f }); } catch (e) { errores.push(`${f}: ${e.message}`); }
  }
  for (const f of node) {
    const r = spawnSync(process.execPath, ['--check', abs(f)], { encoding: 'utf8' });
    if (r.status !== 0) errores.push(`${f}: ${(r.stderr || '').split('\n').find((l) => /Error/.test(l)) || 'error de sintaxis'}`);
  }
  verificar(!errores.length, `Sintaxis de ${todos.length} archivos JS/MJS (${navegador.length} de navegador, ${node.length} de Node)`, errores.join(' | '));
}

/* ---------- 9. Scripts de package.json ---------- */
const PENDIENTES_CONOCIDOS = { e2e: 'declara tests/e2e-smoke.mjs, que todavía no existe (no se simula una prueba E2E)' };
async function scriptsNpm() {
  let pkg;
  try { pkg = JSON.parse(await leer('package.json')); } catch (e) { fallo('package.json es JSON válido', e.message); return; }
  ok('package.json es JSON válido');
  for (const [nombre, cmd] of Object.entries(pkg.scripts ?? {})) {
    const archivo = /^node\s+(\S+\.m?js)\b/.exec(cmd)?.[1];
    if (!archivo || (await esArchivo(archivo))) continue;
    if (PENDIENTES_CONOCIDOS[nombre]) aviso(`npm run ${nombre}`, PENDIENTES_CONOCIDOS[nombre]);
    else fallo(`npm run ${nombre}`, `apunta a ${archivo}, que no existe`);
  }
  if (!resultados.some((r) => r.grupo === grupo && r.nivel === 'fallo')) ok('Ningún script de package.json apunta a un archivo inexistente (salvo los avisos)');
}

/* ---------- 10. Secretos ---------- */
const PATRONES_SECRETOS = [
  [/sk-[A-Za-z0-9_-]{20,}/, 'clave tipo OpenAI'], [/sb_secret_[A-Za-z0-9_-]{10,}/, 'clave secreta de Supabase'],
  [/eyJ[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{10,}/, 'JWT']
];
async function secretos() {
  const hallazgos = [];
  const archivos = (await listar()).filter((f) => /\.(m?js|json|html|css|md|toml|sql|txt|env)$/i.test(f) && f !== '.env.example');
  for (const f of archivos) {
    const t = await leer(f);
    for (const [re, que] of PATRONES_SECRETOS) if (re.test(t)) hallazgos.push(`${f} (${que})`);
    if (f.startsWith('public/') && /SUPABASE_SERVICE_ROLE_KEY|OPENAI_API_KEY/.test(t)) hallazgos.push(`${f} (nombre de variable secreta en archivo público)`);
  }
  verificar(!hallazgos.length, `Sin secretos evidentes en ${archivos.length} archivos`, hallazgos.join(', '));
}

/* ---------- Ejecución ---------- */
const GRUPOS = [
  ['Archivos esenciales', archivosEsenciales], ['Funciones de Netlify', funcionesNetlify], ['Migraciones SQL', migraciones],
  ['Semilla del catálogo', semilla], ['Página administrativa', administracion], ['Configuración de Netlify', configuracionNetlify],
  ['Páginas HTML', paginasHtml], ['Sintaxis JavaScript', sintaxis], ['Scripts de package.json', scriptsNpm], ['Secretos', secretos]
];
for (const [nombre, fn] of GRUPOS) {
  grupo = nombre;
  try { await fn(); } catch (e) { fallo('La comprobación no pudo completarse', e.message); }
}

const ICONO = { ok: '✓', fallo: '✗', aviso: '⚠' };
console.log(`UNMUTE · comprobación del proyecto (${RAIZ})\n`);
let actual = '';
for (const r of resultados) {
  if (r.grupo !== actual) { actual = r.grupo; console.log(`\n${actual}`); }
  console.log(`  ${ICONO[r.nivel]} ${r.nombre}${r.detalle && r.nivel !== 'ok' ? `\n      ${r.detalle}` : ''}`);
}
const n = (nivel) => resultados.filter((r) => r.nivel === nivel).length;
console.log(`\n${resultados.length} comprobaciones: ${n('ok')} correctas, ${n('fallo')} con error, ${n('aviso')} advertencias.`);
if (n('fallo')) { console.error('Resultado: HAY ERRORES. Corrígelos y vuelve a ejecutar «npm run check».'); process.exit(1); }
console.log('Resultado: correcto.' + (n('aviso') ? ' (Revisa las advertencias.)' : ''));
