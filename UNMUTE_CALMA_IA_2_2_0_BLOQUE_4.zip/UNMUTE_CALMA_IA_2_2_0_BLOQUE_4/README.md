# UNMUTE · Calma orgánica + IA

**Versión:** 2.2.0  
**Bloque:** 4 — Inicio educativo, Recursos y navegación principal  
**Lema:** «Tu voz también merece ser escuchada».

UNMUTE es un diario emocional digital. El diario continúa siendo el núcleo de la aplicación; las noticias, recursos, ejercicios de Pausa y acompañamiento mediante IA son herramientas complementarias y voluntarias.

Esta versión incorpora dos tarjetas independientes en Inicio, la vista pública Recursos y una navegación principal simplificada. Conserva el diario local, Acompañar, Historia, Pausa, Noticias, Ajustes y el panel administrativo de las versiones anteriores.

## Novedades de la versión 2.2.0

### Inicio: dos tarjetas independientes

- **Un minuto para aprender:** muestra un dato curioso publicado elegido al azar mediante `GET /api/facts/today` y el parámetro `offset`.
- **Noticias de UNMUTE:** muestra una noticia publicada elegida al azar desde `GET /api/news`.
- Las tarjetas mantienen selecciones independientes y cada una gestiona sus propios estados de carga, contenido, ausencia de publicaciones, error y reintento.
- «Ver otro dato» y «Ver otra noticia» buscan una alternativa distinta cuando hay más de una opción publicada.
- Volver a Inicio no cambia una tarjeta que ya tiene contenido; una nueva selección ocurre al pedir otro elemento o al recargar la página.
- En escritorio las tarjetas se presentan en dos columnas; en móvil se apilan.

### Recursos

- Nueva vista pública conectada a `GET /api/resources`.
- Muestra solo recursos publicados y excluye los datos curiosos, que se presentan en la tarjeta «Un minuto para aprender».
- Incluye búsqueda por título y descripción, sin distinguir mayúsculas ni tildes.
- Los filtros de categoría se construyen con las categorías disponibles en los resultados.
- Incluye acción para limpiar los filtros, estado vacío y mensaje de error con reintento.
- Los botones aparecen únicamente cuando existe un destino interno aprobado o una URL HTTPS segura. Si un recurso no tiene un destino disponible, no se muestra un botón ficticio.

### Navegación

- Cinco accesos principales: Inicio, Diario, Acompañar, Historia y Más.
- El menú Más reúne Pausa, Noticias, Recursos y Ajustes.
- Se conserva el nombre completo «Acompañar» en móvil.
- El menú permite navegación con teclado, cierre con Escape, gestión del foco y navegación Atrás/Adelante del navegador.

## Arquitectura conservada

- **Frontend:** HTML, CSS y JavaScript en `public/`.
- **Backend:** Netlify Functions en `netlify/functions/`.
- **Datos y autenticación:** Supabase / PostgreSQL / Auth / RLS.
- **IA:** OpenAI desde el backend.
- **Servicios compartidos:** `src/services/` y `src/lib/`.
- **Migraciones:** `supabase/migrations/`.
- **Despliegue previsto:** Netlify.

El Bloque 4 no modifica endpoints, servicios backend, esquema de base de datos, migraciones, autenticación, control de uso, chat ni almacenamiento del diario.

## Estructura relevante

```text
public/
├── index.html
├── admin.html
├── css/
│   ├── styles.css
│   └── admin.css
└── js/
    ├── app.js
    ├── content.js
    ├── resources.js
    ├── ai-chat.js
    ├── admin.js
    ├── help-directory.js
    └── theme-init.js
netlify/functions/       APIs serverless existentes
src/config/              configuración de entorno
src/lib/                 validación, HTTP, Supabase y rate limit
src/services/            servicios de IA, noticias, recursos y contacto
src/data/                semilla privada de recursos
supabase/migrations/     migraciones 001, 002 y 003
scripts/                 construcción de semilla y comprobaciones
tests/                   pruebas automatizadas
server.js                servidor local de desarrollo
netlify.toml             publicación, rutas y cabeceras
```

## Instalación y ejecución local

Requisitos: Node.js 20.12 o superior.

1. Copia `.env.example` como `.env` y configura las variables necesarias. No compartas ni subas `.env`.
2. Instala las dependencias si tu entorno aún no las tiene:

```bash
npm install
```

3. Inicia el servidor local:

```bash
npm start
```

4. Abre `http://localhost:3000`. El panel administrativo está en `http://localhost:3000/admin`.

Para utilizar el entorno de desarrollo de Netlify:

```bash
npm run dev
```

Se requiere que las variables de entorno estén configuradas y que Supabase y OpenAI estén disponibles para probar las integraciones correspondientes.

## Supabase y migraciones

Las migraciones incluidas son:

1. `supabase/migrations/001_initial_schema.sql`
2. `supabase/migrations/002_seed_resources.sql`
3. `supabase/migrations/003_news.sql`

La migración 003 crea la tabla de noticias con trigger de fecha de publicación y políticas RLS. El Bloque 4 no añade ni modifica migraciones.

La semilla de recursos está en `src/data/resources-seed.json`, fuera de `public/`, y contiene también borradores editoriales. Para comprobar la correspondencia entre la semilla y el SQL:

```bash
npm run seed:check
```

## Variables de entorno y secretos

Consulta `.env.example`. Las claves privadas de OpenAI y Supabase deben configurarse únicamente en el servidor o en el entorno de Functions de Netlify. Nunca incluyas `OPENAI_API_KEY`, `SUPABASE_SERVICE_ROLE_KEY` o `SUPABASE_SECRET_KEY` en HTML, CSS, JavaScript público o Git.

El modelo de OpenAI se configura mediante `OPENAI_MODEL`; confirma que el identificador elegido está habilitado para la cuenta API que se utilizará.

## Pruebas

Comandos disponibles:

```bash
npm test
npm run check
npm run seed:check
npm run e2e
```

- `npm test`: pruebas automatizadas de API y lógica con servicios simulados.
- `npm run check`: comprobaciones estáticas de estructura, funciones, migraciones, semilla, CSP, referencias y sintaxis.
- `npm run seed:check`: verifica que la semilla JSON coincide con la migración SQL.
- `npm run e2e`: está declarado en `package.json`, pero el archivo `tests/e2e-smoke.mjs` no está incluido en esta entrega y el comando falla por esa razón.

El changelog del Bloque 4 registra además una ejecución temporal de pruebas de navegador Chromium (76/76) en entorno local con catálogo de semilla y noticias simuladas. Esa prueba temporal no forma parte del repositorio y no equivale a una prueba contra Supabase o Netlify reales. En esta revisión se reprodujeron `npm test`, `npm run check` y `npm run seed:check`; no se volvió a ejecutar el recorrido temporal de navegador.

## Pendientes conocidos

- **Recurso sin destino funcional:** el recurso publicado «Información confiable sobre salud mental» (`biblioteca-informacion`) contiene `action_url = #recursos/informacion`, pero esa vista no existe. Por ello la tarjeta no muestra botón ni pasos de uso y avisa que todavía no está disponible dentro de la aplicación. No se modificó el contenido editorial ni se despublicó el recurso.
- Verificar lectura pública, RLS, caché e imágenes HTTPS contra Supabase real y Netlify desplegado.
- Ejecutar `003_news.sql` en Supabase si aún no se ha aplicado.
- Añadir `tests/e2e-smoke.mjs` o ajustar el comando `e2e` para que apunte a una prueba existente.

## Privacidad y alcance emocional

- El diario y los borradores permanecen en `localStorage`; no se envían automáticamente a Supabase ni a OpenAI.
- Acompañar requiere consentimiento explícito y transmite únicamente los mensajes del chat y su contexto reciente, no las entradas del diario.
- `store: false` no significa retención cero por parte del proveedor de IA.
- El almacenamiento local no está cifrado y puede ser accesible para otras personas con acceso al mismo perfil del navegador.
- UNMUTE IA no diagnostica, no sustituye atención profesional y no es un servicio de emergencias.

---

**UNMUTE — Tu voz también merece ser escuchada.**
