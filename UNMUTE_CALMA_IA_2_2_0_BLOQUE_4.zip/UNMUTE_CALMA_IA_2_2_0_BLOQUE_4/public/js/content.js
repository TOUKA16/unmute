/* ==========================================================
   UNMUTE · Contenido público del servidor: «Un minuto para aprender» y «Noticias»
   · Inicio · dato curioso al azar: GET /api/facts/today?date=AAAA-MM-DD&offset=n. La respuesta trae «index» y «total»:
     con eso el navegador elige una posición al azar entre los datos PUBLICADOS (sin depender de identificadores).
   · Inicio · noticia al azar: GET /api/news (solo publicadas); «Leer noticia» abre el lector de siempre (GET /api/news/:slug).
   · Vista Noticias: lista completa.
   Cada tarjeta tiene su propio estado: si una falla, la otra sigue funcionando.
   No toca el diario ni el almacenamiento local. Todo texto del servidor se escribe con textContent (sin HTML).
   ========================================================== */
(function () {
  'use strict';
  var TIMEOUT_MS = 12000;
  function $(id) { return document.getElementById(id); }
  function el(tag, clase, texto) { var e = document.createElement(tag); if (clase) e.className = clase; if (texto != null) e.textContent = texto; return e; }

  /** GET JSON con tiempo máximo; nunca lanza: devuelve {status, datos}. status 0 = sin conexión. */
  function pedir(ruta) {
    var ctl = new AbortController();
    var t = setTimeout(function () { ctl.abort(); }, TIMEOUT_MS);
    return fetch(ruta, { cache: 'no-cache', credentials: 'omit', headers: { Accept: 'application/json' }, signal: ctl.signal })
      .then(function (res) { return res.json().catch(function () { return {}; }).then(function (d) { return { status: res.status, datos: d || {} }; }); })
      .catch(function () { return { status: 0, datos: {} }; })
      .then(function (r) { clearTimeout(t); return r; });
  }
  function fechaLarga(iso) {
    var d = new Date(iso);
    return isNaN(d) ? '' : new Intl.DateTimeFormat('es', { day: 'numeric', month: 'long', year: 'numeric' }).format(d);
  }
  function urlSegura(u) { return typeof u === 'string' && /^https?:\/\/\S+$/i.test(u); }
  function dominio(u) { try { return new URL(u).hostname.replace(/^www\./, ''); } catch (_e) { return u; } }

  /** Muestra solo los botones indicados dentro de un contenedor de acciones; si no hay ninguno, oculta el contenedor. */
  function botones(contId, visibles) {
    var cont = $(contId), alguno = false;
    Array.prototype.forEach.call(cont.querySelectorAll('button'), function (b) {
      var v = visibles.indexOf(b.id) > -1; b.hidden = !v; if (v) alguno = true;
    });
    cont.hidden = !alguno;
  }
  function aleatorio(n) { return Math.floor(Math.random() * n); }
  function mod(a, n) { return ((a % n) + n) % n; }
  function textoFallo(status, cosa) {
    return status === 0
      ? 'No hay conexión con el servidor. Revisa tu conexión e inténtalo de nuevo.'
      : 'No pudimos cargar ' + cosa + ' en este momento. Tu diario y el resto de UNMUTE funcionan con normalidad.';
  }

  /* ---------- Un minuto para aprender (al azar) ---------- */
  var minuto = { cargando: false, listo: false, offset: 0, index: -1, total: 0, slug: '' };
  function fechaLocal() {
    var d = new Date(), p = function (n) { return String(n).padStart(2, '0'); };
    return d.getFullYear() + '-' + p(d.getMonth() + 1) + '-' + p(d.getDate());
  }
  function pintarDato(f) {
    $('minutoCat').textContent = f.category || '';
    $('minutoCat').hidden = !f.category;
    $('minutoTitulo').textContent = f.title || '';
    $('minutoDesc').textContent = f.description || '';
    var fuente = $('minutoFuente'); fuente.textContent = '';
    if (urlSegura(f.source_url)) {
      fuente.appendChild(document.createTextNode('Fuente: '));
      var a = el('a', null, dominio(f.source_url));
      a.href = f.source_url; a.target = '_blank'; a.rel = 'noopener noreferrer';
      fuente.appendChild(a);
      if (f.reviewed_at) fuente.appendChild(document.createTextNode(' · Revisado el ' + fechaLarga(f.reviewed_at + 'T12:00:00')));
    }
    fuente.hidden = !fuente.textContent;
  }
  /** Pide el dato en la posición que corresponde al «offset»: índice = (día + offset) mod total, según el servidor. */
  function pedirDato(offset) { return pedir('/api/facts/today?date=' + fechaLocal() + '&offset=' + offset); }
  function cargarMinuto(otro) {
    if (minuto.cargando) return;
    minuto.cargando = true;
    var est = $('minutoEstado'), conContenido = minuto.listo;
    est.hidden = false; est.classList.remove('err');
    est.textContent = otro ? 'Buscando otro dato…' : 'Buscando un dato…';
    botones('minutoAcc', []);
    var offset;
    if (otro && minuto.total > 1) {
      // «base» es la posición que da el servidor con offset 0; se elige una posición distinta de la actual y se traduce a offset.
      var base = mod(minuto.index - minuto.offset, minuto.total);
      var destino = mod(minuto.index + 1 + aleatorio(minuto.total - 1), minuto.total);
      offset = mod(destino - base, minuto.total);
    } else {
      offset = aleatorio(10000);
    }
    function fin(r, usado, reintento) {
      var f = r.status === 200 && r.datos.fact;
      var total = Number.isInteger(r.datos.total) ? r.datos.total : 0, index = Number.isInteger(r.datos.index) ? r.datos.index : -1;
      if (f && otro && conContenido && f.slug === minuto.slug && total > 1 && !reintento) { // por si cambió la cantidad de datos
        return pedirDato(usado + 1).then(function (r2) { return fin(r2, usado + 1, true); });
      }
      minuto.cargando = false;
      if (!f) {
        if (conContenido) { // se conserva el dato que ya se ve
          est.classList.add('err'); est.textContent = 'No pudimos cargar otro dato ahora. Puedes volver a intentarlo.';
          botones('minutoAcc', ['minutoOtra']); return;
        }
        $('minutoCuerpo').hidden = true;
        est.classList.toggle('err', r.status !== 404);
        est.textContent = r.status === 404 ? 'Todavía no hay datos publicados. Vuelve más tarde.' : textoFallo(r.status, 'un dato');
        botones('minutoAcc', ['minutoReint']);
        return;
      }
      minuto.listo = true; minuto.offset = usado; minuto.index = index; minuto.total = total; minuto.slug = f.slug || '';
      pintarDato(f);
      est.hidden = true; $('minutoCuerpo').hidden = false;
      botones('minutoAcc', total > 1 ? ['minutoOtra'] : []); // sin alternativas no se ofrece «otro»
    }
    pedirDato(offset).then(function (r) { return fin(r, offset, false); });
  }
  $('minutoOtra').addEventListener('click', function () { cargarMinuto(true); });
  $('minutoReint').addEventListener('click', function () { cargarMinuto(false); });

  /* ---------- Noticias de UNMUTE en Inicio (una al azar) ---------- */
  var ini = { cargando: false, listo: false, slug: '', actual: null };
  function noticiaValida(n) { return n && typeof n === 'object' && typeof n.slug === 'string' && n.slug && typeof n.title === 'string' && n.title; }
  function cargarNoticiaInicio(otra) {
    if (ini.cargando) return;
    ini.cargando = true;
    var est = $('nInicioEstado'), conContenido = ini.listo;
    est.hidden = false; est.classList.remove('err');
    est.textContent = otra ? 'Buscando otra noticia…' : 'Buscando una noticia…';
    botones('nInicioAcc', []);
    pedir('/api/news').then(function (r) {
      ini.cargando = false;
      if (r.status !== 200 || !Array.isArray(r.datos.news)) {
        est.classList.add('err');
        if (conContenido) { est.textContent = 'No pudimos cargar otra noticia ahora. Puedes volver a intentarlo.'; botones('nInicioAcc', ['nInicioLeer', 'nInicioOtra']); return; }
        $('nInicioCuerpo').hidden = true;
        est.textContent = textoFallo(r.status, 'las noticias');
        botones('nInicioAcc', ['nInicioReint']);
        return;
      }
      var lista = r.datos.news.filter(noticiaValida);
      if (!lista.length) {
        ini.listo = false; ini.actual = null; ini.slug = '';
        $('nInicioCuerpo').hidden = true;
        est.textContent = 'Todavía no hay noticias publicadas. Vuelve más tarde.';
        botones('nInicioAcc', ['nInicioReint']);
        return;
      }
      var candidatas = (otra && lista.length > 1) ? lista.filter(function (n) { return n.slug !== ini.slug; }) : lista;
      var n = candidatas[aleatorio(candidatas.length)]; // no depende del orden en que el servidor entrega la lista
      ini.listo = true; ini.actual = n; ini.slug = n.slug;
      ponerImagen($('nInicioImg'), n.image_url);
      $('nInicioCat').textContent = n.category || ''; $('nInicioCat').hidden = !n.category;
      $('nInicioFecha').textContent = n.published_at ? fechaLarga(n.published_at) : '';
      $('nInicioTitulo').textContent = n.title;
      $('nInicioDesc').textContent = n.description || '';
      $('nInicioLeer').setAttribute('aria-label', 'Leer noticia: ' + n.title);
      est.hidden = true; $('nInicioCuerpo').hidden = false;
      botones('nInicioAcc', lista.length > 1 ? ['nInicioLeer', 'nInicioOtra'] : ['nInicioLeer']);
    });
  }
  $('nInicioOtra').addEventListener('click', function () { cargarNoticiaInicio(true); });
  $('nInicioReint').addEventListener('click', function () { cargarNoticiaInicio(false); });
  $('nInicioLeer').addEventListener('click', function () { if (ini.actual) abrir(ini.actual.slug, $('nInicioLeer')); }); // mismo lector que la vista Noticias

  /* ---------- Noticias ---------- */
  var nCargando = false;
  function ponerImagen(img, url) {
    img.hidden = true;
    img.removeAttribute('src');
    if (!/^https:\/\/\S+$/i.test(url || '')) return;
    img.referrerPolicy = 'no-referrer';
    img.onerror = function () { img.hidden = true; }; // si la imagen no carga, la noticia se lee igual
    img.onload = function () { img.hidden = false; };
    img.src = url;
  }
  function tarjeta(n) {
    var art = el('article', 'noticia');
    var img = el('img', 'noticia-img'); img.alt = ''; img.loading = 'lazy'; img.decoding = 'async';
    art.appendChild(img);
    ponerImagen(img, n.image_url);
    var cuerpo = el('div', 'noticia-cuerpo');
    var meta = el('p', 'meta');
    meta.appendChild(el('span', 'etq', n.category || ''));
    if (n.published_at) meta.appendChild(document.createTextNode(' ' + fechaLarga(n.published_at)));
    cuerpo.appendChild(meta);
    cuerpo.appendChild(el('h2', null, n.title));
    cuerpo.appendChild(el('p', null, n.description));
    var b = el('button', 'btn-sec', 'Leer noticia'); b.type = 'button';
    b.setAttribute('aria-label', 'Leer noticia: ' + n.title);
    b.addEventListener('click', function () { abrir(n.slug, b); });
    cuerpo.appendChild(b);
    art.appendChild(cuerpo);
    return art;
  }
  function cargarNoticias() {
    if (nCargando) return;
    nCargando = true;
    var est = $('nEstado'); est.classList.remove('err'); est.textContent = 'Cargando noticias…';
    $('nActualizar').disabled = true;
    pedir('/api/news').then(function (r) {
      nCargando = false; $('nActualizar').disabled = false;
      var lista = $('nLista'); lista.textContent = '';
      if (r.status !== 200 || !Array.isArray(r.datos.news)) {
        est.classList.add('err');
        est.textContent = r.status === 0 ? 'No hay conexión con el servidor. Revisa tu conexión e inténtalo de nuevo.' : 'No pudimos cargar las noticias en este momento. Inténtalo de nuevo en unos minutos.';
        return;
      }
      if (!r.datos.news.length) { est.textContent = 'Todavía no hay noticias publicadas. Vuelve más tarde.'; return; }
      est.textContent = '';
      r.datos.news.forEach(function (n) { lista.appendChild(tarjeta(n)); });
    });
  }
  $('nActualizar').addEventListener('click', cargarNoticias);

  var dlg = $('lectorNoticia');
  function abrir(slug, origen) {
    $('nTit').textContent = 'Cargando…'; $('nMeta').textContent = ''; $('nTxt').textContent = ''; ponerImagen($('nImg'), '');
    if (!dlg.open) dlg.showModal();
    pedir('/api/news/' + encodeURIComponent(slug)).then(function (r) {
      var n = r.status === 200 && r.datos.news;
      if (!n) {
        $('nTit').textContent = 'No pudimos abrir esta noticia';
        $('nTxt').textContent = r.status === 404 ? 'Ya no está publicada. Actualiza la lista para ver las noticias vigentes.' : 'Inténtalo de nuevo en unos minutos.';
        return;
      }
      $('nTit').textContent = n.title;
      $('nMeta').textContent = [n.category, n.published_at ? fechaLarga(n.published_at) : ''].filter(Boolean).join(' · ');
      $('nTxt').textContent = n.content || n.description; // texto plano: los saltos de línea se conservan por CSS
      ponerImagen($('nImg'), n.image_url);
    });
    dlg.addEventListener('close', function () { if (origen && document.body.contains(origen)) origen.focus(); }, { once: true });
  }
  $('nCerrar').addEventListener('click', function () { dlg.close(); });

  window.UNMUTE_PUB = { pedir: pedir, el: el, urlSegura: urlSegura, ponerImagen: ponerImagen }; // lo reutiliza resources.js

  /* ---------- Cuándo cargar ---------- */
  function alEntrar(v) {
    if (v === 'inicio') { // cada tarjeta por separado; si una ya tiene contenido, no cambia al volver a Inicio
      if (!minuto.listo) cargarMinuto(false);
      if (!ini.listo) cargarNoticiaInicio(false);
    }
    if (v === 'noticias') cargarNoticias(); // en cada visita: siempre se consulta el servidor
  }
  document.addEventListener('unmute:vista', function (e) { alEntrar(e.detail); });
  var actual = document.querySelector('nav.principal a[aria-current="page"]'); // app.js ya mostró la vista inicial
  if (actual) alEntrar(actual.dataset.v);
})();
