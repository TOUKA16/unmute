/* ==========================================================
   UNMUTE · Vista pública «Recursos»
   Lee el catálogo de Supabase mediante GET /api/resources (solo recursos PUBLICADOS; los borradores nunca llegan).
   · Los datos curiosos (resource_type = «fact») viven en el mismo catálogo pero se muestran en «Un minuto para aprender»,
     así que aquí se excluyen.
   · Cada botón apunta a una pantalla que existe de verdad. Si el recurso no tiene destino real, no hay botón.
   · Búsqueda y filtros se calculan en el navegador sobre lo ya descargado. No toca el diario ni el almacenamiento local.
   · Todo texto del servidor se escribe con textContent (sin HTML).
   ========================================================== */
(function () {
  'use strict';
  var pub = window.UNMUTE_PUB; // lo define content.js
  if (!pub || !document.getElementById('v-recursos')) return;
  var pedir = pub.pedir, el = pub.el, urlSegura = pub.urlSegura, ponerImagen = pub.ponerImagen;
  function $(id) { return document.getElementById(id); }
  function norm(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }

  /* Destinos internos que existen en la aplicación (ruta hash → texto del botón). */
  var DESTINOS = {
    '#diario': 'Abrir el diario',
    '#acompanar': 'Ir a Acompañar',
    '#historia': 'Ver mi historia',
    '#pausa': 'Ir a Pausa',
    '#noticias': 'Ver noticias',
    '#ajustes': 'Abrir ajustes'
  };
  function accionDe(r) {
    var u = typeof r.action_url === 'string' ? r.action_url.trim() : '';
    if (DESTINOS[u]) return { tipo: 'interna', href: u, texto: DESTINOS[u] };
    if (urlSegura(u)) return { tipo: 'externa', href: u, texto: 'Abrir enlace' };
    return null; // vacío o una ruta que todavía no existe: no se promete nada
  }

  /* Iconos sencillos (trazo, como el logotipo). Nombre del catálogo → trazos SVG. Un nombre desconocido no muestra icono. */
  var ICONOS = {
    book: ['M5 4h11a3 3 0 0 1 3 3v13H8a3 3 0 0 1-3-3z', 'M5 17a3 3 0 0 1 3-3h11'],
    chat: ['M5 5h14v10H10l-5 4z'],
    wind: ['M3 9h11a3 3 0 1 0-3-3', 'M3 15h15a3 3 0 1 1-3 3', 'M3 12h7'],
    eye: ['M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z', 'M12 9.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5z'],
    pen: ['M4 20l1-4L16 5l3 3L8 19z', 'M14 7l3 3'],
    info: ['M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z', 'M12 11v5', 'M12 8h.01'],
    compass: ['M12 3a9 9 0 1 0 0 18 9 9 0 0 0 0-18z', 'M15.5 8.5l-2 5-5 2 2-5z'],
    heart: ['M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.5A4 4 0 0 1 19 10c0 5.6-7 10-7 10z']
  };
  function icono(nombre) {
    var trazos = ICONOS[nombre]; if (!trazos) return null;
    var ns = 'http://www.w3.org/2000/svg', svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24'); svg.setAttribute('width', '22'); svg.setAttribute('height', '22');
    svg.setAttribute('aria-hidden', 'true'); svg.setAttribute('focusable', 'false');
    svg.setAttribute('fill', 'none'); svg.setAttribute('stroke', 'currentColor'); svg.setAttribute('stroke-width', '1.6');
    svg.setAttribute('stroke-linecap', 'round'); svg.setAttribute('stroke-linejoin', 'round');
    trazos.forEach(function (d) { var p = document.createElementNS(ns, 'path'); p.setAttribute('d', d); svg.appendChild(p); });
    var span = el('span', 'rec-icono'); span.appendChild(svg);
    return span;
  }

  var todos = [];            // recursos publicados (sin datos curiosos)
  var categoria = '';        // filtro activo
  var cargando = false;

  function tarjeta(r) {
    var art = el('article', 'recurso');
    if (/^https:\/\/\S+$/i.test(r.image_url || '')) {
      var img = el('img', 'noticia-img rec-img'); img.alt = ''; img.loading = 'lazy'; img.decoding = 'async';
      art.appendChild(img); ponerImagen(img, r.image_url); // si falla, se oculta y el recurso se lee igual
    }
    var cab = el('div', 'rec-cab');
    var ic = icono(r.icon); if (ic) cab.appendChild(ic);
    if (r.category) cab.appendChild(el('span', 'etq', r.category));
    art.appendChild(cab);
    art.appendChild(el('h2', null, r.title));
    if (r.description) art.appendChild(el('p', null, r.description));

    var acc = accionDe(r);
    if (acc && r.content) { // los pasos solo se muestran si el recurso se puede abrir de verdad
      var det = el('details', 'rec-pasos'); det.appendChild(el('summary', null, 'Cómo usarlo'));
      det.appendChild(el('div', 'lectura', r.content));
      art.appendChild(det);
    }
    var pie = el('p', 'acciones rec-acc');
    if (acc) {
      var a = el('a', 'btn-sec', acc.texto); a.href = acc.href;
      a.setAttribute('aria-label', acc.texto + ': ' + r.title);
      if (acc.tipo === 'externa') { a.target = '_blank'; a.rel = 'noopener noreferrer'; }
      pie.appendChild(a);
    } else {
      pie.appendChild(el('span', 'suave', 'Todavía no está disponible dentro de la app.'));
    }
    art.appendChild(pie);
    return art;
  }

  function filtrados() {
    var q = norm($('recBuscar').value.trim());
    return todos.filter(function (r) {
      if (categoria && r.category !== categoria) return false;
      return !q || norm(r.title + ' ' + (r.description || '')).indexOf(q) > -1;
    });
  }

  function pintarCategorias() {
    var cont = $('recCats'); cont.textContent = '';
    var cats = [];
    todos.forEach(function (r) { if (r.category && cats.indexOf(r.category) < 0) cats.push(r.category); });
    cats.sort(function (a, b) { return a.localeCompare(b, 'es'); });
    if (cats.length < 2) { cont.hidden = true; if (categoria && cats.indexOf(categoria) < 0) categoria = ''; return; }
    if (categoria && cats.indexOf(categoria) < 0) categoria = ''; // esa categoría ya no existe
    ['Todas'].concat(cats).forEach(function (c) {
      var valor = c === 'Todas' ? '' : c;
      var b = el('button', 'tag', c); b.type = 'button';
      b.setAttribute('aria-pressed', String(valor === categoria));
      b.addEventListener('click', function () { categoria = valor; pintarCategorias(); mostrar(); });
      cont.appendChild(b);
    });
    cont.hidden = false;
  }

  function mostrar() {
    var lista = $('recLista'), est = $('recEstado'); lista.textContent = '';
    var hayFiltros = !!(categoria || $('recBuscar').value.trim());
    $('recLimpiar').hidden = !hayFiltros;
    est.classList.remove('err');
    if (!todos.length) { est.textContent = 'Todavía no hay recursos publicados. Vuelve más tarde.'; return; }
    var res = filtrados();
    if (!res.length) { est.textContent = 'No encontramos recursos con esa búsqueda. Prueba con otras palabras o restablece los filtros.'; return; }
    est.textContent = hayFiltros ? 'Mostrando ' + res.length + ' de ' + todos.length + ' recursos.' : '';
    res.forEach(function (r) { lista.appendChild(tarjeta(r)); });
  }

  function cargar() {
    if (cargando) return;
    cargando = true;
    var est = $('recEstado'); est.classList.remove('err'); est.textContent = 'Cargando recursos…';
    $('recReint').hidden = true;
    pedir('/api/resources').then(function (r) {
      cargando = false;
      if (r.status !== 200 || !Array.isArray(r.datos.resources)) {
        todos = []; $('recLista').textContent = ''; $('recCats').hidden = true; $('recLimpiar').hidden = true;
        est.classList.add('err');
        est.textContent = r.status === 0
          ? 'No hay conexión con el servidor. Revisa tu conexión e inténtalo de nuevo.'
          : 'No pudimos cargar los recursos en este momento. Tu diario y el resto de UNMUTE funcionan con normalidad.';
        $('recReint').hidden = false;
        return;
      }
      todos = r.datos.resources.filter(function (x) {
        return x && typeof x.title === 'string' && x.title && x.resource_type !== 'fact' && (x.status === undefined || x.status === 'published');
      });
      pintarCategorias(); mostrar();
    });
  }

  $('recBuscar').addEventListener('input', mostrar);
  $('recLimpiar').addEventListener('click', function () {
    $('recBuscar').value = ''; categoria = ''; pintarCategorias(); mostrar(); $('recBuscar').focus();
  });
  $('recReint').addEventListener('click', cargar);

  /* Se consulta el servidor en cada visita, para no mostrar algo que ya se despublicó. */
  document.addEventListener('unmute:vista', function (e) { if (e.detail === 'recursos') cargar(); });
  if (document.body.dataset.vista === 'recursos') cargar(); // app.js ya mostró la vista inicial
})();
