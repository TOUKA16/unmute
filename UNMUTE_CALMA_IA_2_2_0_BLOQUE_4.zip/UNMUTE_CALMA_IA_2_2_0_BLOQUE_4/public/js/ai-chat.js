(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const form = $('#aiForm');
  if (!form) return;

  const consent = $('#aiConsent');
  const input = $('#aiInput');
  const send = $('#aiSend');
  const log = $('#aiMessages');
  const status = $('#aiStatus');
  const counter = $('#aiCount');
  const clear = $('#aiClear');
  const suggestions = [...document.querySelectorAll('[data-ai-suggest]')];
  // Solo memoria de esta pestaña: no se escribe en localStorage ni sessionStorage.
  let conversation = [];
  let sending = false;
  let consentHint = false;
  const MSG_CONSENT = 'Marca la casilla de privacidad para habilitar el envío.';

  function bubble(text, role) {
    const node = document.createElement('article');
    node.className = 'ai-message ' + (role === 'user' ? 'ai-user' : 'ai-assistant');
    const p = document.createElement('p');
    p.textContent = text; // El texto de la IA y del usuario nunca se interpreta como HTML.
    node.appendChild(p);
    log.appendChild(node);
    log.scrollTop = log.scrollHeight;
    return node;
  }

  function updateControls() {
    send.disabled = !consent.checked || !input.value.trim() || sending;
    counter.textContent = String(input.value.length);
    // Si ya escribió algo pero falta el consentimiento, se explica por qué el botón está desactivado.
    if (!consent.checked && input.value.trim()) {
      status.classList.remove('error');
      status.textContent = MSG_CONSENT;
      consentHint = true;
    } else if (consentHint) {
      if (status.textContent === MSG_CONSENT) status.textContent = '';
      consentHint = false;
    }
  }

  function recentContext() {
    // Respeta también el límite total del servidor, sin guardar ni ampliar el historial.
    const selected = [];
    let total = 0;
    for (let i = conversation.length - 1; i >= 0 && selected.length < 12; i--) {
      const item = conversation[i];
      if (total + item.content.length > 8500) break;
      selected.unshift(item);
      total += item.content.length;
    }
    return selected;
  }

  consent.addEventListener('change', () => {
    if (consent.checked) {
      status.classList.remove('error');
      status.textContent = 'Consentimiento activado para esta página. Puedes desactivarlo cuando quieras.';
    } else {
      status.textContent = MSG_CONSENT;
    }
    consentHint = false;
    updateControls();
  });

  input.addEventListener('input', updateControls);
  suggestions.forEach((button) => button.addEventListener('click', () => {
    input.value = button.dataset.aiSuggest || '';
    input.focus();
    updateControls();
  }));

  clear.addEventListener('click', () => {
    if (sending) return;
    conversation = [];
    log.replaceChildren();
    bubble('Conversación limpiada. Podemos empezar desde aquí, a tu ritmo.', 'assistant');
    status.classList.remove('error');
    status.textContent = 'El contexto de esta conversación se ha eliminado de la memoria de esta página.';
  });

  form.addEventListener('submit', async (event) => {
    event.preventDefault();
    if (sending) return;
    // El consentimiento nunca se da por hecho: sin la casilla marcada no se envía nada al servidor.
    if (!consent.checked) {
      status.classList.add('error');
      status.textContent = 'Para enviar tu mensaje, primero marca la casilla de privacidad. No se ha enviado nada.';
      consent.focus();
      return;
    }
    const message = input.value.trim();
    if (!message) return;

    // Conserva como máximo 6 turnos previos. No se incluyen entradas del diario.
    conversation.push({ role: 'user', content: message });
    if (conversation.length > 12) conversation = conversation.slice(-12);
    bubble(message, 'user');
    input.value = '';
    sending = true;
    status.classList.remove('error');
    status.textContent = 'UNMUTE está preparando una respuesta…';
    updateControls();

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        // «consent» refleja el estado real de la casilla en este momento; el servidor lo vuelve a exigir.
        body: JSON.stringify({ consent: consent.checked === true, messages: recentContext() })
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || 'No se pudo enviar el mensaje.');
      const reply = typeof data.reply === 'string' && data.reply.trim()
        ? data.reply.trim()
        : 'No pude preparar una respuesta esta vez. Puedes intentarlo de nuevo.';
      conversation.push({ role: 'assistant', content: reply });
      if (conversation.length > 12) conversation = conversation.slice(-12);
      bubble(reply, 'assistant');
      status.textContent = '';
    } catch (error) {
      // Retira del contexto la solicitud fallida; su burbuja queda visible para que se entienda qué pasó.
      if (conversation.length && conversation[conversation.length - 1].role === 'user') conversation.pop();
      status.classList.add('error');
      status.textContent = error.message || 'No pude conectar con UNMUTE IA. Inténtalo más tarde.';
    } finally {
      sending = false;
      updateControls();
      input.focus();
    }
  });

  updateControls();
})();
