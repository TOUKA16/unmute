/* ==========================================================
   UNMUTE · Directorio de ayuda (datos que se muestran en «Necesito ayuda»)
   REGLAS PARA EDITARLO:
   · Solo se publican datos comprobados en una fuente oficial. Cada recurso lleva su fuente y la fecha de verificación.
   · Si no hay horario confirmado por la fuente, se deja «hours» en null (no se afirma «24 horas» sin verificarlo).
   · Los números cambian: vuelve a comprobar las fuentes cada cierto tiempo y actualiza «verified».
   · Para añadir otro país, agrega un objeto a «countries» con el mismo formato.
   Líneas revisadas pero NO incluidas por no poder confirmarse su vigencia: «192 opción 4» (Ministerio de Salud).
   ========================================================== */
window.UNMUTE_HELP = {
  default: 'CO',
  countries: [
    {
      code: 'CO',
      name: 'Colombia',
      resources: [
        {
          id: 'co-123',
          name: 'Línea de emergencias 123',
          scope: 'Todo el país',
          phone: '123',
          description: 'Línea única nacional de emergencias. Úsala si tú o alguien está en peligro inmediato.',
          hours: '24 horas, todos los días',
          source: { name: 'Policía Nacional de Colombia', url: 'https://www.policia.gov.co/noticia/policia-nacional-sensibiliza-comunidad-sobre-uso-las-lineas-emergencia-123-155' },
          verified: '2026-11-16'
        },
        {
          id: 'co-106',
          name: 'Línea 106 «El poder de ser escuchado»',
          scope: 'Bogotá',
          phone: '106',
          whatsapp: { display: '300 754 8933', e164: '573007548933' },
          description: 'Apoyo emocional y orientación en salud mental de la Secretaría Distrital de Salud de Bogotá. Es gratuita.',
          hours: '24 horas, todos los días',
          source: { name: 'Alcaldía de Bogotá', url: 'https://bogota.gov.co/mi-ciudad/salud/linea-106-para-apoyo-psicologico-y-mas-en-bogota-este-2025' },
          verified: '2026-11-16'
        },
        {
          id: 'co-141',
          name: 'Línea 141 del ICBF',
          scope: 'Todo el país',
          phone: '141',
          description: 'Línea gratuita nacional de protección, emergencia y orientación para niñas, niños y adolescentes.',
          hours: '24 horas',
          source: { name: 'Instituto Colombiano de Bienestar Familiar', url: 'https://www.icbf.gov.co/proteccion/linea-141' },
          verified: '2026-11-16'
        },
        {
          id: 'co-155',
          name: 'Línea 155',
          scope: 'Todo el país',
          phone: '155',
          description: 'Orientación para mujeres víctimas de violencia.',
          hours: '24 horas, todos los días',
          source: { name: 'Policía Nacional de Colombia', url: 'https://www.policia.gov.co/noticia/policia-nacional-sensibiliza-comunidad-sobre-uso-las-lineas-emergencia-123-155' },
          verified: '2026-11-16'
        }
      ],
      note: 'Si estás en otra ciudad, tu Secretaría de Salud puede tener una línea propia de apoyo emocional. Pregunta por ella o busca en el sitio oficial de tu alcaldía.'
    }
  ],
  other: {
    name: 'Otro país',
    text: 'Llama al número de emergencias de tu país o territorio si hay peligro inmediato. Para encontrar líneas de apoyo emocional cerca de ti, estos directorios internacionales pueden ayudar:',
    links: [
      { name: 'Find a Helpline (ThroughLine)', url: 'https://findahelpline.com' },
      { name: 'IASP · Centros de crisis y líneas de ayuda', url: 'https://www.iasp.info/crisis-centres/' }
    ],
    verified: '2026-11-16'
  }
};
