(function () {
  'use strict';
  try {
    var p = JSON.parse(localStorage.getItem('unmute_v2_prefs') || '{}');
    var h = document.documentElement;
    var t = p.tema || 'sistema';
    h.dataset.tema = t === 'sistema'
      ? (matchMedia('(prefers-color-scheme: dark)').matches ? 'oscuro' : 'claro')
      : t;
    if (p.texto) h.dataset.texto = p.texto;
    if (p.reducir) h.dataset.calma = '1';
    if (p.sinefectos) h.dataset.efectos = 'off';
  } catch (_e) { /* Las preferencias no deben impedir cargar la app. */ }
})();
