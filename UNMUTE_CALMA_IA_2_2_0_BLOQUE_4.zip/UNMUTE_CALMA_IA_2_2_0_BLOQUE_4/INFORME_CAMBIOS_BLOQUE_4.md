# UNMUTE 2.2.0 — Informe de cambios del Bloque 4
## Inicio educativo, biblioteca de Recursos y navegación principal

**Versión de partida:** 2.1.0 — Bloque 3.  
**Versión actualizada:** 2.2.0 — Bloque 4.  
**Alcance:** Inicio con dos tarjetas informativas, vista pública Recursos y navegación principal de cinco accesos.

---

## 1. Resumen

El Bloque 4 mejora la entrada a UNMUTE y amplía el acceso a sus contenidos. Inicio pasa a mostrar dos tarjetas independientes: «Un minuto para aprender» y «Noticias de UNMUTE». También se incorpora una vista pública Recursos conectada al catálogo que ya existe en Supabase y se reorganiza la navegación principal alrededor de cinco accesos, con un menú Más para las secciones secundarias.

Se mantiene la arquitectura, los servicios backend, las migraciones, el diario local, el consentimiento de Acompañar y la autenticación administrativa.

## 2. Cambios incorporados y motivo

### 2.1. Inicio: dos tarjetas independientes

**Se incorpora o modifica:**
- Distribución de Inicio en dos tarjetas: a la izquierda «Un minuto para aprender» y a la derecha «Noticias de UNMUTE».
- Las tarjetas se presentan en dos columnas en escritorio y se apilan en móvil.
- Cada tarjeta tiene su propio estado de carga, contenido, ausencia de publicaciones, error y reintento.
- Las selecciones son independientes: un fallo o cambio de contenido en una tarjeta no bloquea la otra.

**Dato curioso aleatorio:**
- Se reutiliza `GET /api/facts/today`; no se crea una API nueva.
- Se usa `offset` y el `index`/`total` devuelto por el backend para elegir entre datos publicados sin depender de IDs consecutivos.
- En la primera carga se elige un offset aleatorio.
- «Ver otro dato» solicita una posición distinta de la actual cuando hay más de un dato publicado.
- Al volver a Inicio, si la tarjeta ya tiene contenido, la selección se conserva. Cambia al solicitar otro elemento o recargar la página.

**Noticia aleatoria:**
- Se reutiliza `GET /api/news`, que devuelve únicamente noticias publicadas.
- El navegador elige una noticia al azar; «Ver otra noticia» excluye la actual cuando hay alternativas.
- «Leer noticia» abre el lector ya existente de la sección Noticias.
- La tarjeta no cambia al volver a Inicio si ya tiene una selección.

**Por qué se hizo:** dar visibilidad al contenido educativo y editorial desde Inicio, ofreciendo variedad sin duplicar endpoints ni mezclar los estados de dos servicios diferentes.

### 2.2. Vista pública Recursos

**Archivos principales:** `public/index.html`, `public/js/resources.js` y `public/css/styles.css`.

**Se incorpora:**
- Nueva vista pública «Recursos» conectada a `GET /api/resources`.
- Tarjetas con título, descripción, categoría e icono o imagen cuando existan.
- Exclusión de elementos `resource_type = 'fact'`, que se muestran en «Un minuto para aprender».
- Búsqueda por título y descripción sin distinguir mayúsculas ni tildes.
- Filtros de categoría construidos a partir de los recursos recibidos.
- Acción para restablecer búsqueda y filtros.
- Estados de carga, lista vacía, ausencia de coincidencias, error y reintento.
- Los borradores no se muestran; el endpoint entrega recursos publicados.

**Acciones seguras:**
- Los botones internos se muestran únicamente para destinos aprobados que existen: Diario, Acompañar, Historia, Pausa, Noticias y Ajustes.
- Los enlaces externos se aceptan solo cuando son URLs HTTPS válidas y se abren con `noopener noreferrer`.
- Si un recurso no tiene un destino funcional, no se inventa un botón. En ese caso se presenta una nota de disponibilidad.
- Los pasos de uso solo se muestran cuando el recurso tiene un destino real.

**Por qué se hizo:** permitir que las personas encuentren herramientas y contenidos desde un catálogo compartido, sin crear copias locales ni exponer borradores.

### 2.3. Navegación principal y menú Más

**Se incorpora o reorganiza:**
- Cinco accesos principales: Inicio, Diario, Acompañar, Historia y Más.
- El menú Más agrupa Pausa, Noticias, Recursos y Ajustes.
- Se conserva la etiqueta completa «Acompañar» en pantallas móviles.
- El menú admite interacción con ratón y teclado, cierre con Escape y gestión del foco.
- Se mantiene la navegación por hash, el historial Atrás/Adelante y la vista indicada por el hash inicial.
- Se añade el evento `unmute:vista` para que los módulos de contenido carguen datos al entrar a cada vista.

**Por qué se hizo:** dar prioridad a las cinco áreas principales y ordenar las herramientas secundarias sin eliminarlas ni alterar su función.

### 2.4. Ajustes visuales y responsive

- Inicio y Recursos utilizan un ancho máximo de contenido de hasta 60 rem.
- Las vistas de lectura conservan una columna más estrecha.
- Las tarjetas, filtros y navegación se adaptan a móvil y escritorio.
- Se mantienen los estilos de Calma orgánica y las preferencias de movimiento reducido.

**Por qué se hizo:** dar espacio suficiente a las tarjetas y al catálogo sin cambiar la identidad visual de UNMUTE.

## 3. Archivos modificados y nuevos

**Nuevos:**
- `public/js/resources.js`
- `tests/bloque4.test.mjs`
- `CHANGELOG_BLOQUE_4.md` (registro del bloque)
- `INFORME_CAMBIOS_BLOQUE_4.md` (este informe)

**Modificados:**
- `public/index.html`
- `public/css/styles.css`
- `public/js/app.js`
- `public/js/content.js`
- `package.json` (versión 2.2.0)
- `CHANGELOG.md`
- `README.md`

**No modificados por este bloque:**
- `src/`, `netlify/functions/`, `supabase/` y `netlify.toml`.
- `public/admin.html`, `public/js/admin.js`, `public/js/ai-chat.js` y el directorio de ayuda.
- Consentimiento del chat, autenticación, RLS, rate limiting y almacenamiento del diario.

No se añadió una migración SQL ni un endpoint nuevo.

## 4. Hallazgo conocido

El recurso publicado **«Información confiable sobre salud mental»** (`biblioteca-informacion`) contiene `action_url = #recursos/informacion`, una vista que no existe. Para no ofrecer un destino roto, la tarjeta se muestra sin botón y con la nota «Todavía no está disponible dentro de la app»; tampoco muestra los pasos de uso.

No se modificó ni despublicó el recurso porque eso requiere una decisión editorial del propietario. Para resolverlo será necesario cambiar su destino/contenido o despublicarlo desde administración.

## 5. Pruebas y resultados

### Ejecutadas de nuevo durante esta revisión

| Comprobación | Resultado |
|---|---:|
| `npm test` | **74/74 pruebas aprobadas** |
| `npm run check` | **44 correctas, 0 errores, 1 advertencia** |
| `npm run seed:check` | **Correcto: semilla al día** |
| `npm run e2e` | **No ejecutable:** falta `tests/e2e-smoke.mjs` |
| Integridad del ZIP | **Correcta** |

La advertencia de `npm run check` corresponde al comando E2E declarado sin el archivo de prueba correspondiente.

### Prueba de navegador registrada en el changelog del Bloque 4

El `CHANGELOG_BLOQUE_4.md` incluido en la entrega registra un recorrido temporal en Chromium de **76/76 comprobaciones**, con servidor local, semilla del catálogo y noticias simuladas. Según ese registro, se cubrieron las tarjetas de Inicio, estados vacíos y errores, lector de noticias, búsqueda y filtros de Recursos, navegación con ratón y teclado, Escape, foco, Atrás/Adelante y tamaños de 320, 390 y 1280 px.

Ese script temporal no forma parte del paquete y no se volvió a ejecutar en esta revisión. Sus resultados no equivalen a una prueba contra Supabase, Netlify u OpenAI reales.

## 6. Verificaciones externas pendientes

- Probar la lectura anónima y las políticas RLS contra Supabase real.
- Verificar el comportamiento de caché de `/api/resources` (60 segundos) en Netlify.
- Comprobar la carga de imágenes HTTPS externas en el despliegue.
- Ejecutar `003_news.sql` en Supabase si todavía no se ha aplicado.
- Resolver el destino del recurso `biblioteca-informacion`.

## 7. Instrucciones de integración

1. Utilizar este paquete como base de la siguiente etapa.
2. No aplicar nuevas migraciones por el Bloque 4: no se añadieron cambios de base de datos.
3. Conservar las variables privadas de Supabase y OpenAI en el entorno de Functions.
4. Desplegar en Netlify y verificar las APIs ya existentes de datos curiosos, noticias y recursos.
5. Resolver el destino del recurso señalado antes de presentar ese contenido como una herramienta plenamente disponible.

---

**UNMUTE — Tu voz también merece ser escuchada.**
