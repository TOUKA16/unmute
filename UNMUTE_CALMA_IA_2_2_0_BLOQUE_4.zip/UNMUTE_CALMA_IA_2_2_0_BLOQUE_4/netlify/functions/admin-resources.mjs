/* Administración del catálogo (todas las rutas exigen sesión de administrador verificada):
     GET    /api/admin/resources              lista (también borradores y archivados)
     POST   /api/admin/resources              crear
     GET    /api/admin/resources/:id          ver
     PATCH  /api/admin/resources/:id          modificar
     DELETE /api/admin/resources/:id          eliminar
     POST   /api/admin/resources/:id/publish    publicar
     POST   /api/admin/resources/:id/unpublish  despublicar (vuelve a borrador)
     GET    /api/admin/stats                  indicadores de contenido y mensajes */
import { createHandler, json, readJson } from '../../src/lib/http.mjs';
import { badRequest, methodNotAllowed, notFound } from '../../src/lib/errors.mjs';
import { RESOURCE_STATUSES, RESOURCE_TYPES, isUuid, parseResourceInput } from '../../src/lib/validation.mjs';
import { requerirAdmin } from '../../src/services/auth.service.mjs';
import * as recursos from '../../src/services/resources.service.mjs';
import { contarPorEstado } from '../../src/services/contact.service.mjs';

export default createHandler(async ({ req, url, method }) => {
  const { token } = await requerirAdmin(req); // primero identidad y permisos; después, cualquier otra cosa
  const partes = url.pathname.replace(/\/+$/, '').split('/').filter(Boolean); // api, admin, resources|stats, id?, accion?

  if (partes[2] === 'stats') {
    if (method !== 'GET') throw methodNotAllowed(['GET']);
    const [resources, messages] = await Promise.all([recursos.adminEstadisticas(token), contarPorEstado(token)]);
    return json({ resources, messages });
  }

  const [, , , id, accion] = partes;
  if (!id) {
    if (method === 'GET') {
      const type = url.searchParams.get('type') || undefined;
      const status = url.searchParams.get('status') || undefined;
      if (type && !RESOURCE_TYPES.includes(type)) throw badRequest('El tipo de recurso no es válido.', 'invalid_type');
      if (status && !RESOURCE_STATUSES.includes(status)) throw badRequest('El estado no es válido.', 'invalid_status');
      return json({ resources: await recursos.adminListar(token, { type, status }) });
    }
    if (method === 'POST') return json({ resource: await recursos.adminCrear(token, parseResourceInput(await readJson(req, 24 * 1024))) }, 201);
    throw methodNotAllowed(['GET', 'POST']);
  }

  if (!isUuid(id)) throw notFound('No se encontró ese recurso.');
  if (accion) {
    if (method !== 'POST') throw methodNotAllowed(['POST']);
    if (accion === 'publish') return json({ resource: await recursos.adminCambiarEstado(token, id, 'published') });
    if (accion === 'unpublish') return json({ resource: await recursos.adminCambiarEstado(token, id, 'draft') });
    throw notFound();
  }
  if (method === 'GET') return json({ resource: await recursos.adminObtener(token, id) });
  if (method === 'PATCH') {
    const cambios = parseResourceInput(await readJson(req, 24 * 1024), { partial: true });
    if (!Object.keys(cambios).length) throw badRequest('No hay cambios que guardar.', 'empty_patch');
    return json({ resource: await recursos.adminActualizar(token, id, cambios) });
  }
  if (method === 'DELETE') { await recursos.adminEliminar(token, id); return json({ ok: true }); }
  throw methodNotAllowed(['GET', 'PATCH', 'DELETE']);
}, { methods: ['GET', 'POST', 'PATCH', 'DELETE'] });

export const config = { path: ['/api/admin/resources', '/api/admin/resources/:id', '/api/admin/resources/:id/:action', '/api/admin/stats'] };
