/* GET /api/health · Estado del backend. Nunca devuelve claves ni secretos. */
import { createHandler, json } from '../../src/lib/http.mjs';
import { getConfig } from '../../src/config/environment.mjs';
import * as sb from '../../src/lib/supabase.mjs';
import { modoLimite } from '../../src/lib/rate-limit.mjs';

export default createHandler(async ({ url }) => {
  const cfg = getConfig();
  const bdLista = sb.isConfigured();
  const servicios = {
    ai: { configured: Boolean(cfg.openai.apiKey), model: cfg.openai.apiKey ? cfg.openai.model : null },
    database: { configured: bdLista, serviceRoleConfigured: sb.isConfigured({ service: true }) },
    // 'database' | 'unavailable' | 'memory' (este último solo con RATE_LIMIT_DEV_MEMORY=true en local; no apto para producción)
    rateLimit: { mode: modoLimite() }
  };
  // ?deep=1 hace una consulta real y ligera a la base de datos (por defecto solo se revisa la configuración).
  if (url.searchParams.get('deep') === '1' && bdLista) {
    try { await sb.rest({ table: 'resources', query: { select: 'id', limit: 1 }, timeoutMs: 5000 }); servicios.database.reachable = true; }
    catch { servicios.database.reachable = false; }
  }
  const degradado = !servicios.ai.configured || !bdLista || servicios.database.reachable === false || servicios.rateLimit.mode === 'unavailable';
  return json({ ok: true, status: degradado ? 'degraded' : 'ok', time: new Date().toISOString(), services: servicios });
}, { methods: ['GET'] });

export const config = { path: '/api/health' };
