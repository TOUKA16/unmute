/* Catálogo público de recursos y datos curiosos (solo contenido PUBLICADO):
     GET /api/resources            lista (filtros: type, category, featured)
     GET /api/resources/:slug      un recurso
     GET /api/facts/today          dato del día (?date=AAAA-MM-DD&offset=n) */
import { createHandler, json } from '../../src/lib/http.mjs';
import { badRequest, notFound } from '../../src/lib/errors.mjs';
import { RESOURCE_TYPES, isSlug, parseDateParam } from '../../src/lib/validation.mjs';
import { datoDelDia, listarPublicos, obtenerPublico } from '../../src/services/resources.service.mjs';

const CACHE = { 'Cache-Control': 'public, max-age=60' };

export default createHandler(async ({ url, params }) => {
  const ruta = url.pathname.replace(/\/+$/, '');

  if (ruta === '/api/facts/today') {
    const fecha = parseDateParam(url.searchParams.get('date')) || new Date().toISOString().slice(0, 10);
    const offset = Number.parseInt(url.searchParams.get('offset') ?? '0', 10);
    if (!Number.isInteger(offset) || offset < 0 || offset > 10000) throw badRequest('El desplazamiento no es válido.', 'invalid_offset');
    return json(await datoDelDia({ fecha, offset }), 200, CACHE);
  }

  if (params.slug) {
    if (!isSlug(params.slug)) throw notFound('Ese recurso no existe o no está publicado.');
    return json({ resource: await obtenerPublico(params.slug) }, 200, CACHE);
  }

  const type = url.searchParams.get('type') || undefined;
  if (type && !RESOURCE_TYPES.includes(type)) throw badRequest('El tipo de recurso no es válido.', 'invalid_type');
  const category = url.searchParams.get('category')?.trim().slice(0, 60) || undefined;
  const destacado = url.searchParams.get('featured');
  const featured = destacado === 'true' ? true : destacado === 'false' ? false : undefined;
  return json({ resources: await listarPublicos({ type, category, featured }) }, 200, CACHE);
}, { methods: ['GET'] });

export const config = { path: ['/api/resources', '/api/resources/:slug', '/api/facts/today'] };
