/* POST /api/contact · Formulario de contacto (consultas, sugerencias y reportes técnicos).
   No es un canal de crisis. Validación + trampa antispam + límite de uso + guardado en Supabase. */
import { createHandler, json, readJson } from '../../src/lib/http.mjs';
import { getConfig } from '../../src/config/environment.mjs';
import { parseContactPayload } from '../../src/lib/validation.mjs';
import { limitarPorCliente } from '../../src/lib/rate-limit.mjs';
import { crearMensaje } from '../../src/services/contact.service.mjs';

const CONFIRMACION = { ok: true, message: 'Recibimos tu mensaje. Gracias por escribir a UNMUTE.' };

export default createHandler(async ({ req, ip }) => {
  const resultado = parseContactPayload(await readJson(req, 8 * 1024));
  // A los bots se les responde «éxito» para no darles pistas, pero no se guarda nada.
  if (resultado.spam) return json(CONFIRMACION, 201);
  await limitarPorCliente({ scope: 'contacto', ip, limite: getConfig().limits.contactPerHour, ventanaSeg: 3600, mensaje: 'Enviaste varios mensajes seguidos. Inténtalo de nuevo más tarde.' });
  await crearMensaje(resultado.value);
  return json(CONFIRMACION, 201);
}, { methods: ['POST'] });

export const config = { path: '/api/contact' };
