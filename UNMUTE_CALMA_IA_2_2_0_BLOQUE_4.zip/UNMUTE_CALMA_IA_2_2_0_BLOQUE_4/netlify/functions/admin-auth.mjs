/* Sesión de administración:
     POST /api/admin/login      correo + contraseña → token de acceso (solo si la cuenta es admin)
     POST /api/admin/logout     cierra esta sesión
     GET  /api/admin/session    confirma que el token sigue siendo válido y administrador */
import { createHandler, json, readJson, bearerToken } from '../../src/lib/http.mjs';
import { getConfig } from '../../src/config/environment.mjs';
import { methodNotAllowed, notFound } from '../../src/lib/errors.mjs';
import { parseLoginPayload } from '../../src/lib/validation.mjs';
import { limitarPorCliente } from '../../src/lib/rate-limit.mjs';
import { cerrarSesion, iniciarSesion, requerirAdmin } from '../../src/services/auth.service.mjs';

export default createHandler(async ({ req, url, ip, method }) => {
  const accion = url.pathname.replace(/\/+$/, '').split('/').pop();

  if (accion === 'login') {
    if (method !== 'POST') throw methodNotAllowed(['POST']);
    // Se cuenta cada intento (también los fallidos) para frenar la fuerza bruta.
    await limitarPorCliente({ scope: 'login', ip, limite: getConfig().limits.loginPer15Min, ventanaSeg: 900, mensaje: 'Demasiados intentos de inicio de sesión. Espera unos minutos.' });
    const { email, password } = parseLoginPayload(await readJson(req, 4 * 1024));
    return json(await iniciarSesion(email, password));
  }
  if (accion === 'logout') {
    if (method !== 'POST') throw methodNotAllowed(['POST']);
    const token = bearerToken(req);
    if (token) await cerrarSesion(token);
    return json({ ok: true });
  }
  if (accion === 'session') {
    if (method !== 'GET') throw methodNotAllowed(['GET']);
    const { user } = await requerirAdmin(req);
    return json({ ok: true, user });
  }
  throw notFound();
}, { methods: ['GET', 'POST'] });

export const config = { path: ['/api/admin/login', '/api/admin/logout', '/api/admin/session'] };
