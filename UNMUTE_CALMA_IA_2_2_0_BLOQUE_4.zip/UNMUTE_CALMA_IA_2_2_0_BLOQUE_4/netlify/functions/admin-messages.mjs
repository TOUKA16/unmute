/* Mensajes de contacto (solo administración):
     GET   /api/admin/messages        lista (?status=new|read|resolved|archived)
     PATCH /api/admin/messages/:id    cambia el estado del mensaje */
import { createHandler, json, readJson } from '../../src/lib/http.mjs';
import { badRequest, methodNotAllowed, notFound } from '../../src/lib/errors.mjs';
import { MESSAGE_STATUSES, isUuid, parseStatusPayload } from '../../src/lib/validation.mjs';
import { requerirAdmin } from '../../src/services/auth.service.mjs';
import { actualizarEstado, listarMensajes } from '../../src/services/contact.service.mjs';

export default createHandler(async ({ req, url, params, method }) => {
  const { token } = await requerirAdmin(req);
  if (!params.id) {
    if (method !== 'GET') throw methodNotAllowed(['GET']);
    const status = url.searchParams.get('status') || undefined;
    if (status && !MESSAGE_STATUSES.includes(status)) throw badRequest('El estado no es válido.', 'invalid_status');
    return json({ messages: await listarMensajes(token, { status }) });
  }
  if (!isUuid(params.id)) throw notFound('No se encontró ese mensaje.');
  if (method !== 'PATCH') throw methodNotAllowed(['PATCH']);
  const status = parseStatusPayload(await readJson(req, 2 * 1024), MESSAGE_STATUSES);
  return json({ message: await actualizarEstado(token, params.id, status) });
}, { methods: ['GET', 'PATCH'] });

export const config = { path: ['/api/admin/messages', '/api/admin/messages/:id'] };
