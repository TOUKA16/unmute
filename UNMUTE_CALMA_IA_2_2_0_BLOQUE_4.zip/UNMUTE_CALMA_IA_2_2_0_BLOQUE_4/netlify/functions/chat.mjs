/* POST /api/chat · Conversación con UNMUTE IA.
   Recibe solo los mensajes que la persona decidió compartir. No toca el diario ni guarda la conversación. */
import { createHandler, json, readJson } from '../../src/lib/http.mjs';
import { getConfig } from '../../src/config/environment.mjs';
import { unavailable } from '../../src/lib/errors.mjs';
import { parseChatPayload } from '../../src/lib/validation.mjs';
import { limitarGlobal, limitarPorCliente } from '../../src/lib/rate-limit.mjs';
import { generarRespuesta } from '../../src/services/ai.service.mjs';

export default createHandler(async ({ req, ip }) => {
  const { openai, limits } = getConfig();
  if (!openai.apiKey) {
    throw unavailable('La IA todavía no está configurada. Falta la clave de API en las variables de entorno del servidor.', 'ai_not_configured');
  }
  const { messages } = parseChatPayload(await readJson(req, 24 * 1024));
  await limitarPorCliente({ scope: 'chat-min', ip, limite: limits.chatPerMinute, ventanaSeg: 60, mensaje: 'Has enviado varios mensajes seguidos. Espera un minuto e inténtalo de nuevo.' });
  await limitarPorCliente({ scope: 'chat-dia', ip, limite: limits.chatPerDay, ventanaSeg: 86400, mensaje: 'Has alcanzado el límite diario de mensajes. Vuelve mañana o contacta a quien administra UNMUTE.' });
  await limitarGlobal({ scope: 'chat-dia', limite: limits.chatGlobalPerDay, ventanaSeg: 86400, mensaje: 'UNMUTE IA alcanzó su límite de uso de hoy. Inténtalo mañana.' });
  return json(await generarRespuesta(messages));
}, { methods: ['POST'] });

export const config = { path: '/api/chat' };
