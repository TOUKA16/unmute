/* Noticias públicas (solo contenido PUBLICADO, de la más reciente a la más antigua):
     GET /api/news          lista (sin el contenido completo)
     GET /api/news/:slug    una noticia con su contenido
   Sin caché compartida obsoleta: el navegador y la CDN deben revalidar en cada consulta. */
import { createHandler, json } from '../../src/lib/http.mjs';
import { notFound } from '../../src/lib/errors.mjs';
import { isSlug } from '../../src/lib/validation.mjs';
import { listarPublicas, obtenerPublica } from '../../src/services/news.service.mjs';

const CACHE = { 'Cache-Control': 'public, max-age=0, must-revalidate' };

export default createHandler(async ({ params }) => {
  if (params.slug) {
    if (!isSlug(params.slug)) throw notFound('Esa noticia no existe o no está publicada.');
    return json({ news: await obtenerPublica(params.slug) }, 200, CACHE);
  }
  return json({ news: await listarPublicas() }, 200, CACHE);
}, { methods: ['GET'] });

export const config = { path: ['/api/news', '/api/news/:slug'] };
