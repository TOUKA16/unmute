/* Administración de noticias (todas las rutas exigen sesión de administrador verificada en el servidor):
     GET    /api/admin/news                 lista (también borradores)
     POST   /api/admin/news                 crear
     GET    /api/admin/news/:id             ver
     PATCH  /api/admin/news/:id             modificar
     DELETE /api/admin/news/:id             eliminar
     POST   /api/admin/news/:id/publish     publicar (la fecha la fija la base de datos)
     POST   /api/admin/news/:id/unpublish   despublicar (vuelve a borrador) */
import { createHandler, json, readJson } from '../../src/lib/http.mjs';
import { badRequest, methodNotAllowed, notFound } from '../../src/lib/errors.mjs';
import { NEWS_STATUSES, isUuid, parseNewsInput } from '../../src/lib/validation.mjs';
import { requerirAdmin } from '../../src/services/auth.service.mjs';
import * as noticias from '../../src/services/news.service.mjs';

export default createHandler(async ({ req, url, method }) => {
  const { token } = await requerirAdmin(req); // primero identidad y permisos; después, cualquier otra cosa
  const [, , , id, accion] = url.pathname.replace(/\/+$/, '').split('/').filter(Boolean); // api, admin, news, id?, accion?

  if (!id) {
    if (method === 'GET') {
      const status = url.searchParams.get('status') || undefined;
      if (status && !NEWS_STATUSES.includes(status)) throw badRequest('El estado no es válido.', 'invalid_status');
      return json({ news: await noticias.adminListar(token, { status }) });
    }
    if (method === 'POST') return json({ news: await noticias.adminCrear(token, parseNewsInput(await readJson(req, 24 * 1024))) }, 201);
    throw methodNotAllowed(['GET', 'POST']);
  }

  if (!isUuid(id)) throw notFound('No se encontró esa noticia.');
  if (accion) {
    if (method !== 'POST') throw methodNotAllowed(['POST']);
    if (accion === 'publish') return json({ news: await noticias.adminCambiarEstado(token, id, 'published') });
    if (accion === 'unpublish') return json({ news: await noticias.adminCambiarEstado(token, id, 'draft') });
    throw notFound();
  }
  if (method === 'GET') return json({ news: await noticias.adminObtener(token, id) });
  if (method === 'PATCH') {
    const cambios = parseNewsInput(await readJson(req, 24 * 1024), { partial: true });
    if (!Object.keys(cambios).length) throw badRequest('No hay cambios que guardar.', 'empty_patch');
    return json({ news: await noticias.adminActualizar(token, id, cambios) });
  }
  if (method === 'DELETE') { await noticias.adminEliminar(token, id); return json({ ok: true }); }
  throw methodNotAllowed(['GET', 'PATCH', 'DELETE']);
}, { methods: ['GET', 'POST', 'PATCH', 'DELETE'] });

export const config = { path: ['/api/admin/news', '/api/admin/news/:id', '/api/admin/news/:id/:action'] };
