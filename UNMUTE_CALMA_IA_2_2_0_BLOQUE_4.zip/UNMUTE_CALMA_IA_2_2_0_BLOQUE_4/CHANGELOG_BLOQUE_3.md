# CHANGELOG · BLOQUE 3 — Datos curiosos y noticias (v2.1.0)
Base: `UNMUTE_BLOQUE_2.zip`. Alcance respetado: sin cambios en autenticación, consentimiento del chat, rate limiting, diario ni tecnologías.

## Funcionalidades implementadas
- **Datos curiosos (admin)**: listar, buscar por título, filtrar por estado, crear, editar, guardar borrador, publicar/despublicar y eliminar con diálogo de confirmación. Campos: título, descripción, contenido, categoría, fuente URL, fecha de revisión, icono, imagen e identificador (opcional, solo al crear). Reutiliza `resources` (`resource_type='fact'`) y `/api/admin/resources`; la regla «sin fuente y fecha de revisión no se publica» ya existía en backend y base de datos y ahora también se valida en el formulario.
- **Un minuto para aprender**: tarjeta en Inicio conectada a `/api/facts/today` (título, descripción, categoría, fuente y fecha de revisión). Usa la fecha del dispositivo, así que no cambia al recargar. Si falla, muestra un aviso con «Reintentar» y el resto de UNMUTE sigue funcionando. No existía antes: se creó la tarjeta.
- **Noticias del admin** (pestaña con ese nombre exacto): lista, indicadores (total / publicadas / borradores), búsqueda por título, filtro por estado, formulario de creación y edición, publicar/despublicar, eliminar con confirmación, mensajes de éxito/error, estados de carga y lista vacía. Categorías: las 6 sugeridas (validadas en servidor y en la base de datos).
- **Noticias públicas**: sección «Noticias» (lista + lector con contenido completo), `GET /api/news` y `GET /api/news/:slug`, solo publicadas, de más reciente a más antigua, con `Cache-Control: public, max-age=0, must-revalidate`.
- **Decisión de almacenamiento**: tabla `news` propia (no `resources`), porque `resources` tiene un `CHECK` de tipos sin «news», carece de fecha de publicación gestionada por el servidor y mezclaría noticias con `/api/resources` y sus indicadores.
- **Seguridad**: escritura solo con sesión admin verificada en backend (`requerirAdmin`) y RLS; los endpoints públicos usan la clave anónima y filtran `status=published`; no exponen `status`, `created_by` ni fechas internas; texto plano renderizado con `textContent` (sin `innerHTML`); el servidor rechaza etiquetas HTML y URLs de imagen que no sean https; la fecha de publicación la fija un trigger SQL y se ignora la que envíe el cliente.

## Archivos principales
Nuevos: `supabase/migrations/003_news.sql`, `src/services/news.service.mjs`, `netlify/functions/news.mjs`, `netlify/functions/admin-news.mjs`, `public/js/content.js`, `tests/bloque3.test.mjs`.
Modificados: `src/lib/validation.mjs` (`parseNewsInput`), `src/lib/supabase.mjs` (mensajes de error neutrales), `public/index.html`, `public/js/app.js` (vista «noticias» + evento `unmute:vista`), `public/css/styles.css`, `public/admin.html`, `public/js/admin.js`, `public/css/admin.css`, `netlify.toml` (`img-src … https:`), `scripts/check.mjs`, `tests/helpers/mock-services.mjs` (tabla `news` simulada), `README.md`, `CHANGELOG.md`, `package.json` (2.1.0).

## Migraciones
`003_news.sql` (nueva; no modifica 001/002). **Pendiente de ejecutar** en Supabase → SQL Editor.

## Resultados de las comprobaciones (Supabase y OpenAI SIMULADOS)
1. **Datos curiosos** — OK. Crear → editar → publicar → leer por endpoint público; sin fuente, sin fecha o solo con fuente no se publica (por `/publish`, `PATCH` y `POST`); borradores nunca públicos; dato del día estable por fecha.
2. **Noticias** — OK. Crear → borrador → publicar → editar → despublicar → eliminar; orden descendente; validaciones (HTML, categoría, https, slug repetido, publicar sin contenido).
3. **Seguridad** — OK. Visitante (401), cuenta sin rol admin (403) y token inventado (401) no pueden crear, editar, publicar ni borrar; endpoints públicos sin borradores ni campos internos; sin métodos de escritura públicos (405).
4. **Multidispositivo** — OK con Supabase **simulado**: un segundo y tercer cliente independientes ven lo publicado y dejan de verlo al despublicar.
5. **Regresión** — `npm test`: 70/70 (61 previas + 9 nuevas); `npm run seed:check`: al día; `npm run check`: 44 correctas, 0 errores, 1 advertencia previa (el script `e2e` declarado no existe; viene del Bloque 2).
Extra: recorrido real en Chromium (script temporal, no incluido) del flujo admin → público en móvil y escritorio, sin errores de CSP ni de consola salvo el 400 esperado al intentar publicar sin fuente.

## Pendientes y limitaciones
- **Nada de esto se probó con servicios reales**: el SQL de `003_news.sql` (trigger, RLS, `CHECK`) no se ha ejecutado en PostgreSQL real; el mock solo imita su comportamiento.
- No se pudo probar una imagen https externa real (sin red en el entorno); la CSP admite `https:` en `img-src` y, si una imagen falla, la noticia se lee igual.
- Para ver algo en producción: ejecutar 003 en Supabase, verificar tras desplegar en Netlify. Los 10 datos curiosos iniciales (ya publicados, con fuente y fecha de revisión) y los demás recursos de la semilla no se modificaron, así que la tarjeta «Un minuto para aprender» funciona en cuanto exista la base de datos con la semilla.
- «Resumen» del panel no cuenta noticias (los indicadores están en la propia pestaña).
- El lector de noticias es texto plano (sin negritas ni enlaces), por seguridad.
