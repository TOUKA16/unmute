-- ==========================================================================
-- UNMUTE · Migración 003 · Noticias públicas
-- Cómo ejecutarla: Supabase → SQL Editor → New query → pega TODO este archivo → Run.
-- Requiere haber ejecutado 001 (usa public.is_admin() y public.set_updated_at()).
-- Es segura de repetir: no borra ni modifica datos existentes de otras tablas.
-- Por qué una tabla propia y no «resources»: resources limita resource_type a tool/guide/article/fact,
-- no tiene fecha de publicación gestionada por el servidor y mezclaría noticias con el catálogo
-- (aparecerían en /api/resources y en sus indicadores).
-- ==========================================================================

create table if not exists public.news (
  id           uuid primary key default gen_random_uuid(),
  slug         text not null unique check (char_length(slug) <= 80 and slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  title        text not null check (char_length(title) between 3 and 140),
  description  text not null check (char_length(description) between 1 and 300),
  content      text not null default '' check (char_length(content) <= 8000),
  category     text not null check (category in (
                 'Novedades de UNMUTE', 'Bienestar emocional', 'Autocuidado',
                 'Actualizaciones', 'Recursos educativos', 'Información importante')),
  image_url    text check (image_url is null or (image_url ~* '^https://' and char_length(image_url) <= 500)),
  status       text not null default 'draft' check (status in ('draft', 'published')),
  published_at timestamptz,                       -- la fija el servidor (trigger); el navegador no puede elegirla
  created_by   uuid default auth.uid() references auth.users (id) on delete set null,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  constraint news_published_has_date check ((status = 'published') = (published_at is not null))
);
create index if not exists news_public_idx on public.news (status, published_at desc);

-- La fecha de publicación la decide la base de datos, no quien envía la petición:
--   · al pasar a «published» se fija now();  · mientras sigue publicada se conserva;  · en borrador queda vacía.
create or replace function public.news_set_dates() returns trigger
language plpgsql as $$
begin
  if new.status = 'published' then
    if tg_op = 'UPDATE' and old.status = 'published' then
      new.published_at := old.published_at;
    else
      new.published_at := now();
    end if;
  else
    new.published_at := null;
  end if;
  if tg_op = 'UPDATE' then new.created_by := old.created_by; new.created_at := old.created_at; end if;
  return new;
end $$;

drop trigger if exists news_set_dates on public.news;
create trigger news_set_dates before insert or update on public.news
  for each row execute function public.news_set_dates();

drop trigger if exists news_set_updated_at on public.news;
create trigger news_set_updated_at before update on public.news
  for each row execute function public.set_updated_at();

-- ---------- Seguridad a nivel de fila (mismo patrón que resources) ----------
alter table public.news enable row level security;
revoke all on public.news from anon, authenticated;
grant select on public.news to anon, authenticated;
grant insert, update, delete on public.news to authenticated;

drop policy if exists news_select_published on public.news;
create policy news_select_published on public.news for select to anon, authenticated using (status = 'published');
drop policy if exists news_select_admin on public.news;
create policy news_select_admin on public.news for select to authenticated using (public.is_admin());
drop policy if exists news_insert_admin on public.news;
create policy news_insert_admin on public.news for insert to authenticated with check (public.is_admin());
drop policy if exists news_update_admin on public.news;
create policy news_update_admin on public.news for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists news_delete_admin on public.news;
create policy news_delete_admin on public.news for delete to authenticated using (public.is_admin());
