-- ==========================================================================
-- UNMUTE · Migración 001 · Esquema inicial
-- Cómo ejecutarla: Supabase → SQL Editor → New query → pega TODO este archivo → Run.
-- Después ejecuta 002_seed_resources.sql (contenido inicial).
-- Qué guarda esta base de datos: catálogo de recursos, datos curiosos, mensajes del formulario
-- de contacto, roles de administración y contadores de límite de uso.
-- Qué NO guarda: el diario emocional (vive en el navegador) ni las conversaciones con la IA.
-- ==========================================================================

-- ---------- Perfiles (rol de cada cuenta de Supabase Auth) ----------
create table if not exists public.profiles (
  id         uuid primary key references auth.users (id) on delete cascade,
  role       text not null default 'user' check (role in ('user', 'admin')),
  created_at timestamptz not null default now()
);

-- ---------- Recursos y datos curiosos ----------
create table if not exists public.resources (
  id            uuid primary key default gen_random_uuid(),
  slug          text not null unique check (char_length(slug) <= 80 and slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  title         text not null check (char_length(title) between 3 and 140),
  description   text not null check (char_length(description) between 1 and 600),
  content       text not null default '' check (char_length(content) <= 8000),   -- instrucciones de uso o texto largo
  category      text not null check (char_length(category) between 1 and 60),
  resource_type text not null check (resource_type in ('tool', 'guide', 'article', 'fact')),
  icon          text check (icon is null or icon ~ '^[a-z0-9-]{1,40}$'),
  image_url     text check (image_url is null or image_url ~* '^https://'),
  action_url    text check (action_url is null or action_url ~ '^(#[a-z0-9/-]{1,60}|https://.+)$'),
  source_url    text check (source_url is null or source_url ~* '^https?://'),
  status        text not null default 'draft' check (status in ('draft', 'published', 'archived')),
  featured      boolean not null default false,
  reviewed_at   date,                                                              -- fecha de revisión humana contra la fuente
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  -- Regla editorial: un dato curioso solo puede estar publicado con fuente y fecha de revisión.
  constraint facts_need_source_when_published
    check (not (resource_type = 'fact' and status = 'published') or (source_url is not null and reviewed_at is not null))
);
create index if not exists resources_public_idx on public.resources (status, resource_type, category);

create or replace function public.set_updated_at() returns trigger
language plpgsql as $$
begin
  new.updated_at = now();
  return new;
end $$;

drop trigger if exists resources_set_updated_at on public.resources;
create trigger resources_set_updated_at before update on public.resources
  for each row execute function public.set_updated_at();

-- ---------- Mensajes de contacto ----------
create table if not exists public.contact_messages (
  id         uuid primary key default gen_random_uuid(),
  name       text check (name is null or char_length(name) <= 80),
  email      text check (email is null or char_length(email) <= 120),
  category   text not null check (category in ('consulta', 'sugerencia', 'reporte_tecnico', 'otro')),
  message    text not null check (char_length(message) between 10 and 2000),
  status     text not null default 'new' check (status in ('new', 'read', 'resolved', 'archived')),
  created_at timestamptz not null default now()
);
create index if not exists contact_messages_status_idx on public.contact_messages (status, created_at desc);

-- ---------- Límite de uso compartido entre todas las instancias del backend ----------
-- Guarda un identificador no reversible (HMAC de la IP) y un contador temporal. Nunca contenido.
create table if not exists public.rate_limits (
  bucket       text primary key,
  window_start timestamptz not null default now(),
  hits         integer not null default 0
);

-- Cuenta una solicitud de forma atómica y responde si está permitida (ventana fija).
create or replace function public.consume_rate_limit(p_bucket text, p_limit integer, p_window_seconds integer)
returns jsonb
language plpgsql security definer set search_path = public as $$
declare
  v_now    timestamptz := now();
  v_window interval    := make_interval(secs => p_window_seconds);
  v_row    public.rate_limits%rowtype;
begin
  insert into public.rate_limits as r (bucket, window_start, hits)
  values (p_bucket, v_now, 1)
  on conflict (bucket) do update
    set hits         = case when r.window_start <= v_now - v_window then 1 else r.hits + 1 end,
        window_start = case when r.window_start <= v_now - v_window then v_now else r.window_start end
  returning r.* into v_row;

  -- Limpieza ocasional de contadores viejos (≈ 2 % de las llamadas).
  if random() < 0.02 then
    delete from public.rate_limits where window_start < v_now - interval '2 days';
  end if;

  return jsonb_build_object(
    'allowed',     v_row.hits <= p_limit,
    'remaining',   greatest(p_limit - v_row.hits, 0),
    'retry_after', case when v_row.hits <= p_limit then 0
                        else greatest(ceil(extract(epoch from (v_row.window_start + v_window - v_now)))::integer, 1) end
  );
end $$;

-- ---------- ¿La persona autenticada es administradora? ----------
-- security definer: lee profiles sin depender de las políticas de esa tabla (evita recursión).
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.profiles p where p.id = auth.uid() and p.role = 'admin');
$$;

-- ==========================================================================
-- Seguridad a nivel de fila (RLS). Todas las tablas la tienen activada.
-- ==========================================================================
alter table public.profiles         enable row level security;
alter table public.resources        enable row level security;
alter table public.contact_messages enable row level security;
alter table public.rate_limits      enable row level security;

-- Permisos de tabla explícitos (no dependemos de los permisos por defecto de Supabase).
revoke all on public.profiles, public.resources, public.contact_messages, public.rate_limits from anon, authenticated;
grant select on public.resources to anon, authenticated;
grant insert, update, delete on public.resources to authenticated;
grant select on public.profiles to authenticated;
grant select, update on public.contact_messages to authenticated;
-- rate_limits: ningún permiso para anon/authenticated (solo la clave de servicio, que se salta RLS).

-- profiles: cada persona solo puede leer su propia fila. Nadie escribe desde el navegador:
-- el rol 'admin' solo se concede a mano desde el SQL Editor (ver el final de este archivo).
drop policy if exists profiles_select_own on public.profiles;
create policy profiles_select_own on public.profiles for select to authenticated using (id = auth.uid());

-- resources: el público solo lee lo publicado; solo administración lee todo y escribe.
drop policy if exists resources_select_published on public.resources;
create policy resources_select_published on public.resources for select to anon, authenticated using (status = 'published');
drop policy if exists resources_select_admin on public.resources;
create policy resources_select_admin on public.resources for select to authenticated using (public.is_admin());
drop policy if exists resources_insert_admin on public.resources;
create policy resources_insert_admin on public.resources for insert to authenticated with check (public.is_admin());
drop policy if exists resources_update_admin on public.resources;
create policy resources_update_admin on public.resources for update to authenticated using (public.is_admin()) with check (public.is_admin());
drop policy if exists resources_delete_admin on public.resources;
create policy resources_delete_admin on public.resources for delete to authenticated using (public.is_admin());

-- contact_messages: el público NO puede insertar ni leer directamente (el envío pasa por la función
-- /api/contact, que valida y usa la clave de servicio). Solo administración lee y cambia el estado.
drop policy if exists messages_select_admin on public.contact_messages;
create policy messages_select_admin on public.contact_messages for select to authenticated using (public.is_admin());
drop policy if exists messages_update_admin on public.contact_messages;
create policy messages_update_admin on public.contact_messages for update to authenticated using (public.is_admin()) with check (public.is_admin());

-- Funciones: solo las puede ejecutar quien debe.
revoke all on function public.consume_rate_limit(text, integer, integer) from public, anon, authenticated;
grant execute on function public.consume_rate_limit(text, integer, integer) to service_role;
revoke all on function public.is_admin() from public;
grant execute on function public.is_admin() to anon, authenticated, service_role;

-- ==========================================================================
-- PASO MANUAL (no se ejecuta solo): crear la primera cuenta administradora
--   1) Supabase → Authentication → Users → Add user (correo y contraseña; marca «Auto Confirm User»).
--   2) Ejecuta esto una sola vez en el SQL Editor, con TU correo:
--
--   insert into public.profiles (id, role)
--   select id, 'admin' from auth.users where email = 'tu-correo@ejemplo.com'
--   on conflict (id) do update set role = 'admin';
--
--   3) Recomendado: Authentication → Sign In / Providers → desactiva «Allow new users to sign up»
--      (UNMUTE no tiene registro público).
-- ==========================================================================
