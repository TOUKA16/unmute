# CHANGELOG · Bloque 2 · Protección de recursos y recuperación del panel administrativo

Versión: 2.0.2 (antes 2.0.1). Base: `unmute-bloque1-v2_0_1.zip` (conservadas las reparaciones del Bloque 1; no se tocó ningún archivo del chat, del consentimiento ni de los límites de uso).
Estado final: **TERMINADO** para las tres tareas del bloque, con las limitaciones de validación indicadas más abajo (no se probó contra Supabase ni Netlify reales).

---

## 1. Archivos

### Creados
| Archivo | Para qué |
|---|---|
| `public/admin.html` | Página administrativa (login, vista de reintento, panel inicial). |
| `public/js/admin.js` | Lógica de la página: login, verificación de sesión, panel, cierre de sesión. Sin `innerHTML`. |
| `public/css/admin.css` | Solo lo que `styles.css` no cubre (la CSP del sitio prohíbe estilos y scripts «en línea», por eso son archivos aparte). |
| `scripts/check.mjs` | Comprobación estática: `npm run check`. |
| `tests/admin-page.test.mjs` | 7 pruebas: rutas, CSP, semilla no descargable, catálogo público sin borradores (con los 18 recursos reales), flujo de administración con Supabase simulado. |
| `tests/check.test.mjs` | 6 pruebas de `check.mjs` (pasa en el proyecto real y falla con código 1 al reintroducir cada problema, en copias temporales). |
| `CHANGELOG_BLOQUE_2.md` | Este documento. |

### Movidos (contenido idéntico, verificado byte a byte)
- `public/data/resources-seed.json` → `src/data/resources-seed.json`. La carpeta `public/data/` se eliminó al quedar vacía.

### Modificados
| Archivo | Cambio |
|---|---|
| `scripts/build-seed.mjs` | `ORIGEN` apunta a `src/data/resources-seed.json`; comentarios y mensaje actualizados. |
| `supabase/migrations/002_seed_resources.sql` | Regenerada con `npm run seed:build`. **Única diferencia: la línea de comentario de cabecera** (`desde src/data/…` en lugar de `desde public/data/…`). Las 18 filas y el SQL ejecutable son idénticos. |
| `netlify.toml` | Añadida redirección `/admin/` → `/admin.html` (200); cabeceras `X-Robots-Tag: noindex` y `Cache-Control: no-store` también para `/admin` y `/admin/` (antes solo `/admin.html`). Sin cambios en CSP ni en el resto. |
| `server.js` | El servidor local también sirve `/admin/` (igual que la redirección de Netlify). Una línea. |
| `package.json` | Versión 2.0.2. Los scripts no cambian. |
| `README.md`, `CHANGELOG.md` | Secciones breves sobre el panel, la semilla y `npm run check`; entrada del Bloque 2. |

### Eliminados
- `public/data/resources-seed.json` (movido) y la carpeta `public/data/`.

---

## 2. Tarea 1 · Semilla fuera de `public/`
- Referencias encontradas al JSON: solo `scripts/build-seed.mjs` y el comentario de la migración 002. **El frontend nunca lo descargaba** (no había ningún `fetch` a él), así que el catálogo público no dependía de él y no hizo falta tocar `app.js`.
- `npm run seed:build` → 18 recursos; `npm run seed:check` → «Semilla al día».
- La semilla contiene 16 publicados (10 datos curiosos, 5 herramientas, 1 guía) y 2 borradores. Con los 18 cargados en el Supabase simulado, `/api/resources` entrega 16, `/api/resources/<borrador>` da 404 y `/api/facts/today` nunca devuelve un borrador (40 desplazamientos probados).
- `/data/resources-seed.json`, `/src/data/resources-seed.json` y una ruta con `%2e%2e` dan 404/403 en el servidor local.

## 3. Tarea 2 · `/admin`
Reutiliza el backend existente sin cambiarlo: `POST /api/admin/login`, `GET /api/admin/session`, `POST /api/admin/logout` y `GET /api/admin/stats`. El rol `admin` lo sigue comprobando el servidor (`requerirAdmin`).

- **Login**: correo y contraseña con validación, errores por campo (`aria-invalid`, foco en el primero con error), indicador de carga, botón bloqueado mientras se envía (varios clics/Enter = **una** sola petición), mensajes comprensibles para 400/401/403/429/503/sin conexión. La contraseña se vacía tras cada intento.
- **Sesión**: el token se guarda solo en `sessionStorage` (esta pestaña; se borra al cerrarla) junto con su caducidad. No hay refresh token (el backend no lo entrega). Al cargar y al volver a la pestaña se verifica con `GET /api/admin/session`; 401/403 → vuelve al login con aviso y borra la sesión; fallo temporal (sin conexión, 5xx) → vista «Reintentar» sin borrar la sesión.
- **Panel inicial**: identidad UNMUTE, cuenta autenticada, navegación Resumen/Sesión, estado de la sesión y **Cerrar sesión** real (invalida el token en el servidor; si el servidor no responde, la sesión local se borra igualmente y se avisa).
- **Decisión de alcance**: «Resumen» muestra los recuentos de `GET /api/admin/stats` (endpoint ya existente; solo números, sin datos privados) para que el panel tenga contenido real y demuestre que el token funciona. No hay editores ni noticias: se anuncian en un texto, no con botones sin función.
- **Seguridad**: todo lo que viene del servidor se pinta con `textContent`; sin claves ni nombres de variables secretas; `credentials: 'omit'`; mostrar el panel a mano desde la consola no da acceso (la API sigue respondiendo 401).
- **Rutas**: `/admin`, `/admin/` y `/admin.html` funcionan. **Error encontrado y corregido durante las pruebas en navegador**: con rutas relativas (`css/…`), en `/admin/` los estilos y scripts daban 404; `admin.html` usa rutas absolutas (`/css/…`, `/js/…`) y `check.mjs` lo vigila.

## 4. Tarea 3 · `scripts/check.mjs`
Solo lee; sin credenciales ni red; ignora `node_modules`, `.netlify`, `.git`. Código de salida 1 si algo falla; las advertencias (⚠) no fallan. Comprueba: archivos esenciales y `.gitignore`; las 7 funciones de Netlify (export por defecto + `config.path` bajo `/api/`); migraciones; generador de semilla; semilla **ausente** de `public/` y **presente** en `src/data/` (válida, slugs únicos) y migración 002 coincidente con ella; página administrativa y sus archivos; `netlify.toml` (publish, functions, redirecciones de `/admin` y `/admin/`, ninguna redirección que intercepte `/api/*`, CSP y cabeceras, noindex/no-store); referencias locales de los HTML y ausencia de código en línea que la CSP bloquearía; sintaxis de los 29 archivos JS/MJS (los de `public/` como scripts clásicos, los demás con `node --check`); scripts de `package.json`; búsqueda de secretos evidentes. Opción `--root <carpeta>` para comprobar otra copia.

**Advertencia conocida (no es un error de este bloque):** `npm run e2e` apunta a `tests/e2e-smoke.mjs`, que no existe. No se creó una prueba E2E ficticia ni se tocó `package.json`; `check` lo muestra como ⚠ y no como fallo.

---

## 5. Pruebas y su nivel de validación

| Nivel | Qué se ejecutó | Resultado |
|---|---|---|
| Automatizadas con servicios **simulados** | `npm test` (47 previas + 14 nuevas) | 61 de 61 correctas |
| Generador | `npm run seed:build`, `npm run seed:check` | 18 recursos; semilla al día |
| Estática | `npm run check` | 40 correctas, 0 errores, 1 advertencia (`e2e`) |
| Local real (servidor del proyecto, **sin** Supabase) | `curl` a `/admin`, `/admin/`, `/admin.html`, `/data/resources-seed.json`, `/api/health`, `/api/admin/session`, `/api/resources` | 200, 200, 200, 404, 200, 503 `database_not_configured`, 503 `database_not_configured` |
| Navegador real (Chromium/Playwright) contra el servidor local con Supabase **simulado** | 31 comprobaciones: validación, errores, doble envío, 403, login, resumen, recarga, fallo 503 + reintento, token invalidado, token inventado, manipulación del DOM, cierre de sesión, 3 rutas, 375/768/1280 px y tema oscuro sin desbordamiento horizontal, sin violaciones de CSP | 31 de 31 correctas |
| Integridad del ZIP | `unzip -t`; ZIP extraído en carpeta limpia y repetidos `npm test`, `seed:check` y `check` | ver sección 7 |

**No probado (requiere servicios reales):** inicio de sesión contra Supabase Auth real, políticas RLS reales, despliegue en Netlify (que las redirecciones y las cabeceras de `/admin` y `/admin/` se apliquen como se espera), `/admin` con HTTPS. «Administrador autenticado» se probó **solo con simulaciones**.

---

## 6. Limitaciones, hallazgos y pendientes
1. **Sin renovación de sesión**: el backend no entrega refresh token, así que al vencer el token (normalmente en torno a una hora, según Supabase) hay que iniciar sesión de nuevo.
2. **`sessionStorage` vs XSS**: el token es accesible por JavaScript de la misma pestaña. Se mitiga con la CSP estricta, sin `innerHTML` y sin scripts de terceros; una cookie `HttpOnly` exigiría cambiar el backend (fuera de alcance).
3. **Servidor local**: solo aplica las cabeceras del bloque `/*` de `netlify.toml`; `noindex`/`no-store` de `/admin*` solo existen en Netlify (verificadas estáticamente por `check`, no en ejecución).
4. **Historial**: versiones ya desplegadas o commits anteriores pueden seguir conteniendo la copia pública del JSON (son borradores editoriales, sin secretos). Tras desplegar esta versión deja de servirse.
5. **Migración 002**: si ya se ejecutó en tu Supabase, no hace falta repetirla (cambió solo un comentario y es idempotente: `on conflict do nothing`).
6. **Fuera de alcance, no corregido**: `npm run e2e` apunta a un archivo inexistente; `README.md` conserva secciones anteriores (por ejemplo, la guía de hosting menciona Render/Railway); la carpeta `docs/` sigue vacía.
7. La prueba de navegador (Playwright) se ejecutó de forma puntual y **no forma parte del ZIP** (Playwright no es dependencia del proyecto); las pruebas reproducibles son las de `npm test`.
8. Siguiente bloque (no iniciado): gestión de datos curiosos y noticias.

---

## 7. Cómo verificar el panel (instrucciones breves)
1. En la carpeta del proyecto: `npm start` y abre http://localhost:3000/admin. Debes ver solo el formulario de acceso.
2. Sin Supabase configurado (`.env` sin `SUPABASE_URL`/`SUPABASE_ANON_KEY`), al enviar el formulario verás «La administración todavía no está conectada a Supabase.» (503): es lo esperado.
3. Con Supabase configurado: crea tu cuenta administradora siguiendo el «PASO MANUAL» del final de `supabase/migrations/001_initial_schema.sql`, entra en `/admin` y comprueba: aparece tu correo, el resumen con los recuentos y el botón **Cerrar sesión**.
4. Tras cerrar sesión (o al cerrar la pestaña), recargar `/admin` debe mostrar de nuevo el formulario.
5. Comprueba que http://localhost:3000/data/resources-seed.json da «No encontrado».
6. `npm test`, `npm run seed:check` y `npm run check` deben terminar sin errores.
