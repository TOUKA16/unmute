# CHANGELOG · BLOQUE 4 · UNMUTE 2.2.0
Base: `UNMUTE_BLOQUE_3.zip` (2.1.0). Alcance: Inicio con dos tarjetas, vista Recursos y nueva navegación. Nada más.

## Archivos
Modificados: `public/index.html`, `public/css/styles.css`, `public/js/app.js`, `public/js/content.js`, `package.json` (solo `version`), `CHANGELOG.md`.
Nuevos: `public/js/resources.js`, `tests/bloque4.test.mjs`, este archivo.
No tocados: backend (`src/`, `netlify/`), `supabase/`, `netlify.toml`, `admin.*`, `ai-chat.js`, el almacenamiento del diario.

## Decisiones técnicas
- **Dato al azar sin API nueva.** El servidor calcula `index = (día + offset) mod total`. Primera carga: `offset` aleatorio (0–9999). «Ver otro dato»: con `index`, `offset` y `total` de la respuesta anterior se obtiene la posición base del día y se pide un `offset` que lleva a una posición distinta de la actual. No depende de identificadores consecutivos ni de la cantidad de datos.
- **Noticia al azar.** Se pide `GET /api/news` (solo publicadas) y se elige en el navegador, sin depender del orden. «Ver otra» vuelve a consultar y excluye la actual si hay más de una.
- **Estabilidad.** Si una tarjeta ya tiene contenido, volver a Inicio no lo cambia; solo cambia al pulsar el botón o al recargar la página.
- **Datos curiosos fuera de Recursos.** Comparten tabla (`resource_type='fact'`) pero se muestran en «Un minuto para aprender»; Recursos los excluye en el navegador.
- **Botones solo a destinos reales.** Se aceptan `#diario`, `#acompanar`, `#historia`, `#pausa`, `#noticias`, `#ajustes` y enlaces `https`. Cualquier otra ruta no muestra botón.
- **Etiqueta «Acompañar» completa en móvil** (antes «IA»), porque con cinco accesos cabe incluso en 320 px.
- Inicio y Recursos usan hasta 60 rem de ancho; las demás vistas conservan su columna de lectura.

## Hallazgo (requiere decisión del propietario)
El recurso publicado **«Información confiable sobre salud mental»** (`biblioteca-informacion`) tiene `action_url = #recursos/informacion`, una pantalla que no existe, y su texto de pasos dice «Pulsa Abrir…». Por eso la tarjeta se muestra **sin botón** y con la nota «Todavía no está disponible dentro de la app», y no se muestran sus pasos. Corregirlo exigiría editar datos (seed/migración) o despublicarlo desde la administración; no se hizo por estar fuera del alcance.

## Pruebas
Ejecutadas con **servicios simulados** (Supabase y OpenAI simulados; no validan RLS, el trigger SQL ni Netlify reales):
- `npm test`: 74/74 (70 previas + 4 estáticas nuevas). `npm run check`: correcto (1 advertencia previa: `npm run e2e` declara un archivo inexistente). `npm run seed:check`: al día.
- Navegador (Chromium, servidor local con catálogo semilla real y 3 noticias publicadas + 1 borrador): 76/76. Cubre Inicio (selección, independencia, variedad, estados vacío/error/reintento, imagen rota, lector), Recursos (publicados, borradores ocultos, búsqueda, filtros, destinos, vacío, error), navegación (cinco accesos, menú Más con ratón y teclado, Esc, foco, Atrás/Adelante, hash inicial) y responsive (390 y 320 px, y 1280 px): orden de tarjetas, sin desbordamiento horizontal. Estas pruebas de navegador se ejecutaron con un script temporal fuera del proyecto; no se añadió infraestructura E2E.

## Pendiente
- Verificar contra un **Supabase real y Netlify desplegado**: lectura anónima con RLS, caché de `/api/resources` (60 s) y carga de imágenes externas.
- Decidir qué hacer con `biblioteca-informacion` (ver Hallazgo).
