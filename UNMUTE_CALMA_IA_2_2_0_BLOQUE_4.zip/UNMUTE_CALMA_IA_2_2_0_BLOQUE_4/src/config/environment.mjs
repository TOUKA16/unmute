/* ==========================================================
   UNMUTE · Configuración del backend (única fuente de variables de entorno)
   En Netlify se leen con Netlify.env.get(); en local y en pruebas, con process.env.
   Nada de este archivo se envía al navegador.
   ========================================================== */

/** Devuelve el valor de una variable de entorno o undefined si falta o está vacía. */
export function env(name) {
  try {
    // El objeto global Netlify solo existe dentro del runtime de Netlify Functions.
    if (typeof Netlify !== 'undefined' && Netlify?.env?.get) {
      const v = Netlify.env.get(name);
      if (v !== undefined && v !== null && String(v).trim() !== '') return String(v).trim();
    }
  } catch { /* fuera de Netlify: se usa process.env */ }
  const v = process.env[name];
  return v === undefined || String(v).trim() === '' ? undefined : String(v).trim();
}

/**
 * ¿El código se ejecuta dentro de Netlify (producción, deploy previews, branch deploys o «netlify dev»)?
 * Importante: NETLIFY y CONTEXT son variables de COMPILACIÓN y, según la documentación de Netlify,
 * no llegan a las funciones en ejecución. Por eso la señal principal es el objeto global «Netlify»
 * (solo existe en el runtime de Netlify Functions) y las variables reservadas de AWS Lambda
 * (donde Netlify ejecuta las funciones). NETLIFY/CONTEXT se miran solo como señal adicional.
 * Se usa para impedir que un modo pensado para desarrollo local se active en un entorno serverless.
 */
export function isNetlifyRuntime() {
  try { if (typeof Netlify !== 'undefined' && Netlify) return true; } catch { /* sin global Netlify */ }
  const e = process.env;
  if (e.NETLIFY === 'true' || e.NETLIFY_DEV === 'true') return true;
  if (['production', 'deploy-preview', 'branch-deploy'].includes(e.CONTEXT)) return true;
  return Boolean(e.AWS_LAMBDA_FUNCTION_NAME || e.LAMBDA_TASK_ROOT || e.AWS_EXECUTION_ENV);
}

const entero = (name, porDefecto) => {
  const n = Number.parseInt(env(name) ?? '', 10);
  return Number.isFinite(n) && n > 0 ? n : porDefecto;
};
const sinBarraFinal = (s) => (s ? s.replace(/\/+$/, '') : s);

/** Se calcula en cada llamada para que las pruebas puedan cambiar process.env. */
export function getConfig() {
  return {
    openai: {
      apiKey: env('OPENAI_API_KEY'),
      // El modelo es configurable: la cuenta de cada persona decide a qué modelos tiene acceso.
      model: env('OPENAI_MODEL') || 'gpt-6-luna',
      baseUrl: sinBarraFinal(env('OPENAI_BASE_URL')) || 'https://api.openai.com/v1',
      // Solo se envía si se define (los modelos sin razonamiento rechazan este parámetro).
      reasoningEffort: env('OPENAI_REASONING_EFFORT'),
      maxOutputTokens: entero('OPENAI_MAX_OUTPUT_TOKENS', 1200),
      timeoutMs: entero('OPENAI_TIMEOUT_MS', 45000)
    },
    supabase: {
      url: sinBarraFinal(env('SUPABASE_URL')),
      // Los nombres se mantienen por compatibilidad: aceptan las claves clásicas (anon/service_role)
      // y las nuevas (publishable/secret).
      anonKey: env('SUPABASE_ANON_KEY') || env('SUPABASE_PUBLISHABLE_KEY'),
      serviceKey: env('SUPABASE_SERVICE_ROLE_KEY') || env('SUPABASE_SECRET_KEY')
    },
    limits: {
      chatPerMinute: entero('CHAT_LIMIT_PER_MINUTE', 8),
      chatPerDay: entero('CHAT_LIMIT_PER_DAY', 80),
      chatGlobalPerDay: entero('CHAT_GLOBAL_LIMIT_PER_DAY', 3000), // tope de gasto de toda la aplicación
      contactPerHour: entero('CONTACT_LIMIT_PER_HOUR', 5),
      loginPer15Min: entero('LOGIN_LIMIT_PER_15_MIN', 10)
    },
    rateLimit: {
      // Contador en memoria SOLO para desarrollo local y solo si se pide de forma explícita con
      // RATE_LIMIT_DEV_MEMORY=true. Nunca se usa en Netlify (ver rate-limit.mjs). No apto para producción.
      devMemory: (env('RATE_LIMIT_DEV_MEMORY') || '').toLowerCase() === 'true'
    },
    allowedOrigins: (env('ALLOWED_ORIGINS') || '').split(',').map((s) => s.trim().replace(/\/+$/, '')).filter(Boolean),
    // Sal para convertir la IP en un identificador no reversible antes de contar solicitudes.
    rateLimitSalt: env('RATE_LIMIT_SALT') || 'unmute-sal-de-desarrollo'
  };
}
