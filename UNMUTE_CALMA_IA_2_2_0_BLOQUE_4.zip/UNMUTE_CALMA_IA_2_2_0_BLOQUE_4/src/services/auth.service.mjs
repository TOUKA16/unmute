/* ==========================================================
   UNMUTE · Autenticación y permisos de administración
   El navegador nunca decide quién es administrador: cada operación protegida llama a
   requerirAdmin(), que (1) le pregunta a Supabase Auth si el token es auténtico y vigente y
   (2) comprueba en la tabla profiles que el rol sea 'admin'. El rol no puede cambiarse desde el navegador.
   ========================================================== */
import * as sb from '../lib/supabase.mjs';
import { AppError, forbidden, unauthorized, unavailable } from '../lib/errors.mjs';
import { bearerToken } from '../lib/http.mjs';

function exigirAuth() {
  if (!sb.isConfigured()) throw unavailable('La administración todavía no está conectada a Supabase.', 'database_not_configured');
}

async function esAdmin(userId, token) {
  // Con el token de la propia persona: la política RLS solo le deja ver su fila.
  const filas = await sb.conDb(() => sb.rest({ table: 'profiles', token, query: { select: 'role', id: `eq.${userId}`, limit: 1 } }));
  return filas[0]?.role === 'admin';
}

export async function iniciarSesion(email, password) {
  exigirAuth();
  let sesion;
  try {
    sesion = await sb.authSignIn(email, password);
  } catch (err) {
    if (err instanceof sb.SupabaseError && [400, 401, 422].includes(err.status)) throw unauthorized('Correo o contraseña incorrectos.');
    if (err instanceof sb.SupabaseError && err.status === 429) throw new AppError(429, 'auth_rate_limited', 'Demasiados intentos. Espera unos minutos.', { retryAfter: 300 });
    throw sb.mapDbError(err);
  }
  if (!sesion?.access_token || !sesion?.user?.id || !(await esAdmin(sesion.user.id, sesion.access_token))) {
    // Se espera el cierre de sesión: en serverless, lo que queda pendiente al responder puede no ejecutarse.
    if (sesion?.access_token) await sb.authSignOut(sesion.access_token).catch(() => {});
    throw forbidden('Esta cuenta no tiene permisos de administración.');
  }
  return { accessToken: sesion.access_token, expiresIn: sesion.expires_in, user: { id: sesion.user.id, email: sesion.user.email } };
}

export async function requerirAdmin(req) {
  exigirAuth();
  const token = bearerToken(req);
  if (!token) throw unauthorized();
  let usuario;
  try {
    usuario = await sb.authGetUser(token);
  } catch (err) {
    if (err instanceof sb.SupabaseError && [400, 401, 403].includes(err.status)) throw unauthorized('Tu sesión expiró o no es válida. Inicia sesión de nuevo.');
    throw sb.mapDbError(err);
  }
  if (!usuario?.id || !(await esAdmin(usuario.id, token))) throw forbidden('No tienes permisos de administración.');
  return { token, user: { id: usuario.id, email: usuario.email } };
}

export async function cerrarSesion(token) {
  try { await sb.authSignOut(token); } catch { /* si el token ya caducó, la sesión ya no existe */ }
}
