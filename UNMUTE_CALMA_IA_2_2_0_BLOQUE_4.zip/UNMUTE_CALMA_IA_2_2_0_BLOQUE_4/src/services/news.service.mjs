/* ==========================================================
   UNMUTE · Noticias
   Lectura pública: clave anónima + RLS (solo filas publicadas). La consulta además filtra por estado.
   Administración: con el token de la persona administradora + RLS (is_admin()). Nunca usa la clave de servicio.
   La fecha de publicación la fija la base de datos (trigger); este servicio jamás la envía.
   ========================================================== */
import * as sb from '../lib/supabase.mjs';
import { notFound, unavailable } from '../lib/errors.mjs';
import { assertNewsPublishable } from '../lib/validation.mjs';

const COLUMNAS_LISTA = 'id,slug,title,description,category,image_url,published_at';
const COLUMNAS_DETALLE = `${COLUMNAS_LISTA},content`;

function exigirBaseDeDatos() {
  if (!sb.isConfigured()) throw unavailable('Las noticias todavía no están conectadas a la base de datos.', 'database_not_configured');
}

/* ---------- Lectura pública ---------- */
export async function listarPublicas({ limit = 50 } = {}) {
  exigirBaseDeDatos();
  return sb.conDb(() => sb.rest({ table: 'news', query: { select: COLUMNAS_LISTA, status: 'eq.published', order: 'published_at.desc', limit } }));
}

export async function obtenerPublica(slug) {
  exigirBaseDeDatos();
  const filas = await sb.conDb(() => sb.rest({ table: 'news', query: { select: COLUMNAS_DETALLE, slug: `eq.${slug}`, status: 'eq.published', limit: 1 } }));
  if (!filas.length) throw notFound('Esa noticia no existe o no está publicada.');
  return filas[0];
}

/* ---------- Administración (token de la persona + RLS) ---------- */
export async function adminListar(token, { status, limit = 500 } = {}) {
  const query = { select: '*', order: 'updated_at.desc', limit };
  if (status) query.status = `eq.${status}`;
  return sb.conDb(() => sb.rest({ table: 'news', token, query }));
}

export async function adminObtener(token, id) {
  const filas = await sb.conDb(() => sb.rest({ table: 'news', token, query: { select: '*', id: `eq.${id}`, limit: 1 } }));
  if (!filas.length) throw notFound('No se encontró esa noticia.');
  return filas[0];
}

export async function adminCrear(token, entrada) {
  assertNewsPublishable(entrada);
  const filas = await sb.conDb(() => sb.rest({ table: 'news', token, method: 'POST', body: entrada, prefer: 'return=representation' }));
  return filas[0];
}

export async function adminActualizar(token, id, cambios) {
  const actual = await adminObtener(token, id);
  assertNewsPublishable({ ...actual, ...cambios });
  const filas = await sb.conDb(() => sb.rest({ table: 'news', token, method: 'PATCH', query: { id: `eq.${id}` }, body: cambios, prefer: 'return=representation' }));
  if (!filas.length) throw notFound('No se encontró esa noticia.');
  return filas[0];
}

export const adminCambiarEstado = (token, id, status) => adminActualizar(token, id, { status });

export async function adminEliminar(token, id) {
  const filas = await sb.conDb(() => sb.rest({ table: 'news', token, method: 'DELETE', query: { id: `eq.${id}` }, prefer: 'return=representation' }));
  if (!filas.length) throw notFound('No se encontró esa noticia.');
}
