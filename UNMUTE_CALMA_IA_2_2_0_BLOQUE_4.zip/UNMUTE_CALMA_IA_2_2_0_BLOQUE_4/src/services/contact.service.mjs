/* ==========================================================
   UNMUTE · Mensajes de contacto
   Inserción: clave de servicio (el público NO tiene permiso directo sobre la tabla).
   Lectura y gestión: solo con el token de una persona administradora + RLS.
   Se guarda solo lo necesario: nombre y correo opcionales, tipo y mensaje. Sin IP.
   ========================================================== */
import * as sb from '../lib/supabase.mjs';
import { notFound, unavailable } from '../lib/errors.mjs';

export async function crearMensaje(valor) {
  if (!sb.isConfigured({ service: true })) {
    throw unavailable('El formulario todavía no está conectado a la base de datos.', 'database_not_configured');
  }
  await sb.conDb(() => sb.rest({ table: 'contact_messages', role: 'service', method: 'POST', body: valor }));
}

export async function listarMensajes(token, { status, limit = 200 } = {}) {
  const query = { select: 'id,name,email,category,message,status,created_at', order: 'created_at.desc', limit };
  if (status) query.status = `eq.${status}`;
  return sb.conDb(() => sb.rest({ table: 'contact_messages', token, query }));
}

export async function actualizarEstado(token, id, status) {
  const filas = await sb.conDb(() => sb.rest({ table: 'contact_messages', token, method: 'PATCH', query: { id: `eq.${id}` }, body: { status }, prefer: 'return=representation' }));
  if (!filas.length) throw notFound('No se encontró ese mensaje.');
  return filas[0];
}

export async function contarPorEstado(token) {
  const filas = await sb.conDb(() => sb.rest({ table: 'contact_messages', token, query: { select: 'status', limit: 1000 } }));
  const r = { total: filas.length, new: 0, read: 0, resolved: 0, archived: 0 };
  for (const f of filas) r[f.status] = (r[f.status] || 0) + 1;
  return r;
}
