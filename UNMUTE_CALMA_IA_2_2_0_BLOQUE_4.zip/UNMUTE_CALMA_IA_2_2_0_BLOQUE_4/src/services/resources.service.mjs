/* ==========================================================
   UNMUTE · Catálogo de recursos y datos curiosos
   Lectura pública: clave anónima + RLS (solo filas publicadas).
   Administración: con el token de la persona administradora + RLS (is_admin()).
   Este servicio nunca usa la clave de servicio.
   ========================================================== */
import * as sb from '../lib/supabase.mjs';
import { notFound, unavailable } from '../lib/errors.mjs';
import { assertPublishable } from '../lib/validation.mjs';

const COLUMNAS_PUBLICAS = 'id,slug,title,description,content,category,resource_type,icon,image_url,action_url,source_url,status,featured,reviewed_at,updated_at';

function exigirBaseDeDatos() {
  if (!sb.isConfigured()) throw unavailable('El catálogo todavía no está conectado a la base de datos.', 'database_not_configured');
}

/* ---------- Lectura pública ---------- */
export async function listarPublicos({ type, category, featured, limit = 200 } = {}) {
  exigirBaseDeDatos();
  const query = { select: COLUMNAS_PUBLICAS, status: 'eq.published', order: 'featured.desc,title.asc', limit };
  if (type) query.resource_type = `eq.${type}`;
  if (category) query.category = `eq.${category}`;
  if (featured !== undefined) query.featured = `eq.${featured}`;
  return sb.conDb(() => sb.rest({ table: 'resources', query }));
}

export async function obtenerPublico(slug) {
  exigirBaseDeDatos();
  const filas = await sb.conDb(() => sb.rest({ table: 'resources', query: { select: COLUMNAS_PUBLICAS, slug: `eq.${slug}`, status: 'eq.published', limit: 1 } }));
  if (!filas.length) throw notFound('Ese recurso no existe o no está publicado.');
  return filas[0];
}

/** Posición del dato según la fecha: no cambia al recargar, solo al cambiar de día (o con «offset»). */
export function indiceDelDia(fecha, offset, total) {
  const [y, m, d] = fecha.split('-').map(Number);
  const dia = Math.floor(Date.UTC(y, m - 1, d) / 86400000);
  return (((dia + offset) % total) + total) % total;
}

export async function datoDelDia({ fecha, offset = 0 }) {
  exigirBaseDeDatos();
  const datos = await sb.conDb(() => sb.rest({ table: 'resources', query: { select: COLUMNAS_PUBLICAS, status: 'eq.published', resource_type: 'eq.fact', order: 'slug.asc', limit: 500 } }));
  if (!datos.length) throw notFound('Todavía no hay datos publicados.', 'no_facts');
  const index = indiceDelDia(fecha, offset, datos.length);
  return { fact: datos[index], index, total: datos.length, date: fecha };
}

/* ---------- Administración (token de la persona + RLS) ---------- */
export async function adminListar(token, { type, status, limit = 500 } = {}) {
  const query = { select: '*', order: 'updated_at.desc', limit };
  if (type) query.resource_type = `eq.${type}`;
  if (status) query.status = `eq.${status}`;
  return sb.conDb(() => sb.rest({ table: 'resources', token, query }));
}

export async function adminObtener(token, id) {
  const filas = await sb.conDb(() => sb.rest({ table: 'resources', token, query: { select: '*', id: `eq.${id}`, limit: 1 } }));
  if (!filas.length) throw notFound('No se encontró ese recurso.');
  return filas[0];
}

export async function adminCrear(token, entrada) {
  assertPublishable(entrada);
  const filas = await sb.conDb(() => sb.rest({ table: 'resources', token, method: 'POST', body: entrada, prefer: 'return=representation' }));
  return filas[0];
}

export async function adminActualizar(token, id, cambios) {
  const actual = await adminObtener(token, id);
  assertPublishable({ ...actual, ...cambios });
  const filas = await sb.conDb(() => sb.rest({ table: 'resources', token, method: 'PATCH', query: { id: `eq.${id}` }, body: cambios, prefer: 'return=representation' }));
  if (!filas.length) throw notFound('No se encontró ese recurso.');
  return filas[0];
}

export const adminCambiarEstado = (token, id, status) => adminActualizar(token, id, { status });

export async function adminEliminar(token, id) {
  const filas = await sb.conDb(() => sb.rest({ table: 'resources', token, method: 'DELETE', query: { id: `eq.${id}` }, prefer: 'return=representation' }));
  if (!filas.length) throw notFound('No se encontró ese recurso.');
}

export async function adminEstadisticas(token) {
  const filas = await sb.conDb(() => sb.rest({ table: 'resources', token, query: { select: 'resource_type,status', limit: 1000 } }));
  const resumen = { total: filas.length, published: 0, draft: 0, archived: 0, byType: {} };
  for (const f of filas) {
    resumen[f.status] = (resumen[f.status] || 0) + 1;
    const t = (resumen.byType[f.resource_type] ||= { published: 0, draft: 0, archived: 0 });
    t[f.status] += 1;
  }
  return resumen;
}
