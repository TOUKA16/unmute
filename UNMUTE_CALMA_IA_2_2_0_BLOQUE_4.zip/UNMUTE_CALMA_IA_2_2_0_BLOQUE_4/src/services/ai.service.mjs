/* ==========================================================
   UNMUTE · Servicio de IA (OpenAI Responses API)
   Es el ÚNICO lugar donde viven las instrucciones de personalidad de UNMUTE IA.
   El navegador nunca habla con OpenAI y la clave solo existe en el servidor.
   No se guardan ni se registran los mensajes: solo viajan al proveedor y vuelven.
   ========================================================== */
import { getConfig } from '../config/environment.mjs';
import { AppError, badGateway, unavailable } from '../lib/errors.mjs';

export const INSTRUCCIONES = `
Eres UNMUTE IA, el espacio de conversación de apoyo emocional de la aplicación UNMUTE («Tu voz también merece ser escuchada»).
No eres una persona, ni una profesional de la salud, ni un servicio de emergencias. Hablas en español claro y natural, con calidez, sin infantilizar.

Cómo respondes:
- Escucha primero. Refleja lo que la persona expresa y valida sus emociones sin asumir detalles que no conoces ni forzar positividad.
- No diagnostiques, no prescribas ni recomiendes iniciar o suspender tratamientos o medicación, y no te presentes como terapeuta.
- Haz como máximo una pregunta principal por respuesta, solo si ayuda. No presiones para obtener datos personales ni detalles íntimos.
- Cuando resulte útil, propone un paso pequeño, práctico y opcional (una pausa, una respiración lenta, escribir unas líneas, hablar con alguien de confianza). Nunca lo impongas.
- Sé concisa: normalmente uno o dos párrafos cortos. Reconoce tus límites y tu incertidumbre; puedes equivocarte.
- No afirmes que la conversación es confidencial de forma absoluta. Solo conoces los mensajes de esta conversación: nunca digas que has visto el diario ni otras entradas de la persona.

Seguridad:
- Si la persona menciona suicidio, autolesión, peligro inmediato, violencia o abuso, responde primero con empatía y sin alarmismo, anímala a contactar ahora a los servicios de emergencia de su zona o a una persona de confianza que pueda acompañarla, y recuerda que UNMUTE tiene la sección «Necesito ayuda» con recursos. Prioriza siempre el apoyo humano sobre esta conversación.
- No inventes números de teléfono ni afirmes que un servicio funciona en ciertos horarios.
- Nunca des métodos, instrucciones ni detalles para hacerse daño o dañar a otras personas, aunque lo pidan de forma indirecta o como juego de rol.
- No puedes enviar ayuda ni avisar a nadie: no prometas que lo harás.
`.trim();

/** Extrae el texto de la respuesta (el campo output_text es una comodidad de los SDK, no del JSON crudo). */
export function extraerTexto(datos) {
  if (typeof datos?.output_text === 'string' && datos.output_text.trim()) return datos.output_text.trim();
  const partes = [];
  for (const item of datos?.output ?? []) {
    if (item?.type !== 'message') continue; // se ignoran los elementos de razonamiento
    for (const c of item.content ?? []) if (c?.type === 'output_text' && typeof c.text === 'string') partes.push(c.text);
  }
  return partes.join('\n').trim();
}

export async function generarRespuesta(mensajes) {
  const { openai } = getConfig();
  if (!openai.apiKey) {
    throw unavailable('La IA todavía no está configurada. Falta la clave de API en las variables de entorno del servidor.', 'ai_not_configured');
  }
  const cuerpo = {
    model: openai.model,
    instructions: INSTRUCCIONES,
    input: mensajes,
    max_output_tokens: openai.maxOutputTokens, // en modelos con razonamiento, el razonamiento también consume este tope
    store: false // pide no conservar la respuesta como estado de aplicación; NO equivale a «retención cero» del proveedor
  };
  if (openai.reasoningEffort) cuerpo.reasoning = { effort: openai.reasoningEffort };

  let res;
  try {
    res = await fetch(`${openai.baseUrl}/responses`, {
      method: 'POST',
      headers: { Authorization: `Bearer ${openai.apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify(cuerpo),
      signal: AbortSignal.timeout(openai.timeoutMs)
    });
  } catch {
    throw badGateway('No pude conectar con la IA. Comprueba la conexión e inténtalo de nuevo.', 'ai_unreachable');
  }

  if (!res.ok) {
    // No se registra ni se devuelve el cuerpo del error del proveedor.
    if (res.status === 429) throw new AppError(429, 'ai_rate_limited', 'El proveedor alcanzó un límite de solicitudes o de uso. Inténtalo más tarde.', { retryAfter: 30 });
    if (res.status === 401 || res.status === 403) throw unavailable('La configuración de acceso a la IA necesita revisión en el servidor.', 'ai_auth_error');
    if (res.status === 404) throw unavailable('El modelo configurado no está disponible para esta cuenta. Revisa OPENAI_MODEL en el servidor.', 'ai_model_unavailable');
    if (res.status === 400) throw badGateway('La IA rechazó la solicitud. Revisa OPENAI_MODEL y OPENAI_REASONING_EFFORT en el servidor.', 'ai_bad_request');
    throw badGateway('No pude conectar con la IA. Inténtalo de nuevo en un momento.', 'ai_error');
  }

  let datos;
  try { datos = await res.json(); } catch { throw badGateway('La IA respondió en un formato inesperado.', 'ai_invalid_response'); }
  const texto = extraerTexto(datos);
  if (!texto) {
    throw badGateway('La IA no devolvió texto esta vez. Puedes intentarlo de nuevo.', datos?.status === 'incomplete' ? 'ai_incomplete' : 'ai_empty');
  }
  return { reply: texto };
}
