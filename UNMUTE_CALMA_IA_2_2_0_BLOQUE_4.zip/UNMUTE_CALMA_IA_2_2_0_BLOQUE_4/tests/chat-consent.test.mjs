/* BLOQUE 1 · Problema 1: consentimiento del chat.
   Dos partes:
   · FRONTEND: se ejecuta el public/js/ai-chat.js REAL dentro de un DOM mínimo simulado (node:vm) para
     comprobar qué envía de verdad al pulsar «Enviar». No es un navegador real: no valida estilos ni foco visual.
   · BACKEND: peticiones reales al servidor local (mismas Netlify Functions) con OpenAI y Supabase SIMULADOS. */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { iniciarServidor } from '../server.js';
import { CLAVES, iniciarOpenAISimulado, iniciarSupabaseSimulado } from './helpers/mock-services.mjs';

let app, openai, supa, base;
const CODIGO_FRONT = readFileSync(new URL('../public/js/ai-chat.js', import.meta.url), 'utf8');
const MENSAJE = 'Hoy me siento cansado.';

/* ---------- DOM mínimo para ejecutar ai-chat.js ---------- */
class El {
  constructor() { this.listeners = {}; this.children = []; this.value = ''; this.checked = false; this.disabled = false; this.textContent = ''; this.className = ''; this.scrollTop = 0; this.scrollHeight = 0; this.enfocado = false; this.clases = new Set(); this.classList = { add: (c) => this.clases.add(c), remove: (c) => this.clases.delete(c) }; }
  addEventListener(t, f) { (this.listeners[t] ||= []).push(f); }
  appendChild(c) { this.children.push(c); return c; }
  replaceChildren() { this.children = []; }
  focus() { this.enfocado = true; }
  async disparar(tipo) { for (const f of this.listeners[tipo] || []) await f({ preventDefault() {} }); }
}

function montarFrontend({ fetchFn, diario } = {}) {
  const ids = { '#aiForm': new El(), '#aiConsent': new El(), '#aiInput': new El(), '#aiSend': new El(), '#aiMessages': new El(), '#aiStatus': new El(), '#aiCount': new El(), '#aiClear': new El() };
  const accesosAlmacenamiento = [];
  const traza = (nombre) => (...a) => { accesosAlmacenamiento.push([nombre, ...a]); return null; };
  const almacen = { getItem: traza('getItem'), setItem: traza('setItem'), removeItem: traza('removeItem'), key: traza('key'), length: 0 };
  const llamadas = [];
  const fetchSim = async (url, opts) => { llamadas.push({ url, opts, body: JSON.parse(opts.body) }); return fetchFn ? fetchFn(url, opts) : { ok: true, json: async () => ({ reply: 'Te leo.' }) }; };
  const document = {
    querySelector: (s) => ids[s] ?? null,
    querySelectorAll: () => [],
    createElement: () => new El()
  };
  vm.runInNewContext(CODIGO_FRONT, { document, fetch: fetchSim, localStorage: almacen, sessionStorage: almacen, indexedDB: undefined, console }, { filename: 'ai-chat.js' });
  const e = { form: ids['#aiForm'], consent: ids['#aiConsent'], input: ids['#aiInput'], send: ids['#aiSend'], log: ids['#aiMessages'], status: ids['#aiStatus'] };
  const escribir = async (texto) => { e.input.value = texto; await e.input.disparar('input'); };
  return { ...e, llamadas, accesosAlmacenamiento, diario, escribir, enviar: () => e.form.disparar('submit') };
}

before(async () => {
  openai = await iniciarOpenAISimulado();
  supa = await iniciarSupabaseSimulado();
  app = await iniciarServidor({ puerto: 0, silencioso: true });
  base = `http://127.0.0.1:${app.puerto}`;
});
after(async () => { await app.cerrar(); await openai.cerrar(); await supa.cerrar(); });
beforeEach(() => {
  Object.assign(process.env, { OPENAI_API_KEY: CLAVES.openai, OPENAI_BASE_URL: openai.url, OPENAI_MODEL: 'modelo-de-prueba', SUPABASE_URL: supa.url, SUPABASE_ANON_KEY: CLAVES.anon, SUPABASE_SERVICE_ROLE_KEY: CLAVES.servicio });
  for (const k of ['OPENAI_REASONING_EFFORT', 'CHAT_LIMIT_PER_MINUTE', 'RATE_LIMIT_DEV_MEMORY']) delete process.env[k];
  openai.estado.modo = 'ok'; openai.estado.llamadas.length = 0;
  supa.estado.limites.clear(); supa.estado.llamadas.length = 0; supa.estado.rpcLlamadas.length = 0;
});

const post = async (cuerpo) => {
  const res = await fetch(`${base}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: typeof cuerpo === 'string' ? cuerpo : JSON.stringify(cuerpo) });
  return { status: res.status, json: await res.json() };
};
// Reenvía al backend REAL (con OpenAI/Supabase simulados) lo que el frontend construyó.
const haciaBackend = async (url, opts) => { const r = await fetch(base + url, opts); return { ok: r.ok, status: r.status, json: () => r.json() }; };

/* ================= FRONTEND ================= */
test('frontend · 1. con consentimiento aceptado envía consent:true real y el flujo completo funciona', async () => {
  const f = montarFrontend({ fetchFn: haciaBackend });
  f.consent.checked = true; await f.consent.disparar('change');
  await f.escribir(MENSAJE);
  assert.equal(f.send.disabled, false);
  await f.enviar();
  assert.equal(f.llamadas.length, 1);
  assert.equal(f.llamadas[0].url, '/api/chat');
  assert.deepEqual(Object.keys(f.llamadas[0].body).sort(), ['consent', 'messages'], 'solo consent y messages');
  assert.equal(f.llamadas[0].body.consent, true);
  assert.deepEqual(f.llamadas[0].body.messages, [{ role: 'user', content: MENSAJE }]);
  // Backend (OpenAI simulado) respondió y la burbuja del asistente se mostró.
  assert.equal(openai.estado.llamadas.length, 1);
  assert.equal(f.log.children.length, 2);
  assert.match(f.log.children[1].children[0].textContent, /Gracias por contármelo/);
  assert.equal(f.status.textContent, '');
  assert.ok(!f.status.clases.has('error'));
});

test('frontend · 2. sin consentimiento no envía nada, explica por qué y conserva lo escrito', async () => {
  const f = montarFrontend({ fetchFn: haciaBackend });
  await f.escribir(MENSAJE);
  assert.equal(f.send.disabled, true, 'el botón sigue desactivado');
  assert.match(f.status.textContent, /casilla de privacidad/, 'explica el motivo mientras escribe');
  await f.enviar(); // intento «forzado» (p. ej. Enter, o evento enviado por script)
  assert.equal(f.llamadas.length, 0, 'no hay petición de red');
  assert.equal(openai.estado.llamadas.length, 0);
  assert.match(f.status.textContent, /casilla de privacidad/);
  assert.match(f.status.textContent, /No se ha enviado nada/);
  assert.ok(f.status.clases.has('error'));
  assert.equal(f.consent.enfocado, true, 'lleva el foco a la casilla');
  assert.equal(f.input.value, MENSAJE, 'no se pierde el texto escrito');
  assert.equal(f.log.children.length, 0, 'no aparece una burbuja de mensaje «enviado»');
});

test('frontend · el consentimiento se lee al enviar: si se desmarca después, deja de enviar', async () => {
  const f = montarFrontend();
  f.consent.checked = true; await f.consent.disparar('change');
  await f.escribir(MENSAJE);
  f.consent.checked = false; await f.consent.disparar('change');
  assert.equal(f.send.disabled, true);
  await f.enviar();
  assert.equal(f.llamadas.length, 0);
  f.consent.checked = true; await f.consent.disparar('change');
  await f.enviar();
  assert.equal(f.llamadas.length, 1);
  assert.equal(f.llamadas[0].body.consent, true);
});

test('frontend · 6. el diario nunca se adjunta: no toca el almacenamiento y el cuerpo solo trae lo escrito en el chat', async () => {
  const f = montarFrontend();
  f.consent.checked = true; await f.consent.disparar('change');
  await f.escribir('Primer mensaje'); await f.enviar();
  await f.escribir('Segundo mensaje'); await f.enviar();
  assert.equal(f.llamadas.length, 2);
  assert.deepEqual(f.accesosAlmacenamiento, [], 'ai-chat.js no lee ni escribe localStorage/sessionStorage');
  const texto = f.llamadas[1].opts.body;
  assert.ok(!/unmute_v2|entradas|borrador|emocion|etiqueta/i.test(texto), 'sin claves ni campos del diario');
  assert.deepEqual(f.llamadas[1].body.messages.map((m) => m.content), ['Primer mensaje', 'Te leo.', 'Segundo mensaje']);
  // Revisión estática: el código (sin comentarios) no menciona almacenamiento ni claves del diario.
  const codigo = CODIGO_FRONT.split('\n').filter((l) => !l.trim().startsWith('//')).join('\n');
  assert.ok(!/localStorage|sessionStorage|indexedDB|unmute_v2|unmute_registros/.test(codigo));
  assert.ok(!/consent\s*:\s*true/.test(codigo), 'consent:true nunca está escrito a mano');
});

test('frontend · se conserva el límite de contexto (máx. 12 mensajes y 8500 caracteres) y no se guarda la conversación', async () => {
  const f = montarFrontend();
  f.consent.checked = true; await f.consent.disparar('change');
  for (let i = 1; i <= 15; i++) { await f.escribir(`mensaje ${i}`); await f.enviar(); }
  const ultimo = f.llamadas.at(-1).body;
  assert.ok(ultimo.messages.length <= 12);
  assert.equal(ultimo.messages.at(-1).content, 'mensaje 15');
  assert.deepEqual(f.accesosAlmacenamiento, []);
});

/* ================= BACKEND ================= */
const msgs = [{ role: 'user', content: MENSAJE }];

test('backend · 3 y 4. consentimiento falso, de otro tipo o ausente → 400 consent_required sin llamar a la IA ni consumir límites', async () => {
  const casos = [{ consent: false }, { consent: 'true' }, { consent: 1 }, { consent: null }, {}];
  for (const extra of casos) {
    const r = await post({ messages: msgs, ...extra });
    assert.equal(r.status, 400, JSON.stringify(extra));
    assert.equal(r.json.code, 'consent_required', JSON.stringify(extra));
  }
  assert.equal(openai.estado.llamadas.length, 0, 'OpenAI no recibió nada');
  assert.equal(supa.estado.rpcLlamadas.length, 0, 'ni siquiera se consumió cuota de límite');
});

test('backend · 1 y 5. consentimiento aceptado → respuesta correcta; la IA recibe solo los mensajes del chat con store:false', async () => {
  const r = await post({ consent: true, messages: msgs });
  assert.equal(r.status, 200);
  assert.match(r.json.reply, /Gracias por contármelo/);
  assert.equal(openai.estado.llamadas.length, 1);
  const c = openai.estado.llamadas[0].cuerpo;
  assert.equal(c.store, false);
  assert.deepEqual(c.input, msgs);
  assert.ok(typeof c.instructions === 'string' && c.instructions.includes('UNMUTE IA'), 'la personalidad no cambió');
});

test('backend · el consentimiento se exige antes que cualquier otra cosa sobre el contenido y no se completa por defecto', async () => {
  const r = await post({ messages: msgs });
  assert.equal(r.json.code, 'consent_required');
  const r2 = await post('{"consent":true,"messages":[]}');
  assert.equal(r2.json.code, 'invalid_chat', 'con consentimiento pero mensajes inválidos sigue siendo un 400 distinto');
});
