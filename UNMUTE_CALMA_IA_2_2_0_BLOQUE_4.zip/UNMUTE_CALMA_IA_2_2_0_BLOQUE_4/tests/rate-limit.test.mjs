/* BLOQUE 1 · Problema 2: límites de uso seguros para producción.
   Se usan OpenAI y Supabase SIMULADOS (tests/helpers/mock-services.mjs). Importante:
   · El simulador imita la lógica de consume_rate_limit, pero NO es PostgreSQL: estas pruebas validan
     cómo USA el backend la función (fallos, cierre seguro, contadores compartidos), no el SQL real.
   · La atomicidad real frente a concurrencia depende de INSERT … ON CONFLICT en PostgreSQL y solo
     puede comprobarse contra una instancia real de Supabase/PostgreSQL. */
import { test, before, after, beforeEach, mock } from 'node:test';
import assert from 'node:assert/strict';
import { iniciarServidor } from '../server.js';
import { CLAVES, iniciarOpenAISimulado, iniciarSupabaseSimulado } from './helpers/mock-services.mjs';
import { _vaciarMemoria, consumir, modoLimite } from '../src/lib/rate-limit.mjs';
import { isNetlifyRuntime } from '../src/config/environment.mjs';

let app, openai, supa, base, registro;
const msgOk = [{ role: 'user', content: 'Hoy me siento cansado.' }];
const SENALES_NETLIFY = ['NETLIFY', 'NETLIFY_DEV', 'CONTEXT', 'AWS_LAMBDA_FUNCTION_NAME', 'LAMBDA_TASK_ROOT', 'AWS_EXECUTION_ENV'];
const VARIABLES = ['OPENAI_REASONING_EFFORT', 'CHAT_LIMIT_PER_MINUTE', 'CHAT_LIMIT_PER_DAY', 'CHAT_GLOBAL_LIMIT_PER_DAY', 'CONTACT_LIMIT_PER_HOUR', 'LOGIN_LIMIT_PER_15_MIN', 'RATE_LIMIT_DEV_MEMORY', ...SENALES_NETLIFY];

const pedir = async (ruta, { metodo = 'POST', cuerpo } = {}) => {
  const res = await fetch(base + ruta, { method: metodo, headers: cuerpo !== undefined ? { 'Content-Type': 'application/json' } : {}, body: cuerpo !== undefined ? JSON.stringify(cuerpo) : undefined });
  const texto = await res.text();
  let json = null; try { json = JSON.parse(texto); } catch { /* no JSON */ }
  return { status: res.status, json, texto, headers: res.headers };
};
const chat = () => pedir('/api/chat', { cuerpo: { messages: msgOk, consent: true } });
const contacto = () => pedir('/api/contact', { cuerpo: { name: 'Ana', category: 'consulta', message: 'Este es un mensaje de prueba.', privacy_accepted: true, elapsed_ms: 20000 } });

before(async () => {
  openai = await iniciarOpenAISimulado();
  supa = await iniciarSupabaseSimulado();
  supa.crearUsuario('admin@unmute.test', 'clave-admin-123', 'admin');
  app = await iniciarServidor({ puerto: 0, silencioso: true });
  base = `http://127.0.0.1:${app.puerto}`;
});
after(async () => { await app.cerrar(); await openai.cerrar(); await supa.cerrar(); });
beforeEach(() => {
  Object.assign(process.env, { OPENAI_API_KEY: CLAVES.openai, OPENAI_BASE_URL: openai.url, OPENAI_MODEL: 'modelo-de-prueba', SUPABASE_URL: supa.url, SUPABASE_ANON_KEY: CLAVES.anon, SUPABASE_SERVICE_ROLE_KEY: CLAVES.servicio });
  for (const k of VARIABLES) delete process.env[k];
  delete globalThis.Netlify;
  openai.estado.modo = 'ok'; openai.estado.llamadas.length = 0;
  supa.estado.limites.clear(); supa.estado.llamadas.length = 0; supa.estado.rpcLlamadas.length = 0; supa.estado.mensajes.length = 0; supa.estado.rpcModo = 'ok'; supa.estado.tokens.clear();
  _vaciarMemoria();
  // Se capturan los registros técnicos para comprobar que no filtran secretos.
  registro = [];
  mock.method(console, 'error', (...a) => registro.push(a.join(' ')));
  mock.method(console, 'warn', (...a) => registro.push(a.join(' ')));
});
const sinFugas = (r) => {
  for (const texto of [r.texto, ...registro]) {
    for (const secreto of [CLAVES.servicio, CLAVES.anon, CLAVES.openai, supa.url, 'PGRST202', 'XX000', '127.0.0.1']) assert.ok(!texto.includes(secreto), `no debe filtrarse «${secreto}»`);
  }
};
const exigir503 = (r) => { assert.equal(r.status, 503); assert.equal(r.json.code, 'rate_limit_unavailable'); sinFugas(r); };

/* 1. Supabase disponible y RPC funcionando */
test('1 · Supabase y RPC disponibles: el chat funciona y usa los límites actuales sin memoria', async () => {
  const r = await chat();
  assert.equal(r.status, 200);
  assert.equal(modoLimite(), 'database');
  // Límites y periodos conservados: 8/min, 80/día por persona y 3000/día globales.
  const [min, dia, glob] = supa.estado.rpcLlamadas;
  assert.deepEqual([min.limite, min.ventana, min.bucket.startsWith('chat-min:')], [8, 60, true]);
  assert.deepEqual([dia.limite, dia.ventana, dia.bucket.startsWith('chat-dia:')], [80, 86400, true]);
  assert.deepEqual([glob.limite, glob.ventana, glob.bucket], [3000, 86400, 'chat-dia:global']);
  assert.ok(supa.estado.rpcLlamadas.every((c) => !c.bucket.includes('127.0.0.1')), 'se guarda un hash, no la IP');
});

/* 2. Límite alcanzado */
test('2 · límite alcanzado: 429 con Retry-After y sin llamar más a la IA (minuto, día y global)', async () => {
  process.env.CHAT_LIMIT_PER_MINUTE = '2';
  assert.equal((await chat()).status, 200); assert.equal((await chat()).status, 200);
  const r = await chat();
  assert.equal(r.status, 429); assert.equal(r.json.code, 'rate_limited'); assert.ok(Number(r.headers.get('retry-after')) >= 1);
  assert.equal(openai.estado.llamadas.length, 2);

  delete process.env.CHAT_LIMIT_PER_MINUTE; supa.estado.limites.clear(); openai.estado.llamadas.length = 0;
  process.env.CHAT_LIMIT_PER_DAY = '1';
  assert.equal((await chat()).status, 200); assert.equal((await chat()).status, 429);

  delete process.env.CHAT_LIMIT_PER_DAY; supa.estado.limites.clear();
  process.env.CHAT_GLOBAL_LIMIT_PER_DAY = '1';
  assert.equal((await chat()).status, 200);
  const g = await chat();
  assert.equal(g.status, 429); assert.match(g.json.error, /límite de uso de hoy/);
});

/* 3. Supabase sin credenciales */
test('3 · sin credenciales de Supabase: 503 controlado, sin llamar a la IA y sin memoria', async () => {
  for (const faltante of [['SUPABASE_URL'], ['SUPABASE_SERVICE_ROLE_KEY'], ['SUPABASE_ANON_KEY'], ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'SUPABASE_SERVICE_ROLE_KEY']]) {
    Object.assign(process.env, { SUPABASE_URL: supa.url, SUPABASE_ANON_KEY: CLAVES.anon, SUPABASE_SERVICE_ROLE_KEY: CLAVES.servicio });
    for (const k of faltante) delete process.env[k];
    for (let i = 0; i < 12; i++) exigir503(await chat()); // más que cualquier límite: nunca pasa a memoria
  }
  assert.equal(openai.estado.llamadas.length, 0);
  assert.equal(modoLimite(), 'unavailable');
});

/* 4. Supabase inaccesible */
test('4 · Supabase inaccesible: 503 controlado y la solicitud no llega a OpenAI', async () => {
  process.env.SUPABASE_URL = 'http://127.0.0.1:1';
  exigir503(await chat());
  assert.equal(openai.estado.llamadas.length, 0);
});

/* 5. RPC inexistente o con error */
test('5 · RPC inexistente, con error o con respuesta inesperada: 503 y sin llamar a la IA', async () => {
  for (const modo of ['ausente', 'error', 'malformada']) {
    supa.estado.rpcModo = modo;
    exigir503(await chat());
  }
  assert.equal(openai.estado.llamadas.length, 0);
  assert.ok(supa.estado.rpcLlamadas.length >= 3, 'sí se intentó consultar el RPC');
});

test('5b · una respuesta del RPC sin «allowed» booleano nunca cuenta como permitida (nivel de unidad)', async () => {
  for (const modo of ['malformada']) {
    supa.estado.rpcModo = modo;
    await assert.rejects(() => consumir('x:1', 5, 60), (e) => e.status === 503 && e.code === 'rate_limit_unavailable');
  }
  supa.estado.rpcModo = 'ok';
  for (const [limite, ventana] of [[0, 60], [-1, 60], [5, 0], [NaN, 60], [5, 1.5]]) {
    await assert.rejects(() => consumir('x:1', limite, ventana), (e) => e.status === 503, `parámetros ${limite}/${ventana}`);
  }
});

/* 6. Nunca memoria en Netlify */
test('6 · en Netlify (producción, deploy previews, branch deploys, runtime) no se usa memoria ni con la opción de desarrollo activada', async () => {
  const entornos = {
    'objeto global Netlify (runtime de Functions)': () => { globalThis.Netlify = { env: { get: () => undefined } }; },
    'CONTEXT=production': () => { process.env.CONTEXT = 'production'; },
    'CONTEXT=deploy-preview': () => { process.env.CONTEXT = 'deploy-preview'; },
    'CONTEXT=branch-deploy': () => { process.env.CONTEXT = 'branch-deploy'; },
    'NETLIFY=true': () => { process.env.NETLIFY = 'true'; },
    'netlify dev (NETLIFY_DEV)': () => { process.env.NETLIFY_DEV = 'true'; },
    'AWS Lambda (AWS_LAMBDA_FUNCTION_NAME)': () => { process.env.AWS_LAMBDA_FUNCTION_NAME = 'fn'; }
  };
  for (const [nombre, activar] of Object.entries(entornos)) {
    for (const k of SENALES_NETLIFY) delete process.env[k]; delete globalThis.Netlify;
    activar();
    process.env.RATE_LIMIT_DEV_MEMORY = 'true'; // aunque alguien la deje puesta por error
    assert.equal(isNetlifyRuntime(), true, nombre);
    // a) sin Supabase
    delete process.env.SUPABASE_URL;
    for (let i = 0; i < 10; i++) exigir503(await chat());
    // b) con Supabase configurado pero con el RPC caído
    process.env.SUPABASE_URL = supa.url; supa.estado.rpcModo = 'error';
    exigir503(await chat());
    supa.estado.rpcModo = 'ok';
    // c) con Supabase sano usa SOLO la base compartida (no la memoria)
    const antes = supa.estado.rpcLlamadas.length;
    assert.equal((await chat()).status, 200, nombre);
    assert.ok(supa.estado.rpcLlamadas.length > antes, `${nombre}: el contador está en Supabase`);
    assert.equal(modoLimite(), 'database', nombre);
    supa.estado.limites.clear(); _vaciarMemoria();
  }
  assert.ok(registro.some((l) => l.includes('RATE_LIMIT_DEV_MEMORY se ignora en Netlify')), 'se avisa de que la opción se ignora');
});

/* 7. Los endpoints protegidos no continúan */
test('7 · si falla el control de uso, chat, contacto e inicio de sesión no continúan', async () => {
  supa.estado.rpcModo = 'error';
  exigir503(await chat());
  assert.equal(openai.estado.llamadas.length, 0, 'chat: no llegó a OpenAI');
  exigir503(await contacto());
  assert.equal(supa.estado.mensajes.length, 0, 'contacto: no se guardó nada');
  exigir503(await pedir('/api/admin/login', { cuerpo: { email: 'admin@unmute.test', password: 'clave-admin-123' } }));
  assert.ok(!supa.estado.llamadas.some((l) => l.ruta === '/auth/v1/token'), 'login: no se intentó autenticar sin poder limitar intentos');
  // Y cuando el RPC se recupera, vuelven a funcionar.
  supa.estado.rpcModo = 'ok';
  assert.equal((await chat()).status, 200);
  assert.equal((await contacto()).status, 201);
  assert.equal((await pedir('/api/admin/login', { cuerpo: { email: 'admin@unmute.test', password: 'clave-admin-123' } })).status, 200);
});

/* 8. Modo local explícito */
test('8 · modo local explícito (RATE_LIMIT_DEV_MEMORY=true, fuera de Netlify) sigue funcionando y avisa de que no es para producción', async () => {
  delete process.env.SUPABASE_URL;
  process.env.CHAT_LIMIT_PER_MINUTE = '1';
  // Sin activar la opción: no hay memoria silenciosa.
  exigir503(await chat());
  // Con valores que NO son exactamente «true», tampoco.
  for (const v of ['yes', '1', 'verdadero', 'false']) { process.env.RATE_LIMIT_DEV_MEMORY = v; exigir503(await chat()); }
  // Explícito:
  process.env.RATE_LIMIT_DEV_MEMORY = 'true';
  assert.equal(modoLimite(), 'memory');
  assert.equal((await chat()).status, 200);
  const r = await chat();
  assert.equal(r.status, 429);
  assert.equal(supa.estado.rpcLlamadas.length, 0, 'no se usó Supabase en modo local explícito');
  assert.ok(registro.some((l) => /NO aptos para producción/.test(l)), 'advertencia en el registro');
  // El health lo declara.
  const h = await pedir('/api/health', { metodo: 'GET' });
  assert.equal(h.json.services.rateLimit.mode, 'memory');
});

/* 9. Estado persistente compartido */
test('9 · varias solicitudes (simultáneas y desde «instancias» distintas) comparten el mismo contador persistente', async () => {
  process.env.CHAT_LIMIT_PER_MINUTE = '5';
  const respuestas = await Promise.all(Array.from({ length: 12 }, () => chat()));
  const estados = respuestas.map((r) => r.status);
  assert.equal(estados.filter((s) => s === 200).length, 5);
  assert.equal(estados.filter((s) => s === 429).length, 7);
  assert.equal(openai.estado.llamadas.length, 5);
  const cubetaMin = [...supa.estado.limites.keys()].find((k) => k.startsWith('chat-min:'));
  assert.equal(supa.estado.limites.get(cubetaMin).hits, 12, 'las 12 solicitudes sumaron en la misma fila');
  // Otra instancia serverless = otra memoria de proceso: el estado sigue en la base.
  _vaciarMemoria();
  assert.equal((await chat()).status, 429);
});

test('health: distingue database / unavailable y se marca degradado si no hay forma de limitar', async () => {
  const ok = await pedir('/api/health', { metodo: 'GET' });
  assert.equal(ok.json.services.rateLimit.mode, 'database'); assert.equal(ok.json.status, 'ok');
  delete process.env.SUPABASE_SERVICE_ROLE_KEY;
  const d = await pedir('/api/health', { metodo: 'GET' });
  assert.equal(d.json.services.rateLimit.mode, 'unavailable'); assert.equal(d.json.status, 'degraded');
  sinFugas(d);
});
