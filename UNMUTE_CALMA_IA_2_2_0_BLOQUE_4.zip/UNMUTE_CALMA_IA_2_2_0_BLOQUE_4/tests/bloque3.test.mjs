/* Bloque 3 · Datos curiosos y noticias.
   Usan el servidor local (mismas Netlify Functions) con Supabase y OpenAI SIMULADOS.
   Demuestran cómo se comporta el backend; NO demuestran que las políticas RLS, el trigger SQL de la migración 003
   ni Netlify reales funcionen (eso solo se prueba contra un Supabase real). */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { iniciarServidor } from '../server.js';
import { CLAVES, iniciarOpenAISimulado, iniciarSupabaseSimulado } from './helpers/mock-services.mjs';
import { _vaciarMemoria } from '../src/lib/rate-limit.mjs';

let app, openai, supa, base;
const ADMIN = { email: 'admin@unmute.test', password: 'clave-admin-123' };
const USUARIO = { email: 'persona@unmute.test', password: 'clave-persona-123' };

const pedir = async (ruta, { metodo = 'GET', cuerpo, token, cabeceras = {} } = {}) => {
  const res = await fetch(base + ruta, {
    method: metodo,
    headers: { ...(cuerpo !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}), ...cabeceras },
    body: cuerpo !== undefined ? JSON.stringify(cuerpo) : undefined
  });
  const texto = await res.text();
  let json = null; try { json = JSON.parse(texto); } catch { /* no JSON */ }
  return { status: res.status, json, texto, headers: res.headers };
};
const entrar = async (cred) => (await pedir('/api/admin/login', { metodo: 'POST', cuerpo: cred })).json.accessToken;
const dato = (extra = {}) => ({ title: 'El bostezo enfría el cerebro', description: 'Una hipótesis sugiere que bostezar ayuda a regular la temperatura cerebral.', category: 'Cerebro y comportamiento', resource_type: 'fact', ...extra });
const noticia = (extra = {}) => ({ title: 'Nueva sección de noticias', description: 'Ahora puedes leer novedades de UNMUTE.', content: 'Primer párrafo.\n\nSegundo párrafo.', category: 'Novedades de UNMUTE', ...extra });

before(async () => {
  openai = await iniciarOpenAISimulado();
  supa = await iniciarSupabaseSimulado();
  Object.assign(process.env, { OPENAI_API_KEY: CLAVES.openai, OPENAI_BASE_URL: openai.url, OPENAI_MODEL: 'modelo-de-prueba', SUPABASE_URL: supa.url, SUPABASE_ANON_KEY: CLAVES.anon, SUPABASE_SERVICE_ROLE_KEY: CLAVES.servicio });
  for (const k of ['LOGIN_LIMIT_PER_15_MIN', 'RATE_LIMIT_DEV_MEMORY']) delete process.env[k];
  supa.crearUsuario(ADMIN.email, ADMIN.password, 'admin');
  supa.crearUsuario(USUARIO.email, USUARIO.password, 'user');
  app = await iniciarServidor({ puerto: 0, silencioso: true });
  base = `http://127.0.0.1:${app.puerto}`;
});
after(async () => { await app.cerrar(); await openai.cerrar(); await supa.cerrar(); });
beforeEach(() => {
  for (const k of ['LOGIN_LIMIT_PER_15_MIN', 'RATE_LIMIT_DEV_MEMORY']) delete process.env[k];
  supa.estado.limites.clear(); supa.estado.tokens.clear(); supa.estado.recursos.length = 0; supa.estado.noticias.length = 0; supa.estado.mensajes.length = 0;
  _vaciarMemoria();
});

/* ---------- Prueba 1 · Datos curiosos ---------- */
test('P1 datos curiosos: crear, editar, publicar y leer por el endpoint público; sin fuente no se publica', async () => {
  const t = await entrar(ADMIN);
  // Crear como borrador (sin fuente ni revisión: permitido)
  const c = await pedir('/api/admin/resources', { metodo: 'POST', token: t, cuerpo: dato() });
  assert.equal(c.status, 201);
  const id = c.json.resource.id;
  assert.equal(c.json.resource.status, 'draft');
  // Un borrador no es público ni sale como dato del día
  assert.equal((await pedir('/api/resources?type=fact')).json.resources.length, 0);
  assert.equal((await pedir('/api/facts/today?date=2026-11-17')).status, 404);

  // Publicar SIN fuente ni fecha: rechazado por el servidor (por /publish y por PATCH)
  const sinFuente = await pedir(`/api/admin/resources/${id}/publish`, { metodo: 'POST', token: t });
  assert.equal(sinFuente.status, 400);
  assert.ok(sinFuente.json.fields.source_url && sinFuente.json.fields.reviewed_at);
  assert.equal((await pedir(`/api/admin/resources/${id}`, { metodo: 'PATCH', token: t, cuerpo: { status: 'published' } })).status, 400);
  assert.equal((await pedir('/api/admin/resources', { metodo: 'POST', token: t, cuerpo: dato({ slug: 'otro', status: 'published' }) })).status, 400);
  // Solo fuente (sin fecha) tampoco basta
  assert.equal((await pedir(`/api/admin/resources/${id}`, { metodo: 'PATCH', token: t, cuerpo: { source_url: 'https://www.ejemplo.org/estudio', status: 'published' } })).status, 400);

  // Editar: completar fuente y fecha, y publicar
  const e = await pedir(`/api/admin/resources/${id}`, { metodo: 'PATCH', token: t, cuerpo: { description: 'Descripción editada.', source_url: 'https://www.ejemplo.org/estudio', reviewed_at: '2026-11-17' } });
  assert.equal(e.status, 200);
  assert.equal(e.json.resource.description, 'Descripción editada.');
  assert.equal((await pedir(`/api/admin/resources/${id}/publish`, { metodo: 'POST', token: t })).status, 200);

  // Lectura pública: lista, detalle y dato del día (estable)
  const lista = await pedir('/api/resources?type=fact');
  assert.equal(lista.json.resources.length, 1);
  const hoy1 = await pedir('/api/facts/today?date=2026-11-17');
  const hoy2 = await pedir('/api/facts/today?date=2026-11-17');
  assert.equal(hoy1.status, 200);
  assert.deepEqual(hoy1.json, hoy2.json);
  for (const k of ['title', 'description', 'category', 'source_url']) assert.ok(hoy1.json.fact[k], k);
  assert.equal(hoy1.json.fact.description, 'Descripción editada.');

  // Despublicar: deja de ser público; eliminar: desaparece del panel
  assert.equal((await pedir(`/api/admin/resources/${id}/unpublish`, { metodo: 'POST', token: t })).status, 200);
  assert.equal((await pedir('/api/facts/today?date=2026-11-17')).status, 404);
  assert.equal((await pedir(`/api/admin/resources/${id}`, { metodo: 'DELETE', token: t })).status, 200);
  assert.equal((await pedir('/api/admin/resources?type=fact', { token: t })).json.resources.length, 0);
});

test('P1 dato del día: cambia según la fecha, no al recargar', async () => {
  const t = await entrar(ADMIN);
  for (const n of [1, 2, 3]) {
    supa.nuevoRecurso({ slug: `dato-${n}`, title: `Dato ${n}`, description: 'd', category: 'c', resource_type: 'fact', status: 'published', source_url: 'https://x.org/a', reviewed_at: '2026-11-16' });
  }
  const a = (await pedir('/api/facts/today?date=2026-11-17')).json.fact.slug;
  assert.equal((await pedir('/api/facts/today?date=2026-11-17')).json.fact.slug, a);
  const siguiente = (await pedir('/api/facts/today?date=2026-11-18')).json.fact.slug;
  assert.notEqual(siguiente, a);
  assert.ok(t);
});

/* ---------- Prueba 2 · Noticias: ciclo completo ---------- */
test('P2 noticias: crear, guardar borrador, publicar, editar y eliminar', async () => {
  const t = await entrar(ADMIN);
  const c = await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia() });
  assert.equal(c.status, 201);
  const n = c.json.news;
  assert.equal(n.status, 'draft');
  assert.equal(n.published_at, null);
  assert.equal(n.slug, 'nueva-seccion-de-noticias');

  // Borrador: no público (ni lista ni detalle)
  assert.equal((await pedir('/api/news')).json.news.length, 0);
  assert.equal((await pedir(`/api/news/${n.slug}`)).status, 404);

  // Publicar: la fecha la fija el servidor
  const p = await pedir(`/api/admin/news/${n.id}/publish`, { metodo: 'POST', token: t });
  assert.equal(p.status, 200);
  assert.equal(p.json.news.status, 'published');
  assert.ok(p.json.news.published_at);
  const fecha = p.json.news.published_at;
  const lista = await pedir('/api/news');
  assert.equal(lista.json.news.length, 1);
  assert.equal(lista.json.news[0].content, undefined, 'la lista no trae el contenido completo');
  const detalle = await pedir(`/api/news/${n.slug}`);
  assert.equal(detalle.json.news.content, 'Primer párrafo.\n\nSegundo párrafo.');

  // Editar una noticia publicada: se refleja y conserva la fecha de publicación
  const e = await pedir(`/api/admin/news/${n.id}`, { metodo: 'PATCH', token: t, cuerpo: { title: 'Título corregido', image_url: 'https://imagenes.ejemplo.org/a.jpg' } });
  assert.equal(e.status, 200);
  assert.equal(e.json.news.published_at, fecha);
  assert.equal((await pedir(`/api/news/${n.slug}`)).json.news.title, 'Título corregido');
  assert.equal((await pedir(`/api/news/${n.slug}`)).json.news.image_url, 'https://imagenes.ejemplo.org/a.jpg');

  // Despublicar y volver a publicar
  assert.equal((await pedir(`/api/admin/news/${n.id}/unpublish`, { metodo: 'POST', token: t })).json.news.published_at, null);
  assert.equal((await pedir('/api/news')).json.news.length, 0);
  await pedir(`/api/admin/news/${n.id}/publish`, { metodo: 'POST', token: t });

  // Eliminar
  assert.equal((await pedir(`/api/admin/news/${n.id}`, { metodo: 'DELETE', token: t })).status, 200);
  assert.equal((await pedir(`/api/news/${n.slug}`)).status, 404);
  assert.equal((await pedir('/api/admin/news', { token: t })).json.news.length, 0);
});

test('P2 noticias: orden por fecha descendente, fecha del cliente ignorada y validaciones', async () => {
  const t = await entrar(ADMIN);
  const a = (await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia({ title: 'Primera noticia' }) })).json.news;
  const b = (await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia({ title: 'Segunda noticia' }) })).json.news;
  await pedir(`/api/admin/news/${a.id}/publish`, { metodo: 'POST', token: t });
  await new Promise((r) => setTimeout(r, 15));
  await pedir(`/api/admin/news/${b.id}/publish`, { metodo: 'POST', token: t });
  assert.deepEqual((await pedir('/api/news')).json.news.map((x) => x.title), ['Segunda noticia', 'Primera noticia']);

  // El cliente no puede elegir la fecha de publicación
  const f = await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia({ title: 'Con fecha falsa', published_at: '2001-01-01T00:00:00Z', status: 'published' }) });
  assert.equal(f.status, 201);
  assert.notEqual(f.json.news.published_at, '2001-01-01T00:00:00Z');
  assert.ok(new Date(f.json.news.published_at).getFullYear() >= 2025);

  // Validaciones del servidor
  const malos = [
    [{ category: 'Inventada' }, 'category'],
    [{ title: 'ab' }, 'title'],
    [{ description: '' }, 'description'],
    [{ content: '<script>alert(1)</script>' }, 'content'],
    [{ title: 'Título <b>con</b> HTML' }, 'title'],
    [{ image_url: 'http://inseguro.org/a.jpg' }, 'image_url'],
    [{ image_url: 'javascript:alert(1)' }, 'image_url'],
    [{ slug: 'Mal Slug' }, 'slug']
  ];
  for (const [extra, campo] of malos) {
    const r = await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia({ title: 'Válida', ...extra }) });
    assert.equal(r.status, 400, JSON.stringify(extra));
    assert.ok(r.json.fields[campo], `debe señalar «${campo}» en ${JSON.stringify(extra)}`);
  }
  // Publicar sin contenido: rechazado
  const vacio = (await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia({ title: 'Sin contenido', content: '' }) })).json.news;
  assert.equal((await pedir(`/api/admin/news/${vacio.id}/publish`, { metodo: 'POST', token: t })).status, 400);
  // Identificador repetido
  assert.equal((await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia({ title: 'Primera noticia' }) })).status, 409);
});

/* ---------- Prueba 3 · Seguridad ---------- */
test('P3 seguridad: los visitantes y las cuentas sin rol admin no pueden modificar noticias ni datos', async () => {
  const t = await entrar(ADMIN);
  const n = (await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia() })).json.news;
  const persona = await entrar(USUARIO).catch(() => null);
  assert.equal(persona, undefined, 'una cuenta sin rol admin ni siquiera obtiene sesión en el panel');
  // Token de una cuenta autenticada pero NO admin (obtenida directamente de Auth simulado)
  const crudo = await fetch(`${supa.url}/auth/v1/token?grant_type=password`, { method: 'POST', headers: { apikey: CLAVES.anon, 'Content-Type': 'application/json' }, body: JSON.stringify(USUARIO) });
  const tokenPersona = (await crudo.json()).access_token;
  assert.ok(tokenPersona);

  const intentos = [
    ['GET', '/api/admin/news'], ['POST', '/api/admin/news', noticia({ title: 'Intruso' })],
    ['PATCH', `/api/admin/news/${n.id}`, { title: 'Hackeada' }], ['DELETE', `/api/admin/news/${n.id}`],
    ['POST', `/api/admin/news/${n.id}/publish`], ['POST', `/api/admin/resources`, dato()]
  ];
  for (const [metodo, ruta, cuerpo] of intentos) {
    const sinToken = await pedir(ruta, { metodo, cuerpo });
    assert.equal(sinToken.status, 401, `visitante ${metodo} ${ruta}`);
    const noAdmin = await pedir(ruta, { metodo, cuerpo, token: tokenPersona });
    assert.equal(noAdmin.status, 403, `no admin ${metodo} ${ruta}`);
    const falso = await pedir(ruta, { metodo, cuerpo, token: 'token-inventado' });
    assert.equal(falso.status, 401, `token falso ${metodo} ${ruta}`);
  }
  // Nada cambió
  assert.equal(supa.estado.noticias.length, 1);
  assert.equal(supa.estado.noticias[0].title, 'Nueva sección de noticias');
  // Métodos de escritura en los endpoints públicos: no existen
  for (const metodo of ['POST', 'PATCH', 'DELETE']) assert.equal((await pedir('/api/news', { metodo, cuerpo: noticia() })).status, 405);
});

test('P3 seguridad: los endpoints públicos nunca devuelven borradores ni campos internos', async () => {
  const t = await entrar(ADMIN);
  const borrador = (await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia({ title: 'Borrador secreto' }) })).json.news;
  const pub = (await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia({ title: 'Noticia pública', status: 'published' }) })).json.news;
  supa.nuevoRecurso({ slug: 'dato-borrador', title: 'Dato borrador', description: 'd', category: 'c', resource_type: 'fact', status: 'draft' });
  for (const ruta of ['/api/news', `/api/news/${pub.slug}`, '/api/resources', '/api/facts/today?date=2026-11-17']) {
    const r = await pedir(ruta);
    assert.ok(!/Borrador secreto|Dato borrador/.test(r.texto), `${ruta} no debe mostrar borradores`);
  }
  assert.equal((await pedir(`/api/news/${borrador.slug}`)).status, 404);
  assert.equal((await pedir('/api/news/slug%20inv%C3%A1lido!')).status, 404);
  const lista = (await pedir('/api/news')).json.news;
  assert.deepEqual(lista.map((x) => x.title), ['Noticia pública']);
  for (const campo of ['status', 'created_by', 'created_at', 'updated_at']) assert.equal(lista[0][campo], undefined, `no se expone «${campo}»`);
  // El backend público consulta Supabase solo con la clave anónima (nunca la de servicio)
  const llamadasNews = supa.estado.llamadas.filter((l) => l.ruta === '/rest/v1/news' && l.rol !== 'authenticated');
  assert.ok(llamadasNews.length > 0 && llamadasNews.every((l) => l.rol === 'anon'));
});

/* ---------- Prueba 4 · Multidispositivo ---------- */
test('P4 multidispositivo: lo publicado por el backend lo ve un segundo cliente independiente (Supabase SIMULADO)', async () => {
  const t = await entrar(ADMIN);
  const n = (await pedir('/api/admin/news', { metodo: 'POST', token: t, cuerpo: noticia({ title: 'Desde el panel' }) })).json.news;
  const movil = { 'User-Agent': 'Dispositivo-Movil-B', 'X-Forwarded-For': '203.0.113.9' };
  const portatil = { 'User-Agent': 'Dispositivo-Portatil-C', 'X-Forwarded-For': '198.51.100.4' };
  assert.equal((await pedir('/api/news', { cabeceras: movil })).json.news.length, 0);
  await pedir(`/api/admin/news/${n.id}/publish`, { metodo: 'POST', token: t });
  for (const cliente of [movil, portatil]) {
    const r = await pedir('/api/news', { cabeceras: cliente });
    assert.deepEqual(r.json.news.map((x) => x.title), ['Desde el panel']);
    assert.match(r.headers.get('cache-control'), /max-age=0/);
    assert.match(r.headers.get('cache-control'), /must-revalidate/);
  }
  await pedir(`/api/admin/news/${n.id}`, { metodo: 'PATCH', token: t, cuerpo: { title: 'Editada' } });
  assert.equal((await pedir('/api/news', { cabeceras: movil })).json.news[0].title, 'Editada');
  await pedir(`/api/admin/news/${n.id}/unpublish`, { metodo: 'POST', token: t });
  assert.equal((await pedir('/api/news', { cabeceras: portatil })).json.news.length, 0);
});

/* ---------- Interfaz: comprobaciones estáticas ---------- */
const leer = (rel) => readFile(new URL(`../${rel}`, import.meta.url), 'utf8');

test('interfaz: pestaña «Noticias del admin», sección pública y tarjeta conectada, sin HTML inseguro', async () => {
  const admin = await leer('public/admin.html');
  assert.match(admin, /data-sec="noticias">Noticias del admin<\/button>/);
  assert.match(admin, /data-sec="datos">Datos curiosos<\/button>/);
  for (const id of ['ntLista', 'ntForm', 'ntBuscar', 'ntFiltro', 'ntStats', 'ntMsg', 'dcLista', 'dcForm', 'dcFuente', 'dcRevision', 'dlgConf']) assert.match(admin, new RegExp(`id="${id}"`), id);
  const index = await leer('public/index.html');
  assert.match(index, /data-v="noticias">Noticias<\/a>/);
  assert.match(index, /id="v-noticias"/);
  assert.match(index, /Un minuto para aprender/);
  assert.match(index, /<script src="js\/content\.js">/);
  const js = (await leer('public/js/content.js')) + (await leer('public/js/admin.js'));
  assert.ok(!/innerHTML|outerHTML|insertAdjacentHTML|document\.write|eval\(/.test(js.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '')));
  assert.match(await leer('public/js/content.js'), /\/api\/facts\/today\?date=/);
  assert.match(await leer('public/js/content.js'), /\/api\/news/);
  const toml = await leer('netlify.toml');
  assert.match(toml, /img-src 'self' data: https:;/);
  assert.match(toml, /script-src 'self'/);
});

test('el diario no se toca: ningún archivo nuevo usa localStorage ni envía entradas', async () => {
  for (const f of ['public/js/content.js', 'src/services/news.service.mjs', 'netlify/functions/news.mjs', 'netlify/functions/admin-news.mjs']) {
    const src = await leer(f);
    assert.ok(!/localStorage|sessionStorage|unmute_v2_/.test(src), f);
  }
});
