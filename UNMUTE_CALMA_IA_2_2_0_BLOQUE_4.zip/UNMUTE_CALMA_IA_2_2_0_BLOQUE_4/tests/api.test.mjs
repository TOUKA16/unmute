/* Pruebas del backend: arrancan el servidor local (que ejecuta las mismas Netlify Functions)
   contra OpenAI y Supabase simulados. Ver tests/helpers/mock-services.mjs para sus límites. */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { iniciarServidor } from '../server.js';
import { CLAVES, iniciarOpenAISimulado, iniciarSupabaseSimulado } from './helpers/mock-services.mjs';
import { _vaciarMemoria } from '../src/lib/rate-limit.mjs';

let app, openai, supa, base;
const entorno = {};
const ADMIN = { email: 'admin@unmute.test', password: 'clave-admin-123' };
const USUARIO = { email: 'persona@unmute.test', password: 'clave-persona-123' };

const pedir = async (ruta, { metodo = 'GET', cuerpo, token, cabeceras = {}, crudo } = {}) => {
  const res = await fetch(base + ruta, {
    method: metodo,
    headers: { ...(cuerpo !== undefined || crudo !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}), ...cabeceras },
    body: crudo ?? (cuerpo !== undefined ? JSON.stringify(cuerpo) : undefined)
  });
  const texto = await res.text();
  let json = null; try { json = JSON.parse(texto); } catch { /* no JSON */ }
  return { status: res.status, json, texto, headers: res.headers };
};
const chat = (mensajes, extra = {}) => pedir('/api/chat', { metodo: 'POST', cuerpo: { messages: mensajes, consent: true, ...extra } });
const msgOk = [{ role: 'user', content: 'Hoy me siento cansado.' }];
const sesion = async (cred) => (await pedir('/api/admin/login', { metodo: 'POST', cuerpo: cred })).json.accessToken;
const fechaSeed = (r) => ({ slug: 'x', title: 'Título', description: 'Desc', category: 'Cat', resource_type: 'tool', status: 'published', ...r });

before(async () => {
  openai = await iniciarOpenAISimulado();
  supa = await iniciarSupabaseSimulado();
  Object.assign(entorno, {
    OPENAI_API_KEY: CLAVES.openai, OPENAI_BASE_URL: openai.url, OPENAI_MODEL: 'modelo-de-prueba',
    SUPABASE_URL: supa.url, SUPABASE_ANON_KEY: CLAVES.anon, SUPABASE_SERVICE_ROLE_KEY: CLAVES.servicio
  });
  Object.assign(process.env, entorno);
  for (const k of ['OPENAI_REASONING_EFFORT', 'CHAT_LIMIT_PER_MINUTE', 'CONTACT_LIMIT_PER_HOUR', 'LOGIN_LIMIT_PER_15_MIN']) delete process.env[k];
  supa.crearUsuario(ADMIN.email, ADMIN.password, 'admin');
  supa.crearUsuario(USUARIO.email, USUARIO.password, 'user');
  app = await iniciarServidor({ puerto: 0, silencioso: true });
  base = `http://127.0.0.1:${app.puerto}`;
});
after(async () => { await app.cerrar(); await openai.cerrar(); await supa.cerrar(); });
beforeEach(() => {
  Object.assign(process.env, entorno);
  for (const k of ['OPENAI_REASONING_EFFORT', 'CHAT_LIMIT_PER_MINUTE', 'CONTACT_LIMIT_PER_HOUR', 'LOGIN_LIMIT_PER_15_MIN', 'RATE_LIMIT_DEV_MEMORY']) delete process.env[k];
  openai.estado.modo = 'ok'; openai.estado.llamadas.length = 0;
  supa.estado.limites.clear(); supa.estado.llamadas.length = 0; supa.estado.rpcLlamadas.length = 0; supa.estado.rpcModo = 'ok'; supa.estado.mensajes.length = 0; supa.estado.recursos.length = 0; supa.estado.tokens.clear();
  _vaciarMemoria();
});

/* ---------------- /api/health ---------------- */
test('health responde, no revela secretos y distingue la configuración', async () => {
  const r = await pedir('/api/health');
  assert.equal(r.status, 200);
  assert.equal(r.json.status, 'ok');
  assert.equal(r.json.services.ai.configured, true);
  assert.equal(r.json.services.rateLimit.mode, 'database');
  for (const secreto of [CLAVES.openai, CLAVES.servicio, CLAVES.anon]) assert.ok(!r.texto.includes(secreto), 'no debe aparecer ninguna clave');
  delete process.env.OPENAI_API_KEY; delete process.env.SUPABASE_URL;
  const d = await pedir('/api/health');
  assert.equal(d.json.status, 'degraded');
  assert.equal(d.json.services.ai.configured, false);
  // Sin Supabase ya NO hay respaldo en memoria: el control de uso queda «unavailable».
  assert.equal(d.json.services.rateLimit.mode, 'unavailable');
});

test('health?deep=1 comprueba la base de datos', async () => {
  const r = await pedir('/api/health?deep=1');
  assert.equal(r.json.services.database.reachable, true);
});

/* ---------------- /api/chat ---------------- */
test('chat: respuesta correcta, store:false, instrucciones del servidor y sin datos del diario', async () => {
  const r = await chat(msgOk);
  assert.equal(r.status, 200);
  assert.match(r.json.reply, /Gracias por contármelo/);
  const peticion = openai.estado.llamadas[0];
  assert.equal(peticion.auth, `Bearer ${CLAVES.openai}`);
  assert.equal(peticion.cuerpo.model, 'modelo-de-prueba');
  assert.equal(peticion.cuerpo.store, false);
  assert.equal(peticion.cuerpo.reasoning, undefined, 'sin OPENAI_REASONING_EFFORT no se envía reasoning');
  assert.deepEqual(peticion.cuerpo.input, msgOk);
  assert.match(peticion.cuerpo.instructions, /UNMUTE IA/);
  assert.match(peticion.cuerpo.instructions, /nunca digas que has visto el diario/);
  assert.deepEqual(Object.keys(peticion.cuerpo).sort(), ['input', 'instructions', 'max_output_tokens', 'model', 'store']);
});

test('chat: envía reasoning solo si OPENAI_REASONING_EFFORT está definido', async () => {
  process.env.OPENAI_REASONING_EFFORT = 'low';
  await chat(msgOk);
  assert.deepEqual(openai.estado.llamadas[0].cuerpo.reasoning, { effort: 'low' });
});

test('chat: sin clave de API devuelve un error controlado y no llama al proveedor', async () => {
  delete process.env.OPENAI_API_KEY;
  const r = await chat(msgOk);
  assert.equal(r.status, 503);
  assert.equal(r.json.code, 'ai_not_configured');
  assert.equal(openai.estado.llamadas.length, 0);
});

test('chat: exige consentimiento', async () => {
  for (const extra of [{ consent: false }, { consent: 'true' }, { consent: undefined }]) {
    const r = await chat(msgOk, extra);
    assert.equal(r.status, 400);
    assert.equal(r.json.code, 'consent_required');
  }
  assert.equal(openai.estado.llamadas.length, 0);
});

test('chat: rechaza mensajes inválidos', async () => {
  const largo = 'a'.repeat(2501);
  const casos = [
    [], 'hola', [{ role: 'user', content: '   ' }], [{ role: 'system', content: 'x' }], [{ role: 'user', content: 5 }],
    [{ role: 'assistant', content: 'último del asistente' }], [{ role: 'user', content: largo }],
    Array.from({ length: 13 }, () => ({ role: 'user', content: 'hola' })),
    Array.from({ length: 5 }, () => ({ role: 'user', content: 'a'.repeat(2400) }))
  ];
  for (const m of casos) assert.equal((await chat(m)).status, 400, JSON.stringify(m).slice(0, 60));
  assert.equal((await pedir('/api/chat', { metodo: 'POST', crudo: '{no es json' })).status, 400);
  assert.equal(openai.estado.llamadas.length, 0);
});

test('chat: límite de tamaño de la solicitud y método no permitido', async () => {
  const grande = await pedir('/api/chat', { metodo: 'POST', cuerpo: { messages: msgOk, consent: true, relleno: 'x'.repeat(30000) } });
  assert.equal(grande.status, 413);
  const get = await pedir('/api/chat');
  assert.equal(get.status, 405);
  assert.equal(get.headers.get('allow'), 'POST');
});

test('chat: errores del proveedor se traducen sin filtrar detalles', async () => {
  const esperados = { 429: [429, 'ai_rate_limited'], 401: [503, 'ai_auth_error'], 404: [503, 'ai_model_unavailable'], 400: [502, 'ai_bad_request'], 500: [502, 'ai_error'], incompleto: [502, 'ai_incomplete'] };
  for (const [modo, [status, code]] of Object.entries(esperados)) {
    openai.estado.modo = modo; supa.estado.limites.clear();
    const r = await chat(msgOk);
    assert.equal(r.status, status, modo);
    assert.equal(r.json.code, code, modo);
    assert.ok(!r.texto.includes('simulado') && !r.texto.includes(CLAVES.openai));
  }
});

test('chat: el límite de solicitudes por minuto funciona (compartido en la base de datos)', async () => {
  process.env.CHAT_LIMIT_PER_MINUTE = '2';
  assert.equal((await chat(msgOk)).status, 200);
  assert.equal((await chat(msgOk)).status, 200);
  const r = await chat(msgOk);
  assert.equal(r.status, 429);
  assert.ok(Number(r.headers.get('retry-after')) >= 1);
  assert.equal(openai.estado.llamadas.length, 2);
  // El contador se guardó con hash, no con la IP.
  const cubetas = [...supa.estado.limites.keys()];
  assert.ok(cubetas.every((c) => !c.includes('127.0.0.1')));
});

test('chat: sin Supabase NO se recurre a memoria: error controlado 503 y sin llamar a la IA', async () => {
  delete process.env.SUPABASE_URL;
  const r = await chat(msgOk);
  assert.equal(r.status, 503);
  assert.equal(r.json.code, 'rate_limit_unavailable');
  assert.equal(openai.estado.llamadas.length, 0);
});

test('chat: si falla la base del límite el chat NO continúa (503) y no se llama a la IA', async () => {
  process.env.SUPABASE_URL = 'http://127.0.0.1:1';
  const r = await chat(msgOk);
  assert.equal(r.status, 503);
  assert.equal(r.json.code, 'rate_limit_unavailable');
  assert.equal(openai.estado.llamadas.length, 0);
});

/* ---------------- /api/resources y /api/facts/today ---------------- */
function sembrar() {
  supa.nuevoRecurso(fechaSeed({ slug: 'diario', title: 'Diario', resource_type: 'tool', status: 'published', featured: true }));
  supa.nuevoRecurso(fechaSeed({ slug: 'borrador-secreto', title: 'Borrador', status: 'draft' }));
  supa.nuevoRecurso(fechaSeed({ slug: 'dato-a', title: 'Dato A', resource_type: 'fact', status: 'published', source_url: 'https://who.int/a', reviewed_at: '2026-11-16' }));
  supa.nuevoRecurso(fechaSeed({ slug: 'dato-b', title: 'Dato B', resource_type: 'fact', status: 'published', source_url: 'https://who.int/b', reviewed_at: '2026-11-16' }));
  supa.nuevoRecurso(fechaSeed({ slug: 'dato-c-oculto', title: 'Dato C', resource_type: 'fact', status: 'draft' }));
}

test('recursos: el público solo ve publicados y la lectura usa el rol anónimo', async () => {
  sembrar();
  const r = await pedir('/api/resources');
  assert.equal(r.status, 200);
  assert.deepEqual(r.json.resources.map((x) => x.slug).sort(), ['dato-a', 'dato-b', 'diario']);
  assert.ok(supa.estado.llamadas.filter((l) => l.ruta === '/rest/v1/resources').every((l) => l.rol === 'anon'));
  assert.ok(!r.texto.includes('borrador-secreto'));
  const f = await pedir('/api/resources?type=fact');
  assert.equal(f.json.resources.length, 2);
  assert.equal((await pedir('/api/resources?type=otro')).status, 400);
});

test('recursos: detalle por slug, borradores y slugs inválidos dan 404', async () => {
  sembrar();
  assert.equal((await pedir('/api/resources/diario')).json.resource.title, 'Diario');
  assert.equal((await pedir('/api/resources/borrador-secreto')).status, 404);
  assert.equal((await pedir('/api/resources/NO%20VALIDO')).status, 404);
});

test('recursos: sin Supabase el catálogo da 503 controlado', async () => {
  delete process.env.SUPABASE_URL;
  const r = await pedir('/api/resources');
  assert.equal(r.status, 503);
  assert.equal(r.json.code, 'database_not_configured');
});

test('dato del día: estable en el mismo día, cambia con offset y con la fecha', async () => {
  sembrar();
  const a = (await pedir('/api/facts/today?date=2026-11-16')).json;
  const b = (await pedir('/api/facts/today?date=2026-11-16')).json;
  assert.equal(a.fact.slug, b.fact.slug);
  assert.equal(a.total, 2);
  const otro = (await pedir('/api/facts/today?date=2026-11-16&offset=1')).json;
  assert.notEqual(otro.fact.slug, a.fact.slug);
  const manana = (await pedir('/api/facts/today?date=2026-11-17')).json;
  assert.notEqual(manana.fact.slug, a.fact.slug);
  assert.notEqual(a.fact.slug, 'dato-c-oculto');
  assert.equal((await pedir('/api/facts/today?date=2026-13-40')).status, 400);
  assert.equal((await pedir('/api/facts/today?offset=-1')).status, 400);
});

/* ---------------- /api/contact ---------------- */
const contacto = (extra = {}) => pedir('/api/contact', { metodo: 'POST', cuerpo: { name: 'Ana', email: 'ana@correo.test', category: 'sugerencia', message: 'Me gustaría que añadieran más ejercicios.', privacy_accepted: true, website: '', elapsed_ms: 15000, ...extra } });

test('contacto: guarda el mensaje con la clave de servicio y confirma', async () => {
  const r = await contacto();
  assert.equal(r.status, 201);
  assert.equal(r.json.ok, true);
  assert.equal(supa.estado.mensajes.length, 1);
  assert.deepEqual(Object.keys(supa.estado.mensajes[0]).sort(), ['category', 'created_at', 'email', 'id', 'message', 'name', 'status']);
  const insercion = supa.estado.llamadas.find((l) => l.metodo === 'POST' && l.ruta === '/rest/v1/contact_messages');
  assert.equal(insercion.rol, 'service');
});

test('contacto: valida campos y exige el aviso de privacidad', async () => {
  const malos = [{ message: 'corto' }, { category: 'crisis' }, { email: 'no-es-correo' }, { privacy_accepted: false }, { message: 'a'.repeat(2001) }, { message: 'mira http://a.com http://b.com http://c.com por favor' }];
  for (const m of malos) { const r = await contacto(m); assert.equal(r.status, 400, JSON.stringify(m).slice(0, 40)); assert.ok(r.json.fields); }
  assert.equal(supa.estado.mensajes.length, 0);
});

test('contacto: antispam (trampa oculta y envío instantáneo) responde éxito pero no guarda', async () => {
  assert.equal((await contacto({ website: 'http://spam.test' })).status, 201);
  assert.equal((await contacto({ elapsed_ms: 300 })).status, 201);
  assert.equal(supa.estado.mensajes.length, 0);
});

test('contacto: límite de envíos por hora', async () => {
  process.env.CONTACT_LIMIT_PER_HOUR = '2';
  assert.equal((await contacto()).status, 201);
  assert.equal((await contacto()).status, 201);
  assert.equal((await contacto()).status, 429);
  assert.equal(supa.estado.mensajes.length, 2);
});

test('contacto: sin base de datos da 503 controlado', async () => {
  delete process.env.SUPABASE_URL;
  // El control de uso se comprueba antes de guardar: sin Supabase no se puede verificar y se rechaza con 503.
  const r = await contacto();
  assert.equal(r.status, 503);
  assert.equal(r.json.code, 'rate_limit_unavailable');
});

/* ---------------- Administración ---------------- */
test('admin: sin sesión, con token falso o sin permisos se rechaza (también en el servidor)', async () => {
  const rutas = [['GET', '/api/admin/resources'], ['POST', '/api/admin/resources'], ['GET', '/api/admin/messages'], ['GET', '/api/admin/stats'], ['DELETE', '/api/admin/resources/' + crypto.randomUUID()]];
  for (const [metodo, ruta] of rutas) {
    assert.equal((await pedir(ruta, { metodo, cuerpo: metodo === 'POST' ? {} : undefined })).status, 401, `${metodo} ${ruta} sin token`);
    assert.equal((await pedir(ruta, { metodo, token: 'token-inventado', cuerpo: metodo === 'POST' ? {} : undefined })).status, 401, `${metodo} ${ruta} token falso`);
  }
  // Una cabecera que diga «isAdmin» no sirve de nada.
  assert.equal((await pedir('/api/admin/resources', { cabeceras: { 'x-is-admin': 'true' } })).status, 401);
  // Persona autenticada pero sin rol admin.
  supa.estado.tokens.set('tok-normal', [...supa.estado.usuarios.values()].find((u) => u.email === USUARIO.email).id);
  assert.equal((await pedir('/api/admin/resources', { token: 'tok-normal' })).status, 403);
  assert.equal((await pedir('/api/admin/messages', { token: 'tok-normal' })).status, 403);
});

test('admin: login correcto, incorrecto, sin permisos y límite de intentos', async () => {
  const mal = await pedir('/api/admin/login', { metodo: 'POST', cuerpo: { email: ADMIN.email, password: 'incorrecta' } });
  assert.equal(mal.status, 401);
  assert.ok(!mal.texto.toLowerCase().includes('invalid login'));
  const sinPermiso = await pedir('/api/admin/login', { metodo: 'POST', cuerpo: USUARIO });
  assert.equal(sinPermiso.status, 403);
  assert.equal(supa.estado.tokens.size, 0, 'la sesión de una cuenta sin permisos se cierra');
  const ok = await pedir('/api/admin/login', { metodo: 'POST', cuerpo: ADMIN });
  assert.equal(ok.status, 200);
  assert.equal(ok.json.user.email, ADMIN.email);
  const s = await pedir('/api/admin/session', { token: ok.json.accessToken });
  assert.equal(s.json.ok, true);
  assert.equal((await pedir('/api/admin/logout', { metodo: 'POST', token: ok.json.accessToken })).status, 200);
  assert.equal((await pedir('/api/admin/session', { token: ok.json.accessToken })).status, 401);
  assert.equal((await pedir('/api/admin/login', { metodo: 'POST', cuerpo: { email: 'x' } })).status, 400);
  process.env.LOGIN_LIMIT_PER_15_MIN = '2';
  supa.estado.limites.clear();
  await pedir('/api/admin/login', { metodo: 'POST', cuerpo: { email: ADMIN.email, password: 'a' } });
  await pedir('/api/admin/login', { metodo: 'POST', cuerpo: { email: ADMIN.email, password: 'b' } });
  assert.equal((await pedir('/api/admin/login', { metodo: 'POST', cuerpo: ADMIN })).status, 429);
});

test('admin: ciclo completo del catálogo con el token de la persona (RLS) y reglas editoriales', async () => {
  const token = await sesion(ADMIN);
  sembrar();
  const lista = await pedir('/api/admin/resources', { token });
  assert.equal(lista.json.resources.length, 5, 'el admin ve también borradores');
  assert.equal((await pedir('/api/admin/resources?status=draft', { token })).json.resources.length, 2);

  const nuevo = await pedir('/api/admin/resources', { metodo: 'POST', token, cuerpo: { title: 'Árbol de la Calma', description: 'Una descripción', category: 'Calma', resource_type: 'tool', action_url: '#pausa' } });
  assert.equal(nuevo.status, 201);
  assert.equal(nuevo.json.resource.slug, 'arbol-de-la-calma');
  assert.equal(nuevo.json.resource.status, 'draft');
  const id = nuevo.json.resource.id;
  assert.equal((await pedir('/api/admin/resources', { metodo: 'POST', token, cuerpo: { title: 'Árbol de la Calma', description: 'otra', category: 'Calma', resource_type: 'tool' } })).status, 409);
  assert.equal((await pedir('/api/admin/resources', { metodo: 'POST', token, cuerpo: { title: 'x' } })).status, 400);
  assert.equal((await pedir('/api/admin/resources', { metodo: 'POST', token, cuerpo: { title: 'Enlace malo', description: 'd', category: 'c', resource_type: 'tool', action_url: 'javascript:alert(1)' } })).status, 400);

  assert.equal((await pedir(`/api/admin/resources/${id}/publish`, { metodo: 'POST', token })).json.resource.status, 'published');
  assert.ok((await pedir('/api/resources')).json.resources.some((r) => r.slug === 'arbol-de-la-calma'));
  assert.equal((await pedir(`/api/admin/resources/${id}/unpublish`, { metodo: 'POST', token })).json.resource.status, 'draft');
  assert.ok(!(await pedir('/api/resources')).json.resources.some((r) => r.slug === 'arbol-de-la-calma'));
  assert.equal((await pedir(`/api/admin/resources/${id}`, { metodo: 'PATCH', token, cuerpo: { title: 'Árbol de calma' } })).json.resource.title, 'Árbol de calma');
  assert.equal((await pedir(`/api/admin/resources/${id}`, { metodo: 'PATCH', token, cuerpo: {} })).status, 400);

  // Regla editorial: un dato curioso solo se publica con fuente y fecha de revisión.
  const dato = (await pedir('/api/admin/resources', { metodo: 'POST', token, cuerpo: { title: 'Dato nuevo', description: 'd', category: 'Estrés', resource_type: 'fact' } })).json.resource;
  const sinFuente = await pedir(`/api/admin/resources/${dato.id}/publish`, { metodo: 'POST', token });
  assert.equal(sinFuente.status, 400);
  assert.ok(sinFuente.json.fields.source_url && sinFuente.json.fields.reviewed_at);
  const ok = await pedir(`/api/admin/resources/${dato.id}`, { metodo: 'PATCH', token, cuerpo: { source_url: 'https://www.who.int/x', reviewed_at: '2026-11-16', status: 'published' } });
  assert.equal(ok.status, 200);

  assert.equal((await pedir(`/api/admin/resources/${id}`, { metodo: 'DELETE', token })).json.ok, true);
  assert.equal((await pedir(`/api/admin/resources/${id}`, { token })).status, 404);
  assert.equal((await pedir('/api/admin/resources/no-es-uuid', { token })).status, 404);

  // Las operaciones se hicieron como la persona (rol authenticated), no con la clave de servicio.
  const escrituras = supa.estado.llamadas.filter((l) => l.ruta === '/rest/v1/resources' && l.metodo !== 'GET');
  assert.ok(escrituras.length > 5 && escrituras.every((l) => l.rol === 'authenticated'));
  const stats = await pedir('/api/admin/stats', { token });
  assert.equal(stats.json.resources.byType.fact.published, 3);
});

test('admin: mensajes de contacto (listar, filtrar y cambiar estado)', async () => {
  const token = await sesion(ADMIN);
  await contacto(); await contacto({ message: 'Otro mensaje distinto de prueba.' });
  const lista = await pedir('/api/admin/messages', { token });
  assert.equal(lista.json.messages.length, 2);
  const id = lista.json.messages[0].id;
  assert.equal((await pedir(`/api/admin/messages/${id}`, { metodo: 'PATCH', token, cuerpo: { status: 'resolved' } })).json.message.status, 'resolved');
  assert.equal((await pedir('/api/admin/messages?status=new', { token })).json.messages.length, 1);
  assert.equal((await pedir(`/api/admin/messages/${id}`, { metodo: 'PATCH', token, cuerpo: { status: 'inventado' } })).status, 400);
  assert.equal((await pedir('/api/admin/messages?status=zzz', { token })).status, 400);
  assert.equal((await pedir('/api/admin/stats', { token })).json.messages.resolved, 1);
});

test('el público no puede leer mensajes de contacto ni escribir recursos aunque conozca la API de Supabase', async () => {
  // Comprobación del comportamiento esperado de RLS en el simulador: rol anónimo.
  const r = await fetch(`${supa.url}/rest/v1/contact_messages`, { headers: { apikey: CLAVES.anon } });
  assert.equal(r.status, 401);
  const w = await fetch(`${supa.url}/rest/v1/resources`, { method: 'POST', headers: { apikey: CLAVES.anon, 'Content-Type': 'application/json' }, body: '{}' });
  assert.equal(w.status, 401);
});

/* ---------------- Transversales ---------------- */
test('CORS: solo para orígenes declarados en ALLOWED_ORIGINS', async () => {
  process.env.ALLOWED_ORIGINS = 'https://mi-usuario.github.io';
  const permitido = await pedir('/api/health', { cabeceras: { Origin: 'https://mi-usuario.github.io' } });
  assert.equal(permitido.headers.get('access-control-allow-origin'), 'https://mi-usuario.github.io');
  const otro = await pedir('/api/health', { cabeceras: { Origin: 'https://malo.example' } });
  assert.equal(otro.headers.get('access-control-allow-origin'), null);
  const pre = await fetch(`${base}/api/chat`, { method: 'OPTIONS', headers: { Origin: 'https://mi-usuario.github.io' } });
  assert.equal(pre.status, 204);
  delete process.env.ALLOWED_ORIGINS;
});

test('el servidor estático no permite salir de public/ y aplica la CSP de netlify.toml', async () => {
  const trav = await fetch(`${base}/..%2fserver.js`);
  assert.ok([403, 404].includes(trav.status));
  const raiz = await fetch(`${base}/..%2f..%2fetc%2fpasswd`);
  assert.ok([403, 404].includes(raiz.status));
  assert.equal((await fetch(`${base}/api/no-existe`)).status, 404);
});
