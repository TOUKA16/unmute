/* Bloque 4 · Comprobaciones ESTÁTICAS (leen archivos; no usan red ni servicios).
   Cubren la estructura de Inicio, Recursos y la navegación. El comportamiento en navegador se probó aparte, con servicios simulados. */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const leer = (rel) => readFile(new URL(`../${rel}`, import.meta.url), 'utf8');
const sinComentarios = (s) => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');

test('navegación: cinco accesos principales y menú «Más» con Pausa, Noticias, Recursos y Ajustes', async () => {
  const html = await leer('public/index.html');
  const nav = html.slice(html.indexOf('<nav class="principal"'), html.indexOf('</nav>'));
  const principales = [...nav.matchAll(/<li(?: class="mas")?>\s*<(?:a|button)\b/g)];
  assert.equal(principales.length, 5);
  assert.match(nav, /id="masBtn"[^>]*aria-expanded="false"[^>]*aria-controls="menuMas"/);
  const menu = nav.slice(nav.indexOf('id="menuMas"'));
  for (const v of ['pausa', 'noticias', 'recursos', 'ajustes']) assert.match(menu, new RegExp(`href="#${v}" data-v="${v}"`), v);
  assert.doesNotMatch(nav.slice(0, nav.indexOf('id="menuMas"')), /data-v="(pausa|noticias|ajustes)"/); // ya no están sueltos en la barra
  assert.ok(!/ayuda|contacto/i.test(menu), 'Necesito ayuda y Contacto son del siguiente bloque');
});

test('Inicio: dos tarjetas independientes (datos primero, noticias después) y vista Recursos', async () => {
  const html = await leer('public/index.html');
  assert.ok(html.indexOf('id="minuto"') > 0 && html.indexOf('id="minuto"') < html.indexOf('id="noticiaInicio"'));
  for (const id of ['minutoOtra', 'minutoReint', 'nInicioLeer', 'nInicioOtra', 'nInicioReint', 'v-recursos', 'recBuscar', 'recCats', 'recLimpiar', 'recLista']) assert.match(html, new RegExp(`id="${id}"`), id);
  assert.ok(html.indexOf('js/content.js') < html.indexOf('js/resources.js'), 'resources.js usa lo que define content.js');
  assert.equal((html.match(/id="lectorNoticia"/g) || []).length, 1, 'un solo lector de noticias');
});

test('Recursos: solo destinos que existen, texto seguro y sin tocar el diario', async () => {
  const res = await leer('public/js/resources.js');
  const app = await leer('public/js/app.js');
  const vistas = [...app.match(/const VISTAS = \[([^\]]*)\]/)[1].matchAll(/'(\w+)'/g)].map((m) => m[1]);
  assert.ok(vistas.includes('recursos'));
  const destinos = [...res.match(/var DESTINOS = \{([\s\S]*?)\};/)[1].matchAll(/'#(\w+)'/g)].map((m) => m[1]);
  assert.ok(destinos.length >= 6);
  for (const d of destinos) assert.ok(vistas.includes(d), `#${d} debe ser una vista real`);
  assert.match(res, /\/api\/resources/);
  for (const f of ['public/js/resources.js', 'public/js/content.js']) {
    const src = await leer(f);
    assert.ok(!/innerHTML|outerHTML|insertAdjacentHTML|document\.write|eval\(/.test(sinComentarios(src)), f);
    assert.ok(!/localStorage|sessionStorage|unmute_v2_/.test(src), f);
  }
});

test('Inicio: el dato se elige al azar con el «offset» existente (sin API nueva) y la noticia al azar de GET /api/news', async () => {
  const js = await leer('public/js/content.js');
  assert.match(js, /Math\.random\(\)/);
  assert.match(js, /\/api\/facts\/today\?date=/);
  assert.match(js, /'\/api\/news'/);
  assert.match(js, /abrir\(ini\.actual\.slug/); // reutiliza el lector existente
});
