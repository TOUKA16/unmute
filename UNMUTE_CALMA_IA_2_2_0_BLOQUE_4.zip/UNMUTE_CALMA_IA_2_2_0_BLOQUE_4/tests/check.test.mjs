/* Bloque 2 · Pruebas de scripts/check.mjs: debe pasar en el proyecto real y FALLAR (código ≠ 0)
   cuando se reintroduce un problema. Los casos negativos se prueban en copias temporales. */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { spawnSync } from 'node:child_process';
import { cp, mkdtemp, rm, mkdir, writeFile, unlink, readdir, readFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const RAIZ = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const correr = (raiz) => spawnSync(process.execPath, [path.join(RAIZ, 'scripts', 'check.mjs'), '--root', raiz], { encoding: 'utf8' });

async function conCopia(fn) {
  const dir = await mkdtemp(path.join(tmpdir(), 'unmute-check-'));
  try {
    await cp(RAIZ, dir, { recursive: true, filter: (origen) => !/[\\/](node_modules|\.git|\.netlify)([\\/]|$)/.test(origen) });
    return await fn(dir);
  } finally { await rm(dir, { recursive: true, force: true }); }
}

test('check: el proyecto real pasa (código 0) y el resultado es solo informativo', () => {
  const r = correr(RAIZ);
  assert.equal(r.status, 0, r.stdout + r.stderr);
  assert.match(r.stdout, /0 con error/);
});

test('check: una copia sin cambios también pasa (no depende de la ruta)', async () => {
  await conCopia((dir) => assert.equal(correr(dir).status, 0));
});

test('check: falla si la semilla vuelve a public/', async () => {
  await conCopia(async (dir) => {
    await mkdir(path.join(dir, 'public', 'data'), { recursive: true });
    await cp(path.join(dir, 'src', 'data', 'resources-seed.json'), path.join(dir, 'public', 'data', 'resources-seed.json'));
    const r = correr(dir);
    assert.equal(r.status, 1);
    assert.match(r.stdout, /✗ Ninguna semilla JSON dentro de public/);
  });
});

test('check: falla si falta la semilla en su nueva ubicación o la página administrativa', async () => {
  await conCopia(async (dir) => {
    await unlink(path.join(dir, 'src', 'data', 'resources-seed.json'));
    assert.equal(correr(dir).status, 1);
  });
  await conCopia(async (dir) => {
    await unlink(path.join(dir, 'public', 'admin.html'));
    const r = correr(dir);
    assert.equal(r.status, 1);
    assert.match(r.stdout, /✗ Existe public\/admin\.html/);
  });
});

test('check: falla ante un error de sintaxis, un secreto o código en línea bloqueado por la CSP', async () => {
  await conCopia(async (dir) => {
    await writeFile(path.join(dir, 'src', 'lib', 'roto.mjs'), 'export const x = ;\n');
    const r = correr(dir);
    assert.equal(r.status, 1);
    assert.match(r.stdout, /✗ Sintaxis/);
  });
  await conCopia(async (dir) => {
    await writeFile(path.join(dir, 'src', 'lib', 'clave.mjs'), `export const k = 'sk-${'a'.repeat(30)}';\n`);
    const r = correr(dir);
    assert.equal(r.status, 1);
    assert.match(r.stdout, /✗ Sin secretos/);
  });
  await conCopia(async (dir) => {
    const f = path.join(dir, 'public', 'admin.html');
    await writeFile(f, (await readFile(f, 'utf8')).replace('</body>', '<script>alert(1)</script></body>'));
    const r = correr(dir);
    assert.equal(r.status, 1);
    assert.match(r.stdout, /✗ public\/admin\.html: sin código en línea/);
  });
});

test('check: no modifica el proyecto (mismo contenido de archivos antes y después)', async () => {
  const huella = async (dir) => {
    const h = createHash('sha256');
    const recorrer = async (d) => {
      for (const e of (await readdir(d, { withFileTypes: true })).sort((a, b) => a.name.localeCompare(b.name))) {
        const p = path.join(d, e.name);
        if (e.isDirectory()) { h.update(`D:${path.relative(dir, p)}\n`); await recorrer(p); } else h.update(`F:${path.relative(dir, p)}:`).update(await readFile(p));
      }
    };
    await recorrer(dir);
    return h.digest('hex');
  };
  await conCopia(async (dir) => {
    const antes = await huella(dir);
    assert.equal(correr(dir).status, 0);
    assert.equal(await huella(dir), antes);
  });
});
