/* Bloque 2 · Pruebas de la página administrativa, de la protección de la semilla y de las rutas.
   Usan el servidor local (mismas Netlify Functions) con Supabase y OpenAI SIMULADOS:
   comprueban cómo se comporta el proyecto, no que Supabase Auth o Netlify reales funcionen. */
import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { iniciarServidor } from '../server.js';
import { CLAVES, iniciarOpenAISimulado, iniciarSupabaseSimulado } from './helpers/mock-services.mjs';
import { _vaciarMemoria } from '../src/lib/rate-limit.mjs';

let app, openai, supa, base;
const ADMIN = { email: 'admin@unmute.test', password: 'clave-admin-123' };
const USUARIO = { email: 'persona@unmute.test', password: 'clave-persona-123' };
const semilla = JSON.parse(await readFile(new URL('../src/data/resources-seed.json', import.meta.url), 'utf8'));
const borradores = semilla.filter((r) => r.status === 'draft').map((r) => r.slug);

const pedir = async (ruta, { metodo = 'GET', cuerpo, token } = {}) => {
  const res = await fetch(base + ruta, {
    method: metodo,
    headers: { ...(cuerpo !== undefined ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    body: cuerpo !== undefined ? JSON.stringify(cuerpo) : undefined
  });
  const texto = await res.text();
  let json = null; try { json = JSON.parse(texto); } catch { /* no JSON */ }
  return { status: res.status, json, texto, headers: res.headers };
};

before(async () => {
  openai = await iniciarOpenAISimulado();
  supa = await iniciarSupabaseSimulado();
  Object.assign(process.env, { OPENAI_API_KEY: CLAVES.openai, OPENAI_BASE_URL: openai.url, OPENAI_MODEL: 'modelo-de-prueba', SUPABASE_URL: supa.url, SUPABASE_ANON_KEY: CLAVES.anon, SUPABASE_SERVICE_ROLE_KEY: CLAVES.servicio });
  for (const k of ['LOGIN_LIMIT_PER_15_MIN', 'RATE_LIMIT_DEV_MEMORY']) delete process.env[k];
  supa.crearUsuario(ADMIN.email, ADMIN.password, 'admin');
  supa.crearUsuario(USUARIO.email, USUARIO.password, 'user');
  app = await iniciarServidor({ puerto: 0, silencioso: true });
  base = `http://127.0.0.1:${app.puerto}`;
});
after(async () => { await app.cerrar(); await openai.cerrar(); await supa.cerrar(); });
beforeEach(() => {
  for (const k of ['LOGIN_LIMIT_PER_15_MIN', 'RATE_LIMIT_DEV_MEMORY']) delete process.env[k];
  supa.estado.limites.clear(); supa.estado.tokens.clear(); supa.estado.recursos.length = 0; supa.estado.mensajes.length = 0;
  _vaciarMemoria();
});
const cargarSemilla = () => semilla.forEach((r) => supa.nuevoRecurso({ ...r }));

/* ---------- Rutas de la página administrativa ---------- */
test('/admin, /admin/ y /admin.html sirven la página con la CSP del sitio', async () => {
  for (const ruta of ['/admin', '/admin/', '/admin.html']) {
    const r = await pedir(ruta);
    assert.equal(r.status, 200, ruta);
    assert.match(r.headers.get('content-type'), /text\/html/);
    assert.match(r.texto, /<title>Administración · UNMUTE<\/title>/);
    assert.match(r.headers.get('content-security-policy'), /script-src 'self'/);
    assert.match(r.texto, /js\/admin\.js/);
  }
});

test('los recursos que usa la página administrativa se sirven y las rutas /api/ siguen llegando a sus funciones', async () => {
  assert.equal((await pedir('/js/admin.js')).status, 200);
  assert.equal((await pedir('/css/admin.css')).status, 200);
  assert.equal((await pedir('/api/health')).status, 200);
  assert.equal((await pedir('/api/admin/session')).status, 401, 'la API de sesión responde (no devuelve la página)');
  assert.equal((await pedir('/no-existe')).status, 404);
});

test('la página no contiene claves ni nombres de variables secretas', async () => {
  for (const ruta of ['/admin.html', '/js/admin.js']) {
    const { texto } = await pedir(ruta);
    for (const prohibido of [CLAVES.servicio, CLAVES.anon, CLAVES.openai, 'SERVICE_ROLE', 'OPENAI_API_KEY']) assert.ok(!texto.includes(prohibido), `${ruta} no debe incluir ${prohibido}`);
  }
});

/* ---------- La semilla ya no es descargable ---------- */
test('la semilla JSON no es accesible desde el navegador', async () => {
  for (const ruta of ['/data/resources-seed.json', '/src/data/resources-seed.json', '/resources-seed.json', '/%2e%2e/src/data/resources-seed.json']) {
    const r = await pedir(ruta);
    assert.ok([403, 404].includes(r.status), `${ruta} → ${r.status}`);
    assert.ok(!r.texto.includes('"resource_type"'), `${ruta} no debe filtrar contenido`);
  }
});

test('con la semilla real (18 recursos) el catálogo público solo entrega lo publicado', async () => {
  assert.equal(semilla.length, 18);
  assert.ok(borradores.length >= 1, 'la semilla incluye borradores');
  cargarSemilla();
  const publicados = semilla.filter((r) => r.status === 'published');
  const lista = await pedir('/api/resources');
  assert.equal(lista.status, 200);
  assert.equal(lista.json.resources.length, publicados.length);
  assert.ok(lista.json.resources.every((r) => r.status === 'published'));
  for (const slug of borradores) {
    assert.ok(!lista.texto.includes(`"${slug}"`), `la lista pública no incluye ${slug}`);
    assert.equal((await pedir(`/api/resources/${slug}`)).status, 404, `${slug} no se puede pedir por slug`);
  }
  // El dato del día nunca es un borrador, sea cual sea el día.
  for (let offset = 0; offset < 40; offset++) {
    const d = await pedir(`/api/facts/today?date=2026-11-17&offset=${offset}`);
    assert.equal(d.status, 200);
    assert.equal(d.json.fact.status, 'published');
    assert.equal(d.json.fact.resource_type, 'fact');
  }
});

/* ---------- Seguridad de la administración (con Supabase simulado) ---------- */
test('sin sesión válida ninguna operación administrativa funciona, y el servidor ignora cabeceras «de admin»', async () => {
  for (const ruta of ['/api/admin/session', '/api/admin/stats', '/api/admin/resources', '/api/admin/messages']) {
    assert.equal((await pedir(ruta)).status, 401, `${ruta} sin token`);
    assert.equal((await pedir(ruta, { token: 'token-inventado' })).status, 401, `${ruta} con token falso`);
  }
  const falsa = await fetch(`${base}/api/admin/stats`, { headers: { 'x-is-admin': 'true', 'x-user-role': 'admin' } });
  assert.equal(falsa.status, 401);
  // Una cuenta real, pero sin rol de administración: 403 tanto al iniciar sesión como con su token.
  assert.equal((await pedir('/api/admin/login', { metodo: 'POST', cuerpo: USUARIO })).status, 403);
  supa.estado.tokens.set('tok-normal', [...supa.estado.usuarios.values()].find((u) => u.email === USUARIO.email).id);
  assert.equal((await pedir('/api/admin/session', { token: 'tok-normal' })).status, 403);
  assert.equal((await pedir('/api/admin/stats', { token: 'tok-normal' })).status, 403);
});

test('flujo que usa la página: login → sesión → resumen → cierre de sesión (administrador simulado)', async () => {
  cargarSemilla();
  const login = await pedir('/api/admin/login', { metodo: 'POST', cuerpo: ADMIN });
  assert.equal(login.status, 200);
  assert.ok(login.json.accessToken && login.json.expiresIn > 0 && login.json.user.email === ADMIN.email, 'forma de respuesta que lee admin.js');
  assert.ok(!('refresh_token' in login.json) && !login.texto.includes('refresh'), 'no se entrega refresh token al navegador');
  const token = login.json.accessToken;

  const sesion = await pedir('/api/admin/session', { token });
  assert.equal(sesion.status, 200);
  assert.equal(sesion.json.ok, true);
  assert.equal(sesion.json.user.email, ADMIN.email);

  const stats = await pedir('/api/admin/stats', { token });
  assert.equal(stats.status, 200);
  assert.equal(stats.json.resources.total, 18);
  assert.equal(stats.json.resources.draft, borradores.length);
  assert.equal(stats.json.resources.byType.fact.published, semilla.filter((r) => r.resource_type === 'fact' && r.status === 'published').length);
  assert.equal(stats.json.messages.total, 0);

  assert.equal((await pedir('/api/admin/logout', { metodo: 'POST', token })).status, 200);
  assert.equal((await pedir('/api/admin/session', { token })).status, 401, 'tras cerrar sesión el token ya no sirve');
  assert.equal((await pedir('/api/admin/stats', { token })).status, 401);
});

test('login: validación en el servidor y credenciales incorrectas con mensajes comprensibles', async () => {
  const vacio = await pedir('/api/admin/login', { metodo: 'POST', cuerpo: { email: 'no-es-correo', password: '' } });
  assert.equal(vacio.status, 400);
  assert.ok(vacio.json.fields.email && vacio.json.fields.password, 'devuelve los campos que admin.js muestra junto a cada input');
  const mal = await pedir('/api/admin/login', { metodo: 'POST', cuerpo: { email: ADMIN.email, password: 'incorrecta' } });
  assert.equal(mal.status, 401);
  assert.equal(mal.json.error, 'Correo o contraseña incorrectos.');
});
