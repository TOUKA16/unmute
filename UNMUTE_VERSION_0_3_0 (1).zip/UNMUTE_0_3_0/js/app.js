'use strict';
const $=s=>document.querySelector(s);
const $$=s=>[...document.querySelectorAll(s)];
const VIEWS=['inicio','registrar', 'historial'];
function navigate(name){
 if(!VIEWS.includes(name)) return;
 $$('.view').forEach(v=>v.classList.toggle('active',v.id==='view-'+name));
 $$('[data-view]').forEach(b=>b.classList.toggle('active',b.dataset.view===name));
}
document.addEventListener('click',e=>{
 const target=e.target.closest('[data-view],[data-go]');
 if(!target)return;
 navigate(target.dataset.view||target.dataset.go);
});

const form=$('#entryForm'), list=$('#entries');
const KEY='unmute_registros_v1', DRAFT='unmute_borrador_v1';
let entries=[], editing=null;
const moodNames={muyfeliz:'Muy feliz',feliz:'Feliz',neutral:'Neutral',triste:'Triste',mal:'Mal',enojado:'Enojado',ansioso:'Ansioso',cansado:'Cansado'};
const getMood=()=>form.querySelector('[name="mood"]:checked')?.value||'';
const getIntensity=()=>form.querySelector('[name="intensity"]:checked')?.value||'';
const announce=msg=>{const s=$('#formStatus');s.hidden=false;s.textContent=msg;};
const escDate=iso=>new Intl.DateTimeFormat('es',{dateStyle:'medium',timeStyle:'short'}).format(new Date(iso));
function saveLocal(){
 return true;
}

function render(){
 list.replaceChildren();
 if(!entries.length){list.textContent='Aún no tienes registros. Puedes comenzar desde Registrar.';return;}
 entries.slice().reverse().forEach(item=>{
  const card=document.createElement('article');card.className='entry';
  const head=document.createElement('div');head.className='entry-head';
  const title=document.createElement('strong');title.textContent=(moodNames[item.mood]||item.mood)+' · Intensidad '+item.intensity+'/5';
  const date=document.createElement('time');date.dateTime=item.date;date.textContent=escDate(item.date);
  head.append(title,date);card.append(head);
  const note=document.createElement('p');note.textContent=item.note||'Sin nota escrita.';card.append(note);
  const actions=document.createElement('div');actions.className='entry-actions';
  const del=document.createElement('button');del.type='button';del.textContent='Eliminar';del.addEventListener('click',()=>removeEntry(item.id));actions.append(del);

  card.append(actions);list.append(card);
 });
}
function removeEntry(id){
 if(!confirm('¿Eliminar este registro?'))return;
 entries=entries.filter(x=>x.id!==id);saveLocal();render();
}

form.addEventListener('submit',e=>{
 e.preventDefault();
 const mood=getMood(), intensity=getIntensity(), note=$('#note').value.trim();
 if(!mood||!intensity){announce('Selecciona una emoción y una intensidad.');return;}
 const item={id:editing||((crypto.randomUUID&&crypto.randomUUID())||String(Date.now())),date:new Date().toISOString(),mood,intensity:Number(intensity),note};
 if(editing){const i=entries.findIndex(x=>x.id===editing);if(i>=0)entries[i]=item;editing=null;}
 else entries.push(item);
 if(saveLocal()){
  form.reset();$('#note').value='';$('#count').textContent='0 / 800';$('#saveBtn').textContent='Guardar registro';
  try{localStorage.removeItem(DRAFT);}catch(e){}
  announce('Tu registro se guardó en esta etapa.');render();
  if(VIEWS.includes('historial'))navigate('historial');
 }
});
form.addEventListener('reset',()=>{editing=null; if($('#saveBtn'))$('#saveBtn').textContent='Guardar registro';});
$('#note').addEventListener('input',()=>$('#count').textContent=$('#note').value.length+' / 800');


if(VIEWS.includes('historial'))render();
