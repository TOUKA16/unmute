# UNMUTE 0.3.0 — Diario interactivo en sesión

## Cambios incorporados

- El formulario comienza a crear registros con fecha, emoción, intensidad y nota.
- Se incorpora una vista de Historial con las entradas creadas durante la sesión actual.
- Se permite eliminar entradas de la sesión.
- Los registros se mantienen en memoria y se pierden al recargar la página.

## Por qué se incorporaron

Hacer funcional el recorrido esencial del diario y validar la estructura de sus registros antes de incorporar persistencia.

## Archivos principales

- `index.html`: estructura y contenido de la interfaz.
- `css/styles.css`: estilos visuales y adaptación de la interfaz.
- `js/app.js`: navegación y comportamiento de las funciones incorporadas.

## Cómo probarla

Abre `index.html` en un navegador moderno. No requiere instalación ni servicios externos.

## Alcance y límites funcionales

La aplicación permite registrar y consultar entradas mientras la página permanece abierta. No conserva los registros después de recargar.

## Privacidad

No se envían entradas a servidores. Los registros de esta versión existen únicamente en la memoria de la sesión.

## Comprobaciones realizadas

- Sintaxis JavaScript comprobada con `node --check`.
- No se detectaron IDs HTML duplicados.
- Se comprobaron las referencias locales a CSS y JavaScript.
- No se certificó la accesibilidad mediante una auditoría externa ni se realizó una prueba completa con lectores de pantalla.
