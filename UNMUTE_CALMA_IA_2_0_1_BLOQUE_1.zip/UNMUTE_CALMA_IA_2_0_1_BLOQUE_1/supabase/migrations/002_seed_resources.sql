-- UNMUTE · Migración 002 · Contenido inicial del catálogo y datos curiosos
-- GENERADO con «npm run seed:build» desde public/data/resources-seed.json. No lo edites a mano.
-- Es seguro ejecutarlo más de una vez: «on conflict do nothing» respeta lo que ya hayas editado desde el panel de administración.
-- Los datos curiosos fueron comprobados contra su fuente el 2026-11-16; conviene que una persona del equipo los vuelva a revisar.

insert into public.resources
  (slug, title, description, content, category, resource_type, icon, action_url, source_url, reviewed_at, status, featured)
values
  ('diario-emocional', 'Diario emocional', 'Un espacio privado para escribir lo que piensas y sientes, con un check-in opcional, etiquetas y borradores automáticos.', '1. Abre «Diario» y, si quieres, responde el check-in o salta directo a escribir.
2. Escribe sin prisa: el título y las etiquetas son opcionales.
3. Guarda la entrada. Se queda solo en este dispositivo.
4. Consúltala o edítala después en «Historia».', 'Escritura', 'tool', 'book', '#diario', null, null, 'published', true),
  ('acompanamiento-ia', 'Acompañamiento con inteligencia artificial', 'Una conversación de apoyo para ordenar lo que sientes. No es terapia, no diagnostica y no es un servicio de emergencias.', '1. Abre «Acompañar» y lee el aviso de privacidad.
2. Marca el consentimiento solo si estás de acuerdo.
3. Escribe a tu ritmo. Tu diario no se envía.
4. Puedes limpiar la conversación o retirar el consentimiento cuando quieras.', 'Acompañamiento', 'tool', 'chat', '#acompanar', null, null, 'published', true),
  ('respiracion-guiada', 'Respiración guiada', 'Un círculo que se expande y se contrae para acompañar una respiración lenta. Puedes detenerlo en cualquier momento.', '1. Abre «Pausa».
2. En «Respirar durante un momento», pulsa Empezar.
3. Inhala cuando el círculo crece y exhala cuando se contrae.
4. Pulsa Detener cuando quieras. No es un tratamiento.', 'Calma', 'tool', 'wind', '#pausa', null, null, 'published', false),
  ('orientacion-sensorial', 'Volver al presente', 'Un ejercicio breve de tres pasos para notar lo que ves, lo que sientes y lo que oyes a tu alrededor.', '1. Abre «Pausa».
2. En «Volver al presente», pulsa Empezar.
3. Sigue los tres pasos a tu ritmo.
4. Pulsa Salir cuando quieras.', 'Calma', 'tool', 'eye', '#pausa', null, null, 'published', false),
  ('escritura-reflexiva', 'Escritura libre con temporizador', 'Escribe sin corregir durante uno a cinco minutos. Lo que escribes no se guarda a menos que tú lo decidas.', '1. Abre «Pausa».
2. En «Escribir durante unos minutos», elige la duración.
3. Pulsa Empezar temporizador y escribe sin editar.
4. Si quieres conservarlo, pulsa «Guardar como entrada».', 'Escritura', 'tool', 'pen', '#pausa', null, null, 'published', false),
  ('biblioteca-informacion', 'Información confiable sobre salud mental', 'Datos breves sobre emociones, estrés, sueño y bienestar. Cada uno indica su fuente y la fecha en que se revisó.', '1. Pulsa «Abrir» para ver la información publicada.
2. Usa la búsqueda o el filtro de categoría.
3. Abre la fuente de cada dato para profundizar.
4. Esta información es educativa: no sustituye la atención de profesionales.', 'Información', 'guide', 'info', '#recursos/informacion', null, null, 'published', false),
  ('explorador-de-emociones', 'Explorador de emociones', 'Una biblioteca interactiva para reconocer y diferenciar emociones, sin diagnósticos. Todavía no está disponible.', 'Función prevista. Se publicará cuando esté construida y probada.', 'Emociones', 'tool', 'compass', null, null, null, 'draft', false),
  ('kit-personal-de-calma', 'Kit personal de calma', 'Una lista privada de actividades, lugares y recordatorios que te ayudan. Todavía no está disponible.', 'Función prevista. Se publicará cuando esté construida y probada.', 'Calma', 'tool', 'heart', null, null, null, 'draft', false),
  ('dormir-al-menos-siete-horas', 'Dormir lo suficiente también cuida tu ánimo', 'Los CDC indican que la mayoría de los adultos necesita al menos 7 horas de sueño cada noche, y que niños y adolescentes necesitan más. Los adultos que duermen menos de 7 horas dicen con más frecuencia haber tenido problemas de salud, entre ellos la depresión.', '', 'Sueño y descanso', 'fact', null, null, 'https://cdc.gov/heart-disease/about/sleep-and-heart-health.html', '2026-11-16', 'published', false),
  ('salud-mental-es-mas-que-no-estar-enfermo', 'La salud mental es más que no estar enfermo', 'Según la OMS, la salud mental es un estado de bienestar que permite afrontar las tensiones de la vida, desarrollar las propias capacidades, aprender, trabajar y aportar a la comunidad. Es más que la ausencia de enfermedad.', '', 'Salud mental', 'fact', null, null, 'https://www.who.int/europe/news-room/fact-sheets/item/mental-health', '2026-11-16', 'published', false),
  ('mito-esto-solo-me-pasa-a-mi', 'Mito: «Esto solo me pasa a mí»', 'La OMS señala que, en todo el mundo, más de mil millones de personas viven con una condición de salud mental. Es una experiencia frecuente, y existen estrategias asequibles y eficaces para promover, proteger y restablecer la salud mental.', '', 'Mitos y realidades', 'fact', null, null, 'https://www.who.int/News-Room/Fact-Sheets/Detail/Mental-Health-Strengthening-Our-Response', '2026-11-16', 'published', false),
  ('estres-y-ansiedad-no-son-lo-mismo', 'El estrés y la ansiedad no son lo mismo', 'Según el NIMH, el estrés suele responder a una causa externa, como un examen, y tiende a desaparecer cuando la situación se resuelve. Puede ser positivo, por ejemplo al ayudarte a cumplir una fecha límite, o negativo, como cuando te quita el sueño. La ansiedad, en cambio, suele persistir aunque no haya una amenaza inmediata.', '', 'Estrés', 'fact', null, null, 'https://www.nimh.nih.gov/health/publications/stress', '2026-11-16', 'published', false),
  ('ponerle-nombre-a-una-emocion', 'Ponerle nombre a lo que sientes', 'En un estudio de neuroimagen de 2007, nombrar la emoción de una imagen se asoció con una menor respuesta de la amígdala, una región cerebral implicada en las reacciones emocionales. Es un hallazgo de laboratorio, no una garantía: nombrar lo que sientes no resuelve por sí solo la causa.', '', 'Cerebro y comportamiento', 'fact', null, null, 'https://pubmed.ncbi.nlm.nih.gov/17576282/', '2026-11-16', 'published', false),
  ('cambiar-de-tarea-tiene-un-costo', 'Cambiar de tarea tiene un costo', 'Según la APA, al saltar de una tarea a otra se pierde tiempo, y más cuanto más complejas o poco familiares son las tareas. Cada cambio puede costar solo unas décimas de segundo, pero se acumulan si cambias muchas veces. Hacer una cosa a la vez suele ser más eficiente.', '', 'Atención y concentración', 'fact', null, null, 'https://www.apa.org/topics/research/multitasking', '2026-11-16', 'published', false),
  ('cualquier-movimiento-cuenta', 'Moverte un poco también cuenta', 'La OMS indica que, en adultos, la actividad física reduce los síntomas de depresión y ansiedad y puede mejorar el bienestar general. Sus guías subrayan que cualquier cantidad de actividad es mejor que ninguna: todo movimiento cuenta.', '', 'Autocuidado', 'fact', null, null, 'https://www.who.int/News-Room/Fact-Sheets/Detail/Physical-Activity', '2026-11-16', 'published', false),
  ('sentirse-solo-no-es-estar-solo', 'Sentirse solo no es lo mismo que estar solo', 'Los CDC distinguen entre aislamiento social, que es tener pocas relaciones o poco contacto con otras personas, y soledad, que es la sensación de estar desconectado de los demás. Incluso una persona con muchas amistades puede sentirse sola.', '', 'Relaciones interpersonales', 'fact', null, null, 'https://www.cdc.gov/social-connectedness/risk-factors/index.html', '2026-11-16', 'published', false),
  ('respirar-lento-tecnica-de-relajacion', 'Respirar lento: una técnica de relajación estudiada', 'El NCCIH, de los Institutos Nacionales de Salud de EE. UU., incluye la respiración lenta y profunda entre las técnicas de relajación. Una revisión de 2019 encontró evidencia preliminar de que la respiración diafragmática puede ayudar a reducir el estrés. No debe usarse para reemplazar la atención de un profesional.', '', 'Autocuidado', 'fact', null, null, 'https://www.nccih.nih.gov/health/stress', '2026-11-16', 'published', false),
  ('un-diario-entre-las-ideas-del-nimh', 'Un diario, entre las ideas del NIMH para días abrumadores', 'El NIMH incluye llevar un diario entre las actividades que puedes probar cuando te sientes abrumado. También recuerda que puede requerir ensayo y error descubrir qué te funciona mejor, y que si los síntomas no desaparecen conviene hablar con un profesional.', '', 'Psicología cotidiana', 'fact', null, null, 'https://www.nimh.nih.gov/health/publications/stress', '2026-11-16', 'published', false)
on conflict (slug) do nothing;
