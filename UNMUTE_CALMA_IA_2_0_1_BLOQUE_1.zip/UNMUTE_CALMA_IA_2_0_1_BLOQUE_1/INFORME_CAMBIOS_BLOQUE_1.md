# UNMUTE 2.0.1 — Bloque 1
## Informe de cambios

**Versión de partida:** UNMUTE Calma IA 2.0.0  
**Versión actualizada:** UNMUTE 2.0.1  
**Bloque:** 1 — Reparaciones críticas  
**Alcance:** consentimiento del chat con IA y control seguro de límites de uso.

---

## 1. Resumen

UNMUTE 2.0.1 incorpora dos reparaciones importantes sobre la versión Calma IA 2.0.0. La primera corrige el envío del consentimiento del chat para que el frontend comunique el estado real de la casilla de privacidad. La segunda elimina el respaldo silencioso del rate limit en memoria y exige que el control de uso compartido mediante Supabase esté disponible antes de continuar con operaciones protegidas.

El objetivo del bloque es evitar que una solicitud de IA se envíe sin consentimiento válido y que una falla del servicio de límites se interprete como autorización para continuar sin control.

## 2. Cambios incorporados

### 2.1. Consentimiento real en Acompañar con IA

**Archivo principal:** `public/js/ai-chat.js`  
**Validación de servidor conservada:** `src/lib/validation.mjs`

Cambios:
- La solicitud `POST /api/chat` ahora incluye `consent: consent.checked === true`, tomando el valor directamente de la casilla real `#aiConsent`.
- El botón de envío permanece deshabilitado mientras no exista consentimiento y el usuario recibe una explicación cuando escribe sin marcar la casilla.
- Si se intenta enviar sin consentimiento, no se realiza la petición, se informa que el mensaje no fue enviado, el foco pasa a la casilla y el texto escrito se conserva.
- El backend continúa exigiendo `consent === true`; no se relajó ni sustituyó la validación del servidor.

**Por qué se hizo:** el frontend no debe asumir ni inventar la aceptación. La persona debe decidir expresamente, y el servidor debe seguir comprobando esa decisión antes de procesar el mensaje.

**Se conserva:** personalidad de UNMUTE IA, contexto limitado a un máximo de 12 mensajes y 8500 caracteres, `store: false`, conversación mantenida en memoria de la página y separación completa respecto al diario.

### 2.2. Control de uso seguro para producción

**Archivos principales:**
- `src/lib/rate-limit.mjs`
- `src/config/environment.mjs`
- `netlify/functions/health.mjs`

Cambios:
- Se elimina el fallback silencioso a contadores en memoria.
- En el funcionamiento normal, los límites se consumen mediante la función SQL atómica `consume_rate_limit` de Supabase, compartida entre instancias.
- Si faltan credenciales, Supabase no responde, el RPC no existe, falla o devuelve una respuesta inesperada, la solicitud se rechaza con HTTP 503 y código `rate_limit_unavailable`.
- Si los parámetros de límite son inválidos (cero, negativos o no enteros), el control también falla de forma cerrada.
- El fallo del rate limit impide que las operaciones protegidas continúen hacia OpenAI, el almacenamiento del contacto o la autenticación administrativa.
- El contador en memoria solo se permite cuando `RATE_LIMIT_DEV_MEMORY=true` y el proceso se encuentra fuera de Netlify. Es una ayuda para desarrollo local y no se considera apta para producción.
- Se añade `isNetlifyRuntime()` para identificar el entorno Netlify y evitar que la opción de memoria se active allí.
- El endpoint de salud informa el modo del rate limit como `database`, `unavailable` o `memory`. Cuando no es posible aplicar el control, el estado general se marca como `degraded`.

**Por qué se hizo:** los contadores en memoria no son compartidos entre instancias serverless y se reinician cuando cambia el proceso. En producción, la falta del control persistente no debe convertirse en acceso ilimitado.

### 2.3. Límites que se conservan

Los límites configurados no cambian:

| Operación | Límite |
|---|---:|
| Chat por persona | 8 por minuto |
| Chat por persona | 80 por día |
| Chat global | 3000 por día |
| Contacto | 5 por hora |
| Inicio de sesión | 10 cada 15 minutos |

El identificador de cliente se deriva mediante HMAC de la IP; no se almacena el contenido del mensaje en el contador.

### 2.4. Base de datos y migraciones

No se añade una migración. Se reutiliza `consume_rate_limit`, definida en `supabase/migrations/001_initial_schema.sql`, que utiliza una operación atómica `INSERT ... ON CONFLICT DO UPDATE` y restringe su ejecución al rol de servicio.

La implementación debe probarse con la instancia Supabase real del proyecto para confirmar que la función SQL y sus permisos están efectivamente desplegados.

### 2.5. Configuración y documentación

Se actualizan `.env.example` y `README.md` para explicar `RATE_LIMIT_DEV_MEMORY`, su uso exclusivamente local y el comportamiento 503 cuando el control persistente no está disponible.

## 3. Archivos involucrados

**Modificados:**
- `public/js/ai-chat.js`
- `src/lib/rate-limit.mjs`
- `src/config/environment.mjs`
- `netlify/functions/health.mjs`
- `.env.example`
- `README.md`
- `tests/api.test.mjs`
- `tests/helpers/mock-services.mjs`

**Añadidos:**
- `tests/chat-consent.test.mjs`
- `tests/rate-limit.test.mjs`

No se requiere una migración SQL nueva.

## 4. Comportamiento local después de la actualización

Sin Supabase configurado, las operaciones que requieren rate limit (chat, contacto e inicio de sesión) devuelven HTTP 503 `rate_limit_unavailable`. Ya no continúan usando un contador en memoria de manera automática.

Para pruebas locales aisladas, se puede activar expresamente `RATE_LIMIT_DEV_MEMORY=true` en `.env` y ejecutar `npm start`. Esta opción se ignora en Netlify, incluido `netlify dev`, deploy previews y branch deploys. El contador local se reinicia con el proceso y no ofrece coordinación entre instancias.

## 5. Pruebas y resultados de esta revisión

| Comprobación | Resultado | Alcance |
|---|---|---|
| `npm test` | **47/47 aprobadas** | Pruebas automatizadas con servicios simulados. Incluyen consentimiento, fallos de Supabase, límites y concurrencia simulada. |
| `npm run seed:check` | **Correcto** | La semilla coincide con la migración SQL generada. |
| `npm run check` | **No ejecutable** | El script apunta a `scripts/check.mjs`, pero ese archivo no está incluido en el ZIP. |
| `npm run e2e` | **No ejecutable** | El script apunta a `tests/e2e-smoke.mjs`, pero ese archivo no está incluido en el ZIP. |
| Integridad del ZIP | **Correcta** | El paquete se pudo descomprimir y leer. |

Las pruebas con mocks no equivalen a una verificación contra Supabase real, OpenAI real o Netlify desplegado. No se declara que esas integraciones hayan sido probadas en producción durante esta revisión.

## 6. Pendientes recomendados

1. Incorporar `scripts/check.mjs` o ajustar el comando `check` para que apunte a un verificador existente.
2. Incorporar `tests/e2e-smoke.mjs` o retirar temporalmente el comando `e2e` hasta que exista una prueba reproducible.
3. Verificar con Supabase real que `consume_rate_limit` responde correctamente, que el rol de servicio puede ejecutarla y que los límites compartidos actúan entre instancias.
4. Verificar en Netlify que el runtime se detecta correctamente y que el modo en memoria se mantiene deshabilitado.
5. Probar en entorno de despliegue que, al fallar el control persistente, chat, contacto y login responden 503 sin continuar la operación.

---

**UNMUTE — Tu voz también merece ser escuchada.**
