/* ==========================================================
   UNMUTE · Servidor LOCAL de desarrollo (sin dependencias)
   Qué hace: sirve la carpeta public/ y ejecuta las MISMAS funciones de netlify/functions/
   (la lógica de negocio vive solo allí y en src/). No se usa en producción: en Netlify,
   los archivos estáticos y las funciones los sirve la propia plataforma.
   Alternativa equivalente: «npx netlify-cli dev».
   ========================================================== */
import http from 'node:http';
import { readFile, readdir, stat } from 'node:fs/promises';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { fileURLToPath, pathToFileURL } from 'node:url';

const RAIZ = path.dirname(fileURLToPath(import.meta.url));
const PUBLICO = path.join(RAIZ, 'public');
const FUNCIONES = path.join(RAIZ, 'netlify', 'functions');
const TIPOS = {
  '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.ico': 'image/x-icon', '.txt': 'text/plain; charset=utf-8', '.webp': 'image/webp'
};

// Lee .env si existe (no pisa variables ya definidas en el entorno).
try { process.loadEnvFile(path.join(RAIZ, '.env')); } catch { /* sin .env: se usan las variables del sistema */ }

/** Convierte una ruta de Netlify (/api/x/:id, /api/*) en expresión regular. */
function aRegex(patron) {
  const cuerpo = patron.split('/').map((seg) => (seg.startsWith(':') ? '([^/]+)' : seg === '*' ? '(.*)' : seg.replace(/[.+?^${}()|[\]\\]/g, '\\$&'))).join('/');
  return new RegExp(`^${cuerpo}/?$`);
}

async function cargarRutas() {
  const rutas = [];
  for (const archivo of (await readdir(FUNCIONES)).filter((f) => f.endsWith('.mjs')).sort()) {
    const mod = await import(pathToFileURL(path.join(FUNCIONES, archivo)).href);
    for (const patron of [].concat(mod.config?.path ?? [])) {
      rutas.push({ patron, regex: aRegex(patron), claves: [...patron.matchAll(/:([A-Za-z_]+)/g)].map((m) => m[1]), manejador: mod.default });
    }
  }
  // Las rutas fijas ganan a las que tienen parámetros o comodines.
  return rutas.sort((a, b) => (a.patron.includes(':') || a.patron.includes('*')) - (b.patron.includes(':') || b.patron.includes('*')));
}

// Las cabeceras de seguridad se leen de netlify.toml para probar localmente la misma CSP que en producción.
async function cargarCabeceras() {
  try {
    const toml = await readFile(path.join(RAIZ, 'netlify.toml'), 'utf8');
    const bloque = toml.split('[[headers]]').find((b) => /for\s*=\s*"\/\*"/.test(b));
    const salida = {};
    for (const m of (bloque || '').matchAll(/^\s*([A-Za-z-]+)\s*=\s*"(.*)"\s*$/gm)) if (m[1] !== 'for') salida[m[1]] = m[2];
    delete salida['Strict-Transport-Security']; // solo tiene sentido con HTTPS
    return salida;
  } catch { return {}; }
}

async function aRequest(req, puerto) {
  const trozos = []; let tamano = 0;
  for await (const t of req) { tamano += t.length; if (tamano > 2_000_000) throw new Error('cuerpo demasiado grande'); trozos.push(t); }
  const headers = new Headers();
  for (const [k, v] of Object.entries(req.headers)) if (v !== undefined) headers.set(k, Array.isArray(v) ? v.join(', ') : v);
  const sinCuerpo = req.method === 'GET' || req.method === 'HEAD';
  return new Request(`http://${req.headers.host || `localhost:${puerto}`}${req.url}`, { method: req.method, headers, body: sinCuerpo || !trozos.length ? undefined : Buffer.concat(trozos) });
}

export async function iniciarServidor({ puerto = Number(process.env.PORT || 3000), silencioso = false } = {}) {
  const [rutas, cabeceras] = await Promise.all([cargarRutas(), cargarCabeceras()]);
  let direccionPuerto = puerto;

  const servidor = http.createServer(async (req, res) => {
    try {
      const { pathname } = new URL(req.url, 'http://localhost');
      if (pathname.startsWith('/api/')) {
        for (const r of rutas) {
          const m = r.regex.exec(pathname);
          if (!m) continue;
          const params = Object.fromEntries(r.claves.map((c, i) => [c, decodeURIComponent(m[i + 1])]));
          const request = await aRequest(req, direccionPuerto);
          const respuesta = await r.manejador(request, { params, ip: req.socket.remoteAddress, requestId: randomUUID() });
          res.writeHead(respuesta.status, Object.fromEntries(respuesta.headers));
          return res.end(Buffer.from(await respuesta.arrayBuffer()));
        }
        res.writeHead(404, { 'Content-Type': 'application/json; charset=utf-8' });
        return res.end(JSON.stringify({ error: 'Ruta de API no encontrada.', code: 'not_found' }));
      }

      // Archivos estáticos con ruta segura (sin salir de public/).
      let relativa = decodeURIComponent(pathname);
      if (relativa === '/admin') relativa = '/admin.html'; // igual que la redirección de netlify.toml
      if (relativa.endsWith('/')) relativa += 'index.html';
      const archivo = path.normalize(path.join(PUBLICO, relativa));
      if (!archivo.startsWith(PUBLICO + path.sep)) { res.writeHead(403); return res.end('Prohibido'); }
      const info = await stat(archivo).catch(() => null);
      if (!info?.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); return res.end('No encontrado'); }
      res.writeHead(200, { ...cabeceras, 'Content-Type': TIPOS[path.extname(archivo)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      return res.end(await readFile(archivo));
    } catch (err) {
      console.error('[unmute-local] error', err?.message);
      if (!res.headersSent) res.writeHead(500, { 'Content-Type': 'application/json; charset=utf-8' });
      return res.end(JSON.stringify({ error: 'Ocurrió un error inesperado.', code: 'internal_error' }));
    }
  });

  await new Promise((ok, fallo) => { servidor.once('error', fallo); servidor.listen(puerto, '127.0.0.1', ok); });
  direccionPuerto = servidor.address().port;
  if (!silencioso) {
    const { getConfig } = await import('./src/config/environment.mjs');
    const cfg = getConfig();
    console.log(`UNMUTE (modo local) está disponible en http://localhost:${direccionPuerto}`);
    console.log(`· IA: ${cfg.openai.apiKey ? `configurada (modelo ${cfg.openai.model})` : 'sin configurar (falta OPENAI_API_KEY)'}`);
    console.log(`· Supabase: ${cfg.supabase.url && cfg.supabase.anonKey ? 'configurado' : 'sin configurar (catálogo, contacto y administración no funcionarán; se usarán datos de ejemplo)'}`);
  }
  return { servidor, puerto: direccionPuerto, cerrar: () => new Promise((ok) => servidor.close(ok)) };
}

if (process.argv[1] && pathToFileURL(path.resolve(process.argv[1])).href === import.meta.url) {
  iniciarServidor().catch((e) => { console.error('No se pudo iniciar el servidor local:', e.message); process.exit(1); });
}
