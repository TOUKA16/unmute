# UNMUTE — Calma orgánica + IA

**Versión:** 2.0.1  
**Bloque:** 1 — Reparaciones críticas  
**Lema:** «Tu voz también merece ser escuchada».

## Cambios de esta versión

1. **Consentimiento del chat:** el frontend envía el estado real de la casilla de privacidad. Sin aceptación no se envía la solicitud; el backend sigue validando el consentimiento.
2. **Rate limit seguro:** se elimina el fallback silencioso a memoria. Supabase es el mecanismo compartido y, si no está disponible, las operaciones protegidas fallan con HTTP 503 `rate_limit_unavailable`.

El contador en memoria solo puede activarse para desarrollo local mediante `RATE_LIMIT_DEV_MEMORY=true`; se ignora en Netlify y no es apto para producción.

## Arquitectura

- Frontend: HTML, CSS y JavaScript en `public/`.
- Backend: Netlify Functions en `netlify/functions/`.
- Datos y rate limit: Supabase / PostgreSQL.
- IA: OpenAI desde el backend.
- Configuración: `src/config/`.
- Librerías comunes: `src/lib/`.
- Servicios: `src/services/`.
- Migraciones: `supabase/migrations/`.
- Pruebas: `tests/`.

## Desarrollo local

1. Instala Node.js 20.12 o superior.
2. Copia `.env.example` a `.env` y configura las variables requeridas.
3. Ejecuta `npm install` si el proyecto necesita instalar dependencias.
4. Ejecuta `npm start` y abre `http://localhost:3000`.

Sin Supabase configurado, chat, contacto y login rechazan solicitudes con `rate_limit_unavailable`. Para pruebas locales aisladas se permite activar `RATE_LIMIT_DEV_MEMORY=true`; no uses esa opción en producción ni en Netlify.

## Comandos de verificación

```bash
npm test
npm run seed:check
npm run check
npm run e2e
```

En el ZIP de esta versión, `npm test` y `npm run seed:check` funcionan. Los comandos `check` y `e2e` están declarados, pero sus archivos (`scripts/check.mjs` y `tests/e2e-smoke.mjs`) no están incluidos; por tanto, fallan hasta que se incorporen o se corrijan los scripts.

Consulta `INFORME_CAMBIOS_BLOQUE_1.md` para el detalle de los cambios, las pruebas y los pendientes.

## Privacidad

El diario permanece en el almacenamiento local del navegador y no se adjunta al chat. Acompañar solo envía los mensajes que la persona decide compartir después de aceptar el aviso. `store: false` no es una garantía de retención cero por parte del proveedor de IA.
