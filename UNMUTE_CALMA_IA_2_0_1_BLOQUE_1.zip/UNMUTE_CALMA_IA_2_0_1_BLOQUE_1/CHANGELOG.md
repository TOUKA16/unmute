# CHANGELOG · UNMUTE

## [2.0.1] · Bloque 1 · Reparaciones críticas del backend
Base: `unmute-calma-ia-actualizado (1).zip` (16-nov-2026). Alcance: solo las dos reparaciones siguientes.

### Reparación 1 · Consentimiento del chat con IA
- `public/js/ai-chat.js`: la petición `POST /api/chat` ahora incluye `consent: consent.checked === true`, es decir, el estado REAL de la casilla de privacidad (`#aiConsent`). Nunca se escribe `consent: true` a mano.
- Sin consentimiento no se envía nada: el botón sigue desactivado, se explica el motivo mientras la persona escribe («Marca la casilla de privacidad para habilitar el envío.») y, si aun así se intenta enviar, se muestra un mensaje claro, se lleva el foco a la casilla y se conserva el texto escrito.
- Sin cambios en: HTML, estilos, personalidad de UNMUTE IA, límite de contexto (12 mensajes / 8500 caracteres), `store: false`, ni en el almacenamiento local del diario. El servidor sigue exigiendo `consent === true` (`src/lib/validation.mjs` sin modificar).

### Reparación 2 · Límites de uso seguros para producción
- `src/lib/rate-limit.mjs` reescrito: ya no existe el respaldo silencioso en memoria.
  - Con Supabase (modo normal) se usa solo `consume_rate_limit` (atómica, compartida entre instancias).
  - Si faltan credenciales, Supabase no responde, el RPC no existe/falla o devuelve una respuesta con forma inesperada → **HTTP 503** `rate_limit_unavailable`, mensaje genérico, sin detalles internos, y la solicitud no continúa (no llega a OpenAI, no se guarda el contacto, no se intenta autenticar).
  - Parámetros de límite no válidos (0, negativos, no enteros) también se rechazan con 503 en lugar de interpretarse como «sin límite».
  - Contador en memoria: solo con `RATE_LIMIT_DEV_MEMORY=true` y solo fuera de Netlify. Se ignora (con aviso en el registro) en producción, deploy previews, branch deploys y `netlify dev`. Se avisa por consola de que no es apto para producción.
- `src/config/environment.mjs`: nueva `isNetlifyRuntime()` y `rateLimit.devMemory`. Detecta Netlify por el objeto global `Netlify` y por variables de AWS Lambda; `NETLIFY`/`CONTEXT` solo como señal adicional, porque según la documentación de Netlify son variables de compilación y no llegan a las funciones en ejecución.
- `netlify/functions/health.mjs`: `services.rateLimit.mode` pasa a ser `database` | `unavailable` | `memory` (este último solo en local explícito); `status` pasa a `degraded` si es `unavailable`. (Dependencia mínima: el health reportaba un modo «memory» que ya no existe por defecto.)
- Límites y periodos sin cambios: chat 8/min y 80/día por persona, 3000/día global; contacto 5/h; login 10/15 min (`CHAT_LIMIT_*`, `CONTACT_LIMIT_PER_HOUR`, `LOGIN_LIMIT_PER_15_MIN`).
- Base de datos: **sin migración nueva**. Se revisó `consume_rate_limit` en `001_initial_schema.sql` (INSERT … ON CONFLICT DO UPDATE atómico, permisos solo para `service_role`) y es compatible con lo requerido.
- `.env.example` y `README.md`: documentan `RATE_LIMIT_DEV_MEMORY` y el nuevo comportamiento.

### Cambios de comportamiento a tener en cuenta
- Sin Supabase configurado, el chat, el contacto y el login responden 503 `rate_limit_unavailable` (antes seguían con límite en memoria). Para probar en local sin Supabase: `RATE_LIMIT_DEV_MEMORY=true` en `.env` y `npm start`.
- `netlify dev` cuenta como entorno Netlify: allí se necesita Supabase configurado (la opción en memoria se ignora).

### Pruebas
- Nuevas: `tests/chat-consent.test.mjs`, `tests/rate-limit.test.mjs`. Ampliado `tests/helpers/mock-services.mjs` (modos de fallo del RPC).
- Actualizadas en `tests/api.test.mjs` las 3 pruebas que codificaban el respaldo en memoria (ahora esperan 503).
