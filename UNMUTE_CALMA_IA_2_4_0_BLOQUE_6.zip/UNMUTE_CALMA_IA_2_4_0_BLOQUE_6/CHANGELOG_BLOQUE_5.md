# CHANGELOG · BLOQUE 5 — Necesito ayuda + Contacto con seguimiento
Versión: **2.3.0** · Base: `UNMUTE_BLOQUE_4.zip` (2.2.0) · Entrega: `UNMUTE_BLOQUE_5.zip`

## 1. Alcance
(1) Vista pública «Necesito ayuda»; (2) Contacto con envío y consulta de estado; (3) gestión administrativa de esos mensajes en el panel existente. No se adelanta el Prompt 3 ni se hace auditoría general.

## 2. Qué se hizo
**Necesito ayuda** (`public/js/help.js`, nueva vista `#ayuda` en «Más»; no hay sexta opción principal)
- Muestra 123, 106, 141 y 155 leyendo `window.UNMUTE_HELP` (país predeterminado CO), solo con los campos que existen. La 106 aparece como «Bogotá»; WhatsApp solo en la 106 (enlace `wa.me` construido con el `e164` del directorio); enlaces `tel:`; fuente oficial y fecha de verificación; nota sobre Secretaría de Salud/alcaldía conservada. El bloque `other` (internacional) no se usa.
- Sin geolocalización, IP, red, almacenamiento local ni diario. Un recurso incompleto se omite sin ocultar los demás; si no hay directorio, mensaje de error sin números inventados.
- Accesos a Pausa y Acompañar (enlaces a las vistas existentes) con sus avisos de alcance. No se promete detección de crisis por IA.

**Contacto** (`public/js/contact.js`, vista `#contacto` en «Más»)
- Formulario: nombre y correo opcionales, categoría (`consulta`, `sugerencia`, `reporte_tecnico`, `otro` con etiquetas en español), mensaje (10–2000), consentimiento obligatorio y desmarcado por defecto. Aviso de qué se envía, finalidad, no-emergencias y enlace al diálogo de privacidad existente (se añadió una viñeta sobre Contacto a ese diálogo). Honeypot oculto y `elapsed_ms` ya existentes se siguen enviando.
- Un solo envío a la vez, sin reintentos automáticos, texto conservado ante error, errores asociados a cada campo (`aria-describedby`, `aria-invalid`), confirmación con foco y `role=status`.
- Éxito **solo** si el servidor responde 201 con `saved: true` y un `reference` UUID. Se muestra, se puede copiar y lleva al seguimiento. La referencia no se guarda en el navegador.
- Antispam: respuesta 201 con `saved: false`, sin UUID y con texto que **no** dice que se guardó; la interfaz lo trata como «no confirmado».

**Seguimiento**
- Ruta definitiva: `GET /api/contact/status?reference=UUID` (`netlify/functions/contact-status.mjs`; en `server.js` no hizo falta cambio: carga las funciones por su `config.path`; en Netlify cada función declara su ruta).
- Valida UUID → aplica el límite persistente (`limitarPorCliente`, scope `contacto-estado`, `CONTACT_STATUS_LIMIT_PER_HOUR`, por defecto 30/h) → consulta con la clave de servicio **solo** `select=status,created_at` → arma la respuesta campo por campo: `{status, label, received_at}`. Estado desconocido o fila inexistente → 404 genérico. Solo GET. Sin logs con UUID ni contenido.
- Traducción: `new`→Recibido, `read`→En revisión, `resolved`→Respondido, `archived`→Cerrado (sin renombrar estados ni tocar la base de datos).
- Interfaz: referencia vacía/inválida, consultando, resultado, no disponible (404), límite (429) y error temporal.

**Backend de contacto**
- `src/services/contact.service.mjs`: `crearMensaje` usa `Prefer: return=representation` (ya soportado por `sb.rest`) y devuelve `{id, created_at}`; si la inserción no devuelve fila con UUID → 502 `insert_not_confirmed` (nunca éxito falso). Nuevas `consultarEstado` y `ETIQUETA_PUBLICA`.
- `netlify/functions/contact.mjs`: devuelve `reference`/`received_at` solo con inserción confirmada. El consentimiento ya se validaba en servidor (`privacy_accepted !== true` → 400); no se cambió. **No se almacena** el consentimiento (no hay columna ni migración); la interfaz no afirma lo contrario.
- `src/config/environment.mjs` y `.env.example`: `CONTACT_STATUS_LIMIT_PER_HOUR`.

**Administración** (panel existente; sin otro login)
- Nueva sección «Mensajes de contacto» en `admin.html`/`admin.js`: lista, filtro por estado, apertura del mensaje completo (nombre, correo, tipo, fecha, referencia) y cambio de estado. Usa `GET /api/admin/messages` y `PATCH /api/admin/messages/:id` con valores internos; muestra etiquetas en español. Todo con `textContent` (el mensaje usa `white-space: pre-wrap`, nunca HTML). Sin borrado. Se limpia al cerrar sesión (mecanismo `gestores` existente). Las etiquetas del Resumen se alinearon con las nuevas.
- La autorización sigue en el servidor (`requerirAdmin`); no se tocó.

## 3. Archivos
Creados: `netlify/functions/contact-status.mjs`, `public/js/help.js`, `public/js/contact.js`, `tests/bloque5.test.mjs`, `CHANGELOG_BLOQUE_5.md`.
Modificados: `netlify/functions/contact.mjs`, `src/services/contact.service.mjs`, `src/config/environment.mjs`, `.env.example`, `public/index.html`, `public/js/app.js` (solo `VISTAS`/`EN_MAS`), `public/css/styles.css` (bloque añadido al final), `public/admin.html`, `public/js/admin.js`, `public/css/admin.css`, `scripts/check.mjs` (lista de funciones), `tests/api.test.mjs` (+9 pruebas), `tests/bloque4.test.mjs` (la navegación ahora incluye Ayuda y Contacto, que antes se prohibían), `tests/helpers/mock-services.mjs` (POST devuelve la fila solo con `return=representation`, como PostgREST), `package.json` (2.3.0), `CHANGELOG.md`, `README.md`.
Eliminados: ninguno. **Migraciones: ninguna** (el esquema, los permisos y RLS existentes bastan; el backend usa la clave de servicio para insertar y consultar por UUID).

## 4. Pruebas (todas con servicios SIMULADOS; ver §5)
| Comando | Resultado |
|---|---|
| `npm test` | 93 pruebas, 93 correctas, 0 fallos (74 previas + 19 nuevas/adaptadas en este bloque) |
| `npm run check` | 46 comprobaciones, 45 correctas, 0 errores, 1 advertencia previa (`npm run e2e` apunta a un archivo inexistente) |
| `npm run seed:check` | Semilla al día |
| `npm run e2e` | **No ejecutado**: `tests/e2e-smoke.mjs` no existe |

Cubren: acceso desde Más sin sexta opción; 4 recursos con cobertura/teléfono/WhatsApp/fuente/fecha (ejecutando `help.js` con un DOM mínimo simulado); recurso roto no oculta los demás; sin geolocalización/almacenamiento/diario; formulario y categorías; consentimiento desmarcado y exigido en servidor; UUID = id real de la fila; antispam sin UUID ni «guardado»; inserción sin confirmación → 502; seguimiento (válido, inválido, inexistente, métodos no permitidos, traducción de estados sin modificar la fila, límite 429 con contador en Supabase simulado y 503 si el límite no puede comprobarse); **prueba expresa de que el UUID no revela mensaje, nombre, correo ni categoría**; admin denegado sin sesión, con token falso y con cuenta sin rol; sin DELETE; renderizado como texto; diario intacto.

## 5. Limitaciones y honestidad
- **Mocks, no servicios reales.** Supabase simulado no valida PostgreSQL ni RLS ni el comportamiento real de `return=representation`; PostgREST lo soporta por documentación, pero no se probó contra un Supabase real. Tampoco se probó Netlify ni producción. OpenAI no se modificó ni se probó.
- **Sin prueba en navegador real.** No hay navegador ni `e2e-smoke.mjs` en el entorno. Responsive (320/390 px, tableta, escritorio), foco visible, teclado y contraste **no se verificaron visualmente**; solo hay comprobaciones estáticas (ids únicos, `aria-*` sin referencias rotas, `overflow-wrap`, grid de una columna en móvil, colores solo con variables del tema). Conviene revisarlo a mano antes de publicar.
- Comportamiento de `contact.js` (envío, copiado, seguimiento) revisado por lectura de código y pruebas estáticas; el backend sí se ejercitó por HTTP contra el servidor local.
- El correo opcional no implica respuesta por correo: se dice en la interfaz. No se definió plazo de respuesta ni periodo de conservación (no se inventaron).
- El UUID es aleatorio pero no es autenticación: quien lo tenga solo ve estado y fecha.
- «Respondido» refleja que el equipo marcó `resolved`; el canal de respuesta real queda fuera de este bloque.

## 6. Integración
1. Sustituir el proyecto por `UNMUTE_BLOQUE_5.zip` (no hay migraciones que ejecutar).
2. Opcional: `CONTACT_STATUS_LIMIT_PER_HOUR` en Netlify (alcance Functions). La función `consume_rate_limit` ya existente es la que cuenta.
3. Desplegar y revisar manualmente `#ayuda`, `#contacto` y `/admin` → «Mensajes de contacto» en móvil y escritorio.

## 7. Pendientes / dudas documentadas
- Prueba contra Supabase real del flujo envío → referencia → estado → cambio de estado en admin.
- Revisión visual y de accesibilidad en dispositivos reales; crear `tests/e2e-smoke.mjs` si se quiere automatizar.
- Decidir (propietario) si se añadirá almacenamiento del consentimiento y una política de conservación de mensajes (requieren migración; fuera de este bloque).
- Los avisos de Resumen de admin cambiaron de «Nuevos/Leídos/Resueltos/Archivados» a las etiquetas públicas.
