/* ==========================================================
   UNMUTE · Vista «Necesito ayuda»
   Muestra SOLO lo que define public/js/help-directory.js (país predeterminado: Colombia).
   · Sin geolocalización, sin IP, sin peticiones de red y sin escribir en el almacenamiento local ni en el diario.
   · Cada recurso muestra únicamente sus campos disponibles; no se completa ni se inventa nada.
   · Un recurso incompleto se omite sin ocultar los demás.
   · Todo texto se escribe con textContent (sin HTML).
   ========================================================== */
(function () {
  'use strict';
  if (!document.getElementById('v-ayuda')) return;
  var $ = function (id) { return document.getElementById(id); };

  function el(tag, clase, texto, attrs) {
    var e = document.createElement(tag);
    if (clase) e.className = clase;
    if (texto != null) e.textContent = texto;
    if (attrs) for (var k in attrs) e.setAttribute(k, attrs[k]);
    return e;
  }
  var texto = function (v) { return typeof v === 'string' && v.trim() ? v.trim() : ''; };
  var soloDigitos = function (v) { return typeof v === 'string' && /^\d{2,15}$/.test(v) ? v : ''; };
  var urlHttps = function (v) { return typeof v === 'string' && /^https:\/\/[^\s]+$/.test(v) ? v : ''; };
  function fecha(iso) {
    if (typeof iso !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(iso)) return '';
    var d = new Date(iso + 'T12:00:00');
    return isNaN(d) ? '' : new Intl.DateTimeFormat('es', { day: 'numeric', month: 'long', year: 'numeric' }).format(d);
  }
  function dato(dl, titulo, valor) {
    var g = el('div'); g.appendChild(el('dt', '', titulo)); g.appendChild(el('dd', '', valor)); dl.appendChild(g);
  }

  function tarjeta(r) {
    var nombre = texto(r.name), tel = soloDigitos(r.phone);
    if (!nombre || !tel) return null; // sin nombre o sin número válido no se muestra
    var c = el('article', 'panel tarjeta ayuda-card');
    c.appendChild(el('h3', '', nombre));
    var scope = texto(r.scope);
    if (scope) c.appendChild(el('p', '', null)).appendChild(el('span', 'etq', 'Cobertura: ' + scope));
    var desc = texto(r.description);
    if (desc) c.appendChild(el('p', '', desc));
    var dl = el('dl', 'ayuda-datos');
    var horas = texto(r.hours);
    dato(dl, 'Horario', horas || 'La fuente oficial no confirma el horario.');
    dato(dl, 'Teléfono', tel);
    var wa = r.whatsapp && typeof r.whatsapp === 'object' ? r.whatsapp : null;
    var waNum = wa ? soloDigitos(wa.e164) : '', waTxt = wa ? texto(wa.display) : '';
    if (waNum && waTxt) dato(dl, 'WhatsApp', waTxt);
    c.appendChild(dl);
    var acc = el('p', 'acciones');
    acc.appendChild(el('a', 'btn', 'Llamar al ' + tel, { href: 'tel:' + tel, 'aria-label': 'Llamar al ' + tel + ': ' + nombre }));
    if (waNum && waTxt) acc.appendChild(el('a', 'btn-sec', 'Escribir por WhatsApp', { href: 'https://wa.me/' + waNum, target: '_blank', rel: 'noopener noreferrer', 'aria-label': 'Escribir por WhatsApp al ' + waTxt + ' (se abre en otra pestaña)' }));
    c.appendChild(acc);
    var f = el('p', 'ayuda-fuente');
    var fuente = r.source && typeof r.source === 'object' ? r.source : null, fn = fuente ? texto(fuente.name) : '', fu = fuente ? urlHttps(fuente.url) : '';
    if (fn && fu) { f.appendChild(document.createTextNode('Fuente oficial: ')); f.appendChild(el('a', '', fn, { href: fu, target: '_blank', rel: 'noopener noreferrer' })); }
    else if (fn) f.appendChild(document.createTextNode('Fuente oficial: ' + fn));
    var v = fecha(r.verified);
    if (v) f.appendChild(document.createTextNode((f.childNodes.length ? ' · ' : '') + 'Verificado el ' + v));
    if (f.childNodes.length) c.appendChild(f);
    return c;
  }

  function pintar() {
    var lista = $('ayudaLista'), estado = $('ayudaEstado'), nota = $('ayudaNota');
    lista.textContent = ''; nota.textContent = ''; estado.classList.remove('err'); estado.textContent = '';
    var dir = window.UNMUTE_HELP, paises = dir && Array.isArray(dir.countries) ? dir.countries : [];
    var pais = paises.filter(function (p) { return p && p.code === dir.default; })[0];
    var recursos = pais && Array.isArray(pais.resources) ? pais.resources : [];
    var n = 0;
    recursos.forEach(function (r) { var t = r && tarjeta(r); if (t) { lista.appendChild(t); n++; } });
    if (!n) {
      estado.classList.add('err');
      estado.textContent = dir ? 'No hay líneas de ayuda disponibles para mostrar en este momento.' : 'No pudimos cargar el directorio de líneas de ayuda.';
      estado.textContent += ' Si hay peligro inmediato, llama a los servicios de emergencia de tu zona o busca a alguien de confianza.';
      return;
    }
    if (n < recursos.length) estado.textContent = 'Algunas líneas no se pudieron mostrar. Las demás siguen disponibles.';
    var nt = pais && texto(pais.note);
    if (nt) nota.textContent = nt;
  }

  document.addEventListener('unmute:vista', function (e) { if (e.detail === 'ayuda') pintar(); });
  if (document.body.dataset.vista === 'ayuda') pintar();
})();
