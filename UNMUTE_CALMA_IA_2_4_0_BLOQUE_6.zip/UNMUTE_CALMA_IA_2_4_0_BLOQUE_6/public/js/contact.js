/* ==========================================================
   UNMUTE · Vista «Contacto»: envío y seguimiento
   · POST /api/contact  → confirmación con la referencia (UUID real) SOLO si el servidor la devuelve.
   · GET  /api/contact/status?reference=…  → estado público y fecha. Nada más.
   · No usa localStorage ni sessionStorage (la referencia no se guarda en el navegador) y no lee el diario.
   · Un solo envío a la vez; sin reintentos automáticos; ante un error se conserva el texto escrito.
   · Todo texto del servidor se escribe con textContent (sin HTML).
   ========================================================== */
(function () {
  'use strict';
  if (!document.getElementById('v-contacto')) return;
  var $ = function (id) { return document.getElementById(id); };
  var UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
  var EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  var CATEGORIAS = ['consulta', 'sugerencia', 'reporte_tecnico', 'otro'];
  var MIN = 10, MAX = 2000;
  var CAMPOS = { name: ['cNombre', 'cNombreErr'], email: ['cCorreo', 'cCorreoErr'], category: ['cCategoria', 'cCategoriaErr'], message: ['cMensaje', 'cMensajeErr'], privacy_accepted: ['cPriv', 'cPrivErr'] };
  var t0 = Date.now(), enviando = false, consultando = false;

  function pedir(ruta, opciones) {
    opciones = opciones || {};
    var ctl = new AbortController(), timer = setTimeout(function () { ctl.abort(); }, 15000);
    return fetch(ruta, { method: opciones.metodo || 'GET', headers: opciones.cuerpo ? { 'Content-Type': 'application/json' } : {}, body: opciones.cuerpo ? JSON.stringify(opciones.cuerpo) : undefined, cache: 'no-store', credentials: 'omit', signal: ctl.signal })
      .then(function (res) { return res.text().then(function (t) { var d = {}; try { d = JSON.parse(t) || {}; } catch (_e) { /* sin JSON */ } return { status: res.status, datos: d }; }); })
      .catch(function () { return { status: 0, datos: {} }; })
      .then(function (r) { clearTimeout(timer); return r; });
  }
  function ponerError(id, errId, msg) {
    var campo = $(id), err = $(errId);
    err.textContent = msg; err.hidden = !msg;
    if (msg) campo.setAttribute('aria-invalid', 'true'); else campo.removeAttribute('aria-invalid');
  }
  function limpiarErrores() { Object.keys(CAMPOS).forEach(function (k) { ponerError(CAMPOS[k][0], CAMPOS[k][1], ''); }); $('contError').hidden = true; $('contError').textContent = ''; }
  function fechaLarga(iso) { var d = new Date(iso); return isNaN(d) ? '' : new Intl.DateTimeFormat('es', { day: 'numeric', month: 'long', year: 'numeric' }).format(d); }
  function ocupado(si) { enviando = si; var b = $('contEnviar'); b.disabled = si; b.textContent = si ? 'Enviando…' : 'Enviar mensaje'; $('contForm').setAttribute('aria-busy', String(si)); }

  /* ---------- Envío ---------- */
  function validar() {
    var f = {}, nombre = $('cNombre').value.trim(), correo = $('cCorreo').value.trim(), msg = $('cMensaje').value.trim();
    if (nombre.length > 80) f.name = 'Usa como máximo 80 caracteres.';
    if (correo && (correo.length > 120 || !EMAIL_RE.test(correo))) f.email = 'Escribe un correo válido o déjalo en blanco.';
    if (CATEGORIAS.indexOf($('cCategoria').value) < 0) f.category = 'Elige un tipo de mensaje.';
    if (msg.length < MIN) f.message = 'Cuéntanos un poco más (mínimo ' + MIN + ' caracteres).';
    else if (msg.length > MAX) f.message = 'El mensaje puede tener hasta ' + MAX + ' caracteres.';
    if (!$('cPriv').checked) f.privacy_accepted = 'Debes aceptar el envío de estos datos para poder enviar el mensaje.';
    return f;
  }
  function mostrarCampos(f) {
    var primero = null;
    Object.keys(CAMPOS).forEach(function (k) { if (f[k]) { ponerError(CAMPOS[k][0], CAMPOS[k][1], f[k]); if (!primero) primero = CAMPOS[k][0]; } });
    if (primero) $(primero).focus();
    return !!primero;
  }
  function falla(msg) { var e = $('contError'); e.textContent = msg; e.hidden = false; }

  $('contForm').addEventListener('submit', function (ev) {
    ev.preventDefault();
    if (enviando) return;
    limpiarErrores();
    var f = validar();
    if (mostrarCampos(f)) return;
    ocupado(true);
    pedir('/api/contact', { metodo: 'POST', cuerpo: {
      name: $('cNombre').value.trim() || null, email: $('cCorreo').value.trim() || null, category: $('cCategoria').value,
      message: $('cMensaje').value.trim(), privacy_accepted: $('cPriv').checked, website: $('cWeb').value, elapsed_ms: Date.now() - t0
    } }).then(function (r) {
      ocupado(false);
      var d = r.datos;
      if (r.status === 201 && d.saved === true && typeof d.reference === 'string' && UUID_RE.test(d.reference)) { exito(d.reference); return; }
      if (r.status === 201) { falla('No pudimos confirmar el envío. Espera unos segundos e inténtalo de nuevo; tu texto sigue aquí.'); return; }
      if (r.status === 400 && d.fields && typeof d.fields === 'object') { if (mostrarCampos(d.fields)) return; }
      if (r.status === 0) { falla('No hay conexión con el servidor. Tu mensaje no se envió; el texto sigue aquí. Inténtalo de nuevo cuando tengas conexión.'); return; }
      if ((r.status === 400 || r.status === 413 || r.status === 429 || r.status === 503) && typeof d.error === 'string' && d.error) { falla(d.error + ' Tu mensaje no se envió; el texto sigue aquí.'); return; }
      falla('No pudimos enviar tu mensaje por un problema temporal. El texto sigue aquí; inténtalo de nuevo más tarde.');
    });
  });

  function exito(ref) {
    $('contRef').textContent = ref;
    $('contForm').hidden = true; $('contOk').hidden = false; $('contCopiado').textContent = '';
    ['cNombre', 'cCorreo', 'cCategoria', 'cMensaje', 'cWeb'].forEach(function (id) { $(id).value = ''; });
    $('cPriv').checked = false;
    $('contOk').focus();
  }
  $('contOtro').addEventListener('click', function () { $('contOk').hidden = true; $('contRef').textContent = ''; $('contForm').hidden = false; t0 = Date.now(); $('cNombre').focus(); });
  $('contCopiar').addEventListener('click', function () {
    var ref = $('contRef').textContent, aviso = $('contCopiado');
    var manual = function () {
      var rango = document.createRange(); rango.selectNodeContents($('contRef'));
      var sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(rango);
      aviso.textContent = 'No pude copiarla automáticamente. La dejé seleccionada para que la copies.';
    };
    if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(ref).then(function () { aviso.textContent = 'Referencia copiada.'; }, manual);
    else manual();
  });
  $('contVerEstado').addEventListener('click', function () { $('segRef').value = $('contRef').textContent; consultar(); $('contSeg').scrollIntoView({ block: 'start' }); });

  /* ---------- Seguimiento ---------- */
  function resultado(titulo, lineas, error) {
    var c = $('segRes'); c.textContent = '';
    var p = document.createElement('p'); p.className = error ? 'estado err' : 'seg-estado'; p.textContent = titulo; c.appendChild(p);
    (lineas || []).forEach(function (l) { var q = document.createElement('p'); q.textContent = l; if (!error) q.className = 'suave'; c.appendChild(q); });
  }
  function consultar() {
    if (consultando) return;
    var ref = $('segRef').value.trim();
    ponerError('segRef', 'segErr', ''); $('segRes').textContent = '';
    if (!ref) { ponerError('segRef', 'segErr', 'Escribe la referencia que recibiste al enviar tu mensaje.'); $('segRef').focus(); return; }
    if (!UUID_RE.test(ref)) { ponerError('segRef', 'segErr', 'La referencia no tiene el formato correcto. Cópiala completa, tal como te la mostramos.'); $('segRef').focus(); return; }
    consultando = true; $('segBtn').disabled = true; resultado('Consultando…', [], false);
    pedir('/api/contact/status?reference=' + encodeURIComponent(ref)).then(function (r) {
      consultando = false; $('segBtn').disabled = false;
      var d = r.datos;
      if (r.status === 200 && typeof d.label === 'string' && d.label) {
        var cuando = typeof d.received_at === 'string' ? fechaLarga(d.received_at) : '';
        resultado('Estado: ' + d.label, [cuando ? 'Recibido el ' + cuando + '.' : '', 'Este seguimiento solo muestra el estado y la fecha.'].filter(Boolean), false);
      } else if (r.status === 404) resultado('No encontramos esa referencia.', ['Revisa que esté completa. Si el problema continúa, escribe de nuevo al equipo.'], true);
      else if (r.status === 429) resultado('Hiciste varias consultas seguidas.', ['Inténtalo de nuevo más tarde.'], true);
      else if (r.status === 400) resultado('La referencia no tiene el formato correcto.', ['Cópiala completa, tal como te la mostramos.'], true);
      else resultado('No pudimos consultar el estado en este momento.', ['Es un problema temporal. Inténtalo de nuevo más tarde.'], true);
    });
  }
  $('segForm').addEventListener('submit', function (ev) { ev.preventDefault(); consultar(); });

})();
