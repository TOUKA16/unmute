/* ==========================================================
   UNMUTE · Mensajes de contacto
   Inserción: clave de servicio (el público NO tiene permiso directo sobre la tabla).
   Lectura y gestión: solo con el token de una persona administradora + RLS.
   Se guarda solo lo necesario: nombre y correo opcionales, tipo y mensaje. Sin IP.
   ========================================================== */
import * as sb from '../lib/supabase.mjs';
import { badGateway, notFound, unavailable } from '../lib/errors.mjs';
import { isUuid } from '../lib/validation.mjs';

/** Etiqueta pública de cada estado interno (los valores internos no cambian). */
export const ETIQUETA_PUBLICA = { new: 'Recibido', read: 'En revisión', resolved: 'Respondido', archived: 'Cerrado' };

/** Guarda el mensaje y devuelve solo {id, created_at} de la fila realmente creada. */
export async function crearMensaje(valor) {
  if (!sb.isConfigured({ service: true })) {
    throw unavailable('El formulario todavía no está conectado a la base de datos.', 'database_not_configured');
  }
  const filas = await sb.conDb(() => sb.rest({ table: 'contact_messages', role: 'service', method: 'POST', body: valor, prefer: 'return=representation' }));
  const fila = Array.isArray(filas) ? filas[0] : null;
  // Sin confirmación real de la inserción no se inventa ninguna referencia.
  if (!fila || !isUuid(fila.id)) throw badGateway('No pudimos confirmar que el mensaje se guardara. Inténtalo de nuevo más tarde.', 'insert_not_confirmed');
  return { id: fila.id, created_at: fila.created_at };
}

/** Consulta pública: SOLO estado y fecha de recepción. Se arma campo por campo; nunca se devuelve la fila. */
export async function consultarEstado(id) {
  if (!sb.isConfigured({ service: true })) {
    throw unavailable('La consulta de seguimiento todavía no está disponible.', 'database_not_configured');
  }
  const filas = await sb.conDb(() => sb.rest({ table: 'contact_messages', role: 'service', query: { select: 'status,created_at', id: `eq.${id}`, limit: 1 } }));
  const fila = Array.isArray(filas) ? filas[0] : null;
  const etiqueta = fila ? ETIQUETA_PUBLICA[fila.status] : null;
  if (!etiqueta) throw notFound('No encontramos una referencia disponible con ese código.', 'reference_not_available');
  return { status: fila.status, label: etiqueta, received_at: fila.created_at };
}

export async function listarMensajes(token, { status, limit = 200 } = {}) {
  const query = { select: 'id,name,email,category,message,status,created_at', order: 'created_at.desc', limit };
  if (status) query.status = `eq.${status}`;
  return sb.conDb(() => sb.rest({ table: 'contact_messages', token, query }));
}

export async function actualizarEstado(token, id, status) {
  const filas = await sb.conDb(() => sb.rest({ table: 'contact_messages', token, method: 'PATCH', query: { id: `eq.${id}` }, body: { status }, prefer: 'return=representation' }));
  if (!filas.length) throw notFound('No se encontró ese mensaje.');
  return filas[0];
}

export async function contarPorEstado(token) {
  const filas = await sb.conDb(() => sb.rest({ table: 'contact_messages', token, query: { select: 'status', limit: 1000 } }));
  const r = { total: filas.length, new: 0, read: 0, resolved: 0, archived: 0 };
  for (const f of filas) r[f.status] = (r[f.status] || 0) + 1;
  return r;
}
