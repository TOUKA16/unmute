# CHANGELOG · BLOQUE 6 — Administración + Privacidad + Accesibilidad
Versión: **2.4.0** · Base: `UNMUTE_BLOQUE_5.zip` (2.3.0) · Entrega: `UNMUTE_BLOQUE_6.zip`

## 1. Alcance
Revisión del panel administrativo existente, apartado Privacidad y apartado independiente Accesibilidad en Ajustes. No se reabrieron los bloques 1–5.

## 2. Qué se hizo
**Ajustes** (`public/index.html`, `public/css/styles.css`)
- Orden nuevo: Tema visual · **Accesibilidad** (tamaño del texto, reducir animaciones, desactivar efectos decorativos) · **Concentración y escritura** («Abrir el editor en modo sin distracciones») · Privacidad · Tus datos.
- Se conservaron los `id`/`name` de los controles, las claves de almacenamiento (`unmute_v2_prefs`), `PREF0` y la lógica de `app.js` (**no se modificó `app.js`**). Los valores guardados siguen funcionando.
- Cada apartado es una `<section>` con nombre accesible; casillas con área táctil ≥ 44 px.

**Privacidad** (mismo archivo)
- Bloques breves: dispositivo (diario y preferencias), Acompañar con IA, Contacto, copias y eliminación, riesgos del dispositivo. Texto verificado contra el código (`app.js` no hace peticiones de red; exportación sin borrador; importación solo de entradas; eliminar solo borra datos locales; el consentimiento de Contacto se exige en servidor pero no se guarda).
- El diálogo «Cómo se guardan tus datos» se conserva (un único diálogo), reorganizado en los mismos cuatro bloques y sin duplicar el apartado. No se usan «confidencialidad absoluta», «borrado de todos los servidores» ni se promete retención cero.
- Cambio de texto respecto a antes: «Tus datos» ya no repite el detalle de la copia (queda en Privacidad).

**Administración** (`admin.html`, `admin.js`, `admin.css`) — misma arquitectura, cinco secciones, sin endpoints nuevos
- **Defecto corregido:** si la sesión terminaba (cierre, vencimiento o rechazo 401/403) mientras se guardaba o cargaba algo, los botones Guardar/Publicar/Actualizar podían quedar deshabilitados con `aria-busy` para la siguiente sesión. Ahora `reiniciar` los restablece.
- **Defecto corregido:** al salir permanecían en el DOM (oculto) el resumen, el correo/datos de sesión, las sugerencias de categoría y el texto del diálogo de confirmación. Ahora se vacían y el diálogo se cierra.
- Un solo guardado/publicación/eliminación a la vez: se bloquean botones de lista, «Nuevo» y formulario mientras hay una acción en curso; el resumen no admite cargas simultáneas.
- Estados unificados: «Cargando…», «Guardando…», éxito, error y vacío en una región `role="status"` por sección; `aria-busy` en listas; el foco pasa al resultado tras publicar/despublicar/eliminar/guardar (el botón usado desaparece) y vuelve al botón de origen al cancelar.
- Navegación: al elegir sección el foco pasa a su encabezado; paneles como `<section>` con nombre (antes `div` con `aria-labelledby` sin rol); búsquedas con nombre accesible.
- Responsive: acciones a ancho completo en móvil, lista en columnas desde 48rem, filtro de mensajes sin hueco; estilos de botón deshabilitado.
- Común: los mensajes de error añaden «Error: » como texto (no solo color) en `.estado.err` y `.adm-err`.

## 3. Archivos
Modificados: `public/index.html`, `public/css/styles.css` (bloque al final), `public/admin.html`, `public/js/admin.js`, `public/css/admin.css` (bloque al final), `package.json` (2.4.0), `CHANGELOG.md`.
Creados: `tests/bloque6.test.mjs`, `CHANGELOG_BLOQUE_6.md`. Eliminados: ninguno.

## 4. Confirmaciones
- Autenticación, permisos, RLS, base de datos, backend: **no modificados**. Migraciones: **ninguna**. Endpoints/login/roles nuevos: **ninguno** (lo comprueba una prueba).
- **No** se implementó retención, almacenamiento de consentimiento, borrado remoto ni borrado de mensajes. `ai-chat.js`, `contact.js` y `app.js` sin cambios.

## 5. Pruebas (todas con servicios SIMULADOS o estáticas)
| Comando | Resultado |
|---|---|
| `npm test` | 108 pruebas, 108 correctas (93 previas + 15 nuevas) |
| `npm run check` | 46 comprobaciones, 45 correctas, 0 errores, 1 advertencia previa (`npm run e2e` apunta a un archivo inexistente) |
| `npm run seed:check` | Semilla al día |
| `npm run e2e` | **No ejecutado**: `tests/e2e-smoke.mjs` no existe |
Las pruebas nuevas son **estáticas** (leen los archivos reales): estructura de Ajustes, claves de preferencias, textos de Privacidad, ids/referencias ARIA, panel (secciones, limpieza, bloqueo), ausencia de `innerHTML`/claves privadas/endpoints nuevos. Nada se probó contra Supabase, OpenAI o Netlify reales.

## 6. Accesibilidad: verificado y pendiente
Verificado (por lectura y pruebas estáticas): ids únicos y referencias ARIA válidas en `index.html` y `admin.html`; etiquetas asociadas; foco visible global (`:focus-visible`); `prefers-reduced-motion` y preferencias existentes; áreas táctiles ≥ 44 px en los controles tocados; error no solo por color; sin `innerHTML` en el panel.
**Pendiente / no verificable aquí:** no hay navegador ni lector de pantalla, así que **no** se comprobó visualmente el foco, el responsive (320/390 px, tableta, escritorio), el contraste real en ambos temas, el escalado de texto ni el comportamiento con NVDA/VoiceOver/TalkBack. No se afirma conformidad WCAG ni auditoría certificada. Conviene recorrer a mano `/admin`, Ajustes y la app con teclado en móvil y escritorio antes de publicar.
Observación: el prefijo «Error: » se aplica también a los `.estado.err` de la app pública (p. ej. Contacto); revísalo visualmente.

## 7. Integración
1. Sustituir el proyecto por `UNMUTE_BLOQUE_6.zip`. No hay migraciones ni variables nuevas.
2. Desplegar y revisar manualmente Ajustes (las tres secciones, cambio de tema/tamaño/animaciones/modo sin distracciones) y `/admin` (cerrar sesión durante un guardado, filtros, foco).
