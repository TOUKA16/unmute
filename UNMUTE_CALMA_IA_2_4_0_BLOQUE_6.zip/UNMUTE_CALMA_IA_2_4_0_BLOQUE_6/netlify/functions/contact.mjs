/* POST /api/contact · Formulario de contacto (consultas, sugerencias y reportes técnicos).
   No es un canal de crisis. Validación (incluye el consentimiento de privacidad) + trampa antispam + límite de uso + guardado en Supabase.
   Devuelve la referencia (UUID real de la fila) solo cuando la inserción se confirmó. */
import { createHandler, json, readJson } from '../../src/lib/http.mjs';
import { getConfig } from '../../src/config/environment.mjs';
import { parseContactPayload } from '../../src/lib/validation.mjs';
import { limitarPorCliente } from '../../src/lib/rate-limit.mjs';
import { crearMensaje } from '../../src/services/contact.service.mjs';

const CONFIRMACION = { ok: true, message: 'Recibimos tu mensaje. Gracias por escribir a UNMUTE.' };
// Antispam: se mantiene el 201 (los bots no reciben pistas), pero NO se guarda nada, NO hay referencia
// y el texto no afirma que el mensaje quedó guardado. La interfaz solo confirma cuando llega «reference».
const SIN_GUARDAR = { ok: true, saved: false, message: 'No pudimos confirmar el envío. Espera unos segundos e inténtalo de nuevo.' };

export default createHandler(async ({ req, ip }) => {
  const resultado = parseContactPayload(await readJson(req, 8 * 1024));
  if (resultado.spam) return json(SIN_GUARDAR, 201);
  await limitarPorCliente({ scope: 'contacto', ip, limite: getConfig().limits.contactPerHour, ventanaSeg: 3600, mensaje: 'Enviaste varios mensajes seguidos. Inténtalo de nuevo más tarde.' });
  const creado = await crearMensaje(resultado.value);
  return json({ ...CONFIRMACION, saved: true, reference: creado.id, received_at: creado.created_at }, 201);
}, { methods: ['POST'] });

export const config = { path: '/api/contact' };
