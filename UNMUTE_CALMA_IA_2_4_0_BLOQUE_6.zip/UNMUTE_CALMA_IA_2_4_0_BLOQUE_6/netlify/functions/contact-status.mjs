/* GET /api/contact/status?reference=UUID · Seguimiento público de un mensaje de contacto (solo lectura).
   El UUID NO es una credencial: solo permite ver el estado público y la fecha de recepción.
   Nunca devuelve nombre, correo, categoría ni el mensaje. Límite de uso persistente por cliente.
   No se registra la referencia ni el contenido (el registro técnico solo guarda método, ruta y código). */
import { createHandler, json } from '../../src/lib/http.mjs';
import { badRequest } from '../../src/lib/errors.mjs';
import { getConfig } from '../../src/config/environment.mjs';
import { isUuid } from '../../src/lib/validation.mjs';
import { limitarPorCliente } from '../../src/lib/rate-limit.mjs';
import { consultarEstado } from '../../src/services/contact.service.mjs';

export default createHandler(async ({ url, ip }) => {
  const referencia = (url.searchParams.get('reference') || '').trim();
  if (!isUuid(referencia)) throw badRequest('La referencia no tiene un formato válido.', 'invalid_reference');
  await limitarPorCliente({ scope: 'contacto-estado', ip, limite: getConfig().limits.contactStatusPerHour, ventanaSeg: 3600, mensaje: 'Hiciste varias consultas seguidas. Inténtalo de nuevo más tarde.' });
  return json(await consultarEstado(referencia.toLowerCase()));
}, { methods: ['GET'] });

export const config = { path: '/api/contact/status' };
