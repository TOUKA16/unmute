/* Bloque 6 · Administración + Privacidad + Accesibilidad.
   Comprobaciones ESTÁTICAS sobre los archivos reales (no hay navegador en el entorno de pruebas):
   no sustituyen una revisión visual ni con lector de pantalla. Ver CHANGELOG_BLOQUE_6.md. */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';

const leer = (rel) => readFile(new URL(`../${rel}`, import.meta.url), 'utf8');
const html = await leer('public/index.html');
const admHtml = await leer('public/admin.html');
const app = await leer('public/js/app.js');
const adm = await leer('public/js/admin.js');
const admCss = await leer('public/css/admin.css');

const ids = (s) => [...s.matchAll(/\sid="([^"]+)"/g)].map((m) => m[1]);
const bloque = (s, id) => { const i = s.indexOf(`aria-labelledby="${id}"`); assert.ok(i > 0, `falta el apartado ${id}`); return s.slice(i, s.indexOf('</section>', i)); };

test('Ajustes: Accesibilidad es un apartado independiente con sus tres controles', () => {
  const acc = bloque(html, 'h-acc');
  assert.match(acc, /<h2 id="h-acc">Accesibilidad<\/h2>/);
  for (const c of ['name="texto" value="pequeno"', 'name="texto" value="normal"', 'name="texto" value="grande"', 'id="pReducir"', 'id="pEfectos"']) assert.ok(acc.includes(c), c);
  assert.ok(!acc.includes('id="pEnfoque"'), 'el modo sin distracciones no es accesibilidad');
});

test('Ajustes: «modo sin distracciones» está en Concentración y escritura; tema y privacidad siguen separados', () => {
  assert.ok(bloque(html, 'h-esc').includes('id="pEnfoque"'));
  assert.match(html, /<h2>Tema visual<\/h2>/);
  assert.ok(html.includes('name="tema" value="claro"') && html.includes('name="tema" value="oscuro"') && html.includes('name="tema" value="sistema"'));
  assert.match(bloque(html, 'h-priv'), /<h2 id="h-priv">Privacidad<\/h2>/);
});

test('Preferencias: claves de almacenamiento, valores por defecto y vínculos con los controles no cambian', () => {
  assert.match(app, /pref: 'unmute_v2_prefs'/);
  assert.match(app, /const PREF0 = \{tema: 'sistema', reducir: false, sinefectos: false, texto: 'normal', enfoque: false, recientes: \[\]\};/);
  assert.match(app, /\[\['#pReducir', 'reducir'\], \['#pEfectos', 'sinefectos'\], \['#pEnfoque', 'enfoque'\]\]/);
  assert.match(app, /input\[name=tema\],input\[name=texto\]/);
  assert.match(app, /matchMedia\('\(prefers-color-scheme:dark\)'\)/);
});

test('Privacidad: describe los flujos reales con las expresiones aprobadas', () => {
  const p = bloque(html, 'h-priv').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
  for (const frase of [
    'almacenamiento local de este navegador y dispositivo', 'no se envía automáticamente a Supabase ni a OpenAI', 'no está cifrado', 'no hay sincronización ni recuperación remota',
    'Solo se envían mensajes si marcas el consentimiento', 'memoria de la página', 'no equivale a una garantía de retención cero',
    'se guardan en Supabase y pueden ser consultados por el equipo autorizado', 'no guarda un registro aparte',
    'no incluye el borrador en curso', 'solo se restauran las entradas', 'no elimina mensajes de Contacto guardados en Supabase',
    'mismo navegador o dispositivo', 'ventana privada'
  ]) assert.ok(p.includes(frase), `falta: ${frase}`);
});

test('Privacidad: no aparecen promesas no verificables ni funciones inexistentes (apartado ni diálogo)', () => {
  const txt = (bloque(html, 'h-priv') + html.slice(html.indexOf('<dialog id="dlgPriv"'), html.indexOf('</dialog>', html.indexOf('<dialog id="dlgPriv"')))).toLowerCase();
  for (const mala of ['confidencialidad absoluta', 'retención cero por', 'todos los servidores', 'anónim', 'cifrado de extremo', 'se eliminan automáticamente', 'wcag'])
    assert.ok(!txt.includes(mala) || mala === 'retención cero por', `no debe decir: ${mala}`);
  assert.ok(!/(?<!no )(?<!garantía de )retención cero/.test(txt.replace(/no equivale a una garantía de retención cero/g, '').replace(/no se promete retención cero/g, '')), 'retención cero solo puede aparecer negada');
  assert.ok(!/borrado remoto|plazo de conservación|política de retención/.test(txt));
});

test('Privacidad: el diálogo se conserva, es el único y lo abren los botones data-priv', () => {
  assert.equal((html.match(/id="dlgPriv"/g) || []).length, 1);
  assert.ok(html.includes('data-priv') && html.includes('id="privCerrar"'));
  assert.match(app, /\$\('#dlgPriv'\)\.showModal\(\)/);
});

test('Exportar, importar y eliminar conservan su funcionamiento (controles y lógica intactos)', () => {
  for (const id of ['bExport', 'bImport', 'fImport', 'bBorrador', 'bTodo']) assert.ok(html.includes(`id="${id}"`), id);
  assert.match(app, /entradas, prefs: \{tema: prefs\.tema, reducir: prefs\.reducir, sinefectos: prefs\.sinefectos, texto: prefs\.texto, enfoque: prefs\.enfoque\}/);
  assert.match(app, /Las preferencias del archivo no se importan/);
  assert.match(app, /tipear: 'ELIMINAR'/);
});

test('Diario local: app.js no envía entradas a ningún servicio', () => {
  assert.ok(!/fetch\(/.test(app), 'app.js no hace peticiones de red');
});

test('HTML: ids únicos y referencias aria/for resueltas en la app y en el panel', () => {
  for (const [nombre, s] of [['index', html], ['admin', admHtml]]) {
    const lista = ids(s), set = new Set(lista);
    assert.equal(set.size, lista.length, `${nombre}: ids duplicados`);
    for (const m of s.matchAll(/aria-(?:labelledby|describedby|controls)="([^"]+)"/g)) for (const r of m[1].split(/\s+/)) assert.ok(set.has(r), `${nombre}: referencia rota ${r}`);
    for (const m of s.matchAll(/\sfor="([^"]+)"/g)) assert.ok(set.has(m[1]), `${nombre}: for roto ${m[1]}`);
  }
});

test('Panel: conserva las cinco secciones y cada panel es una región con nombre', () => {
  for (const n of ['resumen', 'datos', 'noticias', 'mensajes', 'sesion']) {
    assert.ok(admHtml.includes(`data-sec="${n}"`), n);
    assert.match(admHtml, new RegExp(`<section id="s-${n}" class="panel" aria-labelledby="t-${n}"`));
    assert.match(admHtml, new RegExp(`<h2 id="t-${n}" tabindex="-1">`));
  }
  assert.equal((admHtml.match(/data-sec="/g) || []).length, 5);
});

test('Panel: al salir se limpia el resumen, la sesión y el diálogo; no quedan botones bloqueados', () => {
  assert.match(adm, /function limpiarPantallaAdmin\(\)/);
  for (const id of ['statsRecursos', 'statsMensajes', 'admUsuario', 'sesCuenta', 'sesVerif', 'sesVence', 'dlgConf']) assert.ok(adm.includes(id), id);
  assert.match(adm, /limpiarPantallaAdmin\(\);\s*\}/);
  assert.match(adm, /ocupadoForm\(false\); g\('Refrescar'\)\.disabled = false/);
});

test('Panel: las acciones simultáneas se bloquean y el resultado recibe el foco', () => {
  assert.match(adm, /function bloquear\(si\)/);
  assert.equal((adm.match(/bloquear\(true\)/g) || []).length >= 2, true, 'cambiar estado y eliminar bloquean');
  assert.match(adm, /function enMensaje\(\)/);
  assert.match(adm, /if \(estado\.cargandoStats\) return/);
  for (const id of ['statsEstado', 'dcMsg', 'ntMsg', 'msgMsg']) assert.match(admHtml, new RegExp(`id="${id}" role="status"[^>]*tabindex="-1"`));
});

test('Panel: sin innerHTML, sin claves privilegiadas y sin borrado de mensajes', () => {
  const codigo = adm.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');
  assert.ok(!/innerHTML|insertAdjacentHTML|document\.write/.test(codigo));
  assert.ok(!/service_role|SERVICE_ROLE|OPENAI/i.test(adm + admHtml));
  assert.ok(!/metodo:\s*'DELETE'[^}]*messages|messages[^;\n]*DELETE/.test(adm));
  assert.ok(!/localStorage/.test(adm), 'la sesión sigue solo en sessionStorage');
});

test('Panel: no se añadieron endpoints, login ni migraciones', async () => {
  const { readdir } = await import('node:fs/promises');
  const fn = (await readdir(new URL('../netlify/functions/', import.meta.url))).sort();
  assert.deepEqual(fn, ['admin-auth.mjs', 'admin-messages.mjs', 'admin-news.mjs', 'admin-resources.mjs', 'chat.mjs', 'contact-status.mjs', 'contact.mjs', 'health.mjs', 'news.mjs', 'resources.mjs']);
  const mig = (await readdir(new URL('../supabase/migrations/', import.meta.url))).sort();
  assert.deepEqual(mig, ['001_initial_schema.sql', '002_seed_resources.sql', '003_news.sql']);
  assert.equal((admHtml.match(/type="password"/g) || []).length, 1, 'un solo formulario de acceso');
});

test('Accesibilidad CSS: foco visible, movimiento reducido, objetivos táctiles y error no solo por color', async () => {
  const css = await leer('public/css/styles.css');
  assert.match(css, /:focus-visible\{outline:3px solid/);
  assert.match(css, /@media\(prefers-reduced-motion:reduce\)/);
  assert.match(css, /html\[data-calma="1"\]/);
  assert.match(css, /#v-ajustes \.panel \.check\{min-height:44px/);
  assert.match(css, /\.estado\.err:not\(:empty\)::before/);
  assert.match(admCss, /\.adm-nav \[data-sec\]\{min-height:44px\}/);
  assert.match(admCss, /@media\(max-width:34rem\)/);
});
