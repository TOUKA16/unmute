/* Bloque 5 · Necesito ayuda + Contacto con seguimiento + gestión administrativa.
   Comprobaciones ESTÁTICAS (leen archivos) y una prueba de help.js con un DOM mínimo simulado (node:vm).
   No sustituyen una prueba en navegador real: ver CHANGELOG_BLOQUE_5.md. */
import { test } from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFile } from 'node:fs/promises';

const leer = (rel) => readFile(new URL(`../${rel}`, import.meta.url), 'utf8');
const sinComentarios = (s) => s.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^\s*\/\/.*$/gm, '');

/* ---- DOM mínimo: lo justo para ejecutar help.js ---- */
function domFalso() {
  const ids = new Map();
  const nodo = (tag) => ({
    tag, className: '', _t: '', attrs: {}, children: [], hidden: false,
    get childNodes() { return this.children; },
    set textContent(v) { this._t = String(v); this.children = []; },
    get textContent() { return this._t + this.children.map((c) => c.textContent).join(''); },
    classList: { add() {}, remove() {} },
    setAttribute(k, v) { this.attrs[k] = v; }, appendChild(c) { this.children.push(c); return c; }
  });
  for (const id of ['v-ayuda', 'ayudaLista', 'ayudaEstado', 'ayudaNota']) ids.set(id, nodo('x'));
  const listeners = {};
  const document = {
    body: { dataset: {} }, getElementById: (id) => ids.get(id) || null, createElement: nodo,
    createTextNode: (t) => ({ tag: '#text', textContent: String(t), children: [] }), addEventListener: (n, f) => { listeners[n] = f; }
  };
  return { document, ids, abrir: () => listeners['unmute:vista']({ detail: 'ayuda' }) };
}
const recorrer = (n, f) => { f(n); (n.children || []).forEach((c) => recorrer(c, f)); };
async function ejecutarAyuda(directorio) {
  const dom = domFalso();
  const ctx = vm.createContext({ document: dom.document, window: { UNMUTE_HELP: directorio }, Intl, Date });
  vm.runInContext(await leer('public/js/help.js'), ctx);
  dom.abrir();
  return dom;
}
async function directorioReal() {
  const ctx = vm.createContext({ window: {} });
  vm.runInContext(await leer('public/js/help-directory.js'), ctx);
  return ctx.window.UNMUTE_HELP;
}

test('Ayuda: vista secundaria en «Más», sin sexta opción principal y con accesos a Pausa y Acompañar', async () => {
  const html = await leer('public/index.html');
  const app = await leer('public/js/app.js');
  const menu = html.slice(html.indexOf('id="menuMas"'), html.indexOf('</nav>'));
  assert.match(menu, /href="#ayuda" data-v="ayuda">Necesito ayuda/);
  assert.match(app, /const VISTAS = \[[^\]]*'ayuda'[^\]]*'contacto'/);
  assert.match(app, /const EN_MAS = \[[^\]]*'ayuda'[^\]]*'contacto'/);
  const v = html.slice(html.indexOf('id="v-ayuda"'), html.indexOf('id="v-contacto"'));
  assert.match(v, /href="#pausa"/); assert.match(v, /href="#acompanar"/);
  assert.match(v, /no diagnostica/i); assert.match(v, /no es atención profesional ni un servicio de emergencias/i); assert.match(v, /no puede llamar a nadie ni enviar ayuda/i);
  assert.match(v, /opcionales y puedes detenerlos/i);
  assert.doesNotMatch(v, /detecta|detección/i, 'no se promete detección de crisis por IA');
  assert.ok(html.indexOf('js/help-directory.js') < html.indexOf('js/help.js'), 'el directorio se carga antes de help.js');
});

test('Ayuda: muestra los 4 recursos del directorio con cobertura, teléfono, WhatsApp, fuente y verificación correctos', async () => {
  const dir = await directorioReal();
  const { ids } = await ejecutarAyuda(dir);
  const tarjetas = ids.get('ayudaLista').children;
  assert.equal(tarjetas.length, 4);
  const textos = tarjetas.map((t) => t.textContent);
  ['123', '106', '141', '155'].forEach((n, i) => assert.match(textos[i], new RegExp(`Llamar al ${n}`)));
  assert.match(textos[1], /Cobertura: Bogotá/); assert.doesNotMatch(textos[1], /Todo el país/);
  for (const i of [0, 2, 3]) assert.match(textos[i], /Cobertura: Todo el país/);
  const enlaces = tarjetas.map((t) => { const l = []; recorrer(t, (n) => { if (n.tag === 'a') l.push(n.attrs); }); return l; });
  tarjetas.forEach((_, i) => assert.ok(enlaces[i].some((a) => /^tel:\d+$/.test(a.href)), 'enlace tel:'));
  assert.deepEqual(enlaces.map((l) => l.filter((a) => /wa\.me/.test(a.href)).length), [0, 1, 0, 0], 'WhatsApp solo en la 106');
  assert.ok(enlaces[1].some((a) => a.href === 'https://wa.me/573007548933'));
  tarjetas.forEach((t, i) => { assert.match(textos[i], /Fuente oficial: /); assert.match(textos[i], /Verificado el 16 de noviembre de 2026/); assert.ok(enlaces[i].some((a) => /^https:\/\//.test(a.href) && a.rel.includes('noopener'))); });
  assert.match(ids.get('ayudaNota').textContent, /Secretaría de Salud/);
});

test('Ayuda: un recurso incompleto no oculta los demás; sin directorio, error comprensible sin inventar números', async () => {
  const dir = await directorioReal();
  const roto = JSON.parse(JSON.stringify(dir)); roto.countries[0].resources[1] = { id: 'x' };
  const parcial = await ejecutarAyuda(roto);
  assert.equal(parcial.ids.get('ayudaLista').children.length, 3);
  assert.match(parcial.ids.get('ayudaEstado').textContent, /Las demás siguen disponibles/);
  const sin = await ejecutarAyuda(undefined);
  assert.equal(sin.ids.get('ayudaLista').children.length, 0);
  const msg = sin.ids.get('ayudaEstado').textContent;
  assert.match(msg, /No pudimos cargar/); assert.doesNotMatch(msg, /\d{3}/);
});

test('Ayuda: sin geolocalización, sin red, sin almacenamiento ni diario; texto seguro', async () => {
  const src = await leer('public/js/help.js');
  const limpio = sinComentarios(src);
  assert.ok(!/geolocation|fetch\(|XMLHttpRequest|localStorage|sessionStorage|unmute_v2_|navigator\./.test(limpio));
  assert.ok(!/innerHTML|outerHTML|insertAdjacentHTML|document\.write|eval\(/.test(limpio));
  const dir = await leer('public/js/help-directory.js');
  assert.ok(!/\binternational|findahelpline/i.test(sinComentarios(src)), 'no usa el bloque «other» como si fuera local');
  assert.match(dir, /default: 'CO'/);
});

test('Contacto: formulario con campos, categorías en español, consentimiento desmarcado y aviso de no-emergencias', async () => {
  const html = await leer('public/index.html');
  const v = html.slice(html.indexOf('id="v-contacto"'), html.indexOf('id="v-ajustes"'));
  for (const id of ['cNombre', 'cCorreo', 'cCategoria', 'cMensaje', 'cPriv', 'contEnviar', 'contRef', 'contCopiar', 'contVerEstado', 'segRef', 'segBtn', 'segRes']) assert.match(v, new RegExp(`id="${id}"`), id);
  for (const [valor, etq] of [['consulta', 'Consulta'], ['sugerencia', 'Sugerencia'], ['reporte_tecnico', 'Reporte técnico'], ['otro', 'Otro']]) assert.match(v, new RegExp(`<option value="${valor}">${etq}</option>`));
  assert.doesNotMatch(v.match(/<input[^>]*id="cPriv"[^>]*>/)[0], /checked/);
  assert.match(v, /no atiende emergencias/i); assert.match(v, /data-priv/); assert.match(v, /No podemos prometer confidencialidad absoluta/);
  assert.match(v, /aria-describedby="cNombreErr"/); assert.match(v, /role="status" aria-live="polite" tabindex="-1"/);
  assert.match(v, /type="email"/); assert.match(v, /maxlength="2000"/);
  assert.ok(!/<(textarea|input)[^>]*(diario|entradas)/i.test(v), 'no se pide contenido del diario');
});

test('Contacto: éxito solo con referencia UUID del servidor, un envío a la vez, sin almacenamiento ni diario', async () => {
  const js = await leer('public/js/contact.js');
  const limpio = sinComentarios(js);
  assert.match(js, /d\.saved === true && typeof d\.reference === 'string' && UUID_RE\.test\(d\.reference\)/);
  assert.match(js, /if \(enviando\) return;/);
  assert.match(js, /\/api\/contact'/); assert.match(js, /\/api\/contact\/status\?reference=/);
  assert.match(js, /privacy_accepted: \$\('cPriv'\)\.checked/);
  assert.ok(!/localStorage|sessionStorage|unmute_v2_|setInterval|setTimeout\([^)]*pedir/.test(limpio), 'sin almacenamiento ni reintentos automáticos');
  assert.ok(!/innerHTML|outerHTML|insertAdjacentHTML|document\.write|eval\(/.test(limpio));
  // El texto no se borra salvo en éxito.
  assert.equal((limpio.match(/\.value = ''/g) || []).length >= 1, true);
  assert.ok(limpio.indexOf('function exito') > limpio.indexOf('falla('));
});

test('Seguimiento: la ruta existe en la función, en el comprobador y se enruta en server.js (sin duplicar endpoints)', async () => {
  const fn = await leer('netlify/functions/contact-status.mjs');
  assert.match(fn, /path: '\/api\/contact\/status'/); assert.match(fn, /methods: \['GET'\]/);
  assert.match(fn, /limitarPorCliente/); assert.match(fn, /isUuid/);
  assert.ok(!/console\./.test(sinComentarios(fn)), 'sin registros que incluyan la referencia');
  const svc = await leer('src/services/contact.service.mjs');
  const consulta = svc.slice(svc.indexOf('export async function consultarEstado'), svc.indexOf('export async function listarMensajes'));
  assert.match(consulta, /select: 'status,created_at'/);
  const sinPermitido = consulta.replace("table: 'contact_messages'", '').replace(/select: 'status,created_at'/, '').replace(/No encontramos[^']*/, '');
  assert.ok(!/message|email|name|category/.test(sinPermitido), 'solo estado y fecha');
});

test('Administración: sección «Mensajes de contacto» en el panel existente, etiquetas en español y texto seguro', async () => {
  const html = await leer('public/admin.html');
  const js = await leer('public/js/admin.js');
  assert.match(html, /data-sec="mensajes">Mensajes de contacto/);
  assert.equal((html.match(/id="fLogin"/g) || []).length, 1, 'un solo login');
  for (const id of ['msgFiltro', 'msgLista', 'msgDetalle', 'msgDTexto', 'msgDEstado', 'msgDGuardar']) assert.match(html, new RegExp(`id="${id}"`), id);
  const filtro = html.match(/<select id="msgFiltro">[\s\S]*?<\/select>/)[0];
  for (const [v, e] of [['new', 'Recibidos'], ['read', 'En revisión'], ['resolved', 'Respondidos'], ['archived', 'Cerrados']]) assert.match(filtro, new RegExp(`value="${v}">${e}<`));
  assert.match(js, /'\/api\/admin\/messages'/); assert.match(js, /metodo: 'PATCH'/); assert.match(js, /cuerpo: \{ status: nuevo \}/);
  assert.ok(!/innerHTML|outerHTML|insertAdjacentHTML|document\.write|eval\(/.test(sinComentarios(js)), 'el mensaje se muestra como texto, nunca como HTML');
  assert.ok(!/DELETE/.test(js.slice(js.indexOf('Mensajes de contacto (GET'), js.indexOf('Comprobación de la sesión'))), 'sin borrado de mensajes');
  assert.match(js, /\$\('msgDTexto'\)\.textContent = m\.message/);
});

test('Regresión: el diario sigue local y las vistas nuevas no tocan sus claves', async () => {
  const app = await leer('public/js/app.js');
  assert.ok(app.includes("const K = {ent: 'unmute_v2_entradas', bor: 'unmute_v2_borrador', pref: 'unmute_v2_prefs', v1: 'unmute_registros_v1'};"), 'claves del diario intactas');
  for (const f of ['public/js/help.js', 'public/js/contact.js']) assert.ok(!/unmute_v2_|unmute_registros|entradas|borrador/.test(sinComentarios(await leer(f))), f);
  const html = await leer('public/index.html');
  assert.equal((html.match(/id="menuMas"/g) || []).length, 1);
  assert.match(html, /<script src="js\/contact\.js"><\/script>/);
});

test('Responsive/accesibilidad: estilos nuevos reutilizan variables y evitan desbordes; sin migración ni cambios de RLS', async () => {
  const css = await leer('public/css/styles.css');
  const bloque = css.slice(css.indexOf('Bloque 5'));
  assert.match(bloque, /\.ayuda-lista\{[^}]*grid-template-columns:1fr\}/); assert.match(bloque, /overflow-wrap:anywhere/);
  assert.ok(!/#[0-9a-f]{3,6}\b/i.test(bloque), 'solo variables de color del tema');
  const { readdir } = await import('node:fs/promises');
  assert.deepEqual((await readdir(new URL('../supabase/migrations', import.meta.url))).sort(), ['001_initial_schema.sql', '002_seed_resources.sql', '003_news.sql']);
});
