/* ==========================================================
   UNMUTE · Servicios simulados para las pruebas (sin internet ni credenciales)
   · iniciarOpenAISimulado(): imita POST /v1/responses.
   · iniciarSupabaseSimulado(): imita Auth (/auth/v1) y PostgREST (/rest/v1) con reglas de acceso
     equivalentes a las políticas RLS de la migración. Sirve para comprobar CÓMO usa el backend cada rol;
     NO demuestra que las políticas SQL reales funcionen (eso solo se prueba contra un Supabase real).
   ========================================================== */
import http from 'node:http';
import { randomUUID } from 'node:crypto';

// La clave anónima imita el formato JWT clásico (se envía también como Bearer);
// la de servicio imita el formato nuevo (solo cabecera apikey).
export const CLAVES = { anon: 'eyJhbGciOiJIUzI1NiJ9.anon.firma', servicio: 'sb_secret_prueba', openai: 'sk-prueba-openai' };

const leer = (req) => new Promise((ok) => { const t = []; req.on('data', (c) => t.push(c)); req.on('end', () => { const s = Buffer.concat(t).toString('utf8'); try { ok(s ? JSON.parse(s) : undefined); } catch { ok(undefined); } }); });
const responder = (res, status, datos) => { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(datos === undefined ? '' : JSON.stringify(datos)); };
const escuchar = (servidor) => new Promise((ok) => servidor.listen(0, '127.0.0.1', () => ok(`http://127.0.0.1:${servidor.address().port}`)));

export async function iniciarOpenAISimulado() {
  const estado = { modo: 'ok', llamadas: [] };
  const servidor = http.createServer(async (req, res) => {
    const cuerpo = await leer(req);
    estado.llamadas.push({ url: req.url, auth: req.headers.authorization, cuerpo });
    if (req.headers.authorization !== `Bearer ${CLAVES.openai}`) return responder(res, 401, { error: { message: 'bad key' } });
    const errores = { '429': 429, '401': 401, '404': 404, '400': 400, '500': 500 };
    if (errores[estado.modo]) return responder(res, errores[estado.modo], { error: { message: 'simulado', code: 'x' } });
    if (estado.modo === 'incompleto') return responder(res, 200, { status: 'incomplete', output: [{ type: 'reasoning', summary: [] }] });
    responder(res, 200, { id: 'resp_1', status: 'completed', model: cuerpo?.model, output: [
      { type: 'reasoning', summary: [] },
      { type: 'message', role: 'assistant', content: [{ type: 'output_text', text: 'Gracias por contármelo. ¿Qué parte te pesa más ahora?' }] }
    ] });
  });
  const url = await escuchar(servidor);
  return { url: `${url}/v1`, estado, cerrar: () => new Promise((ok) => servidor.close(ok)) };
}

export async function iniciarSupabaseSimulado() {
  const estado = { usuarios: new Map(), tokens: new Map(), recursos: [], noticias: [], mensajes: [], limites: new Map(), llamadas: [], rpcLlamadas: [], rpcModo: 'ok' };

  const crearUsuario = (email, password, rol = 'user') => { const u = { id: randomUUID(), email, password, role: rol }; estado.usuarios.set(email, u); return u; };
  const nuevoRecurso = (r) => { const f = { id: randomUUID(), content: '', icon: null, image_url: null, action_url: null, source_url: null, status: 'draft', featured: false, reviewed_at: null, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), ...r }; estado.recursos.push(f); return f; };

  function actor(req) {
    const apikey = req.headers.apikey;
    const bearer = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
    if (apikey === CLAVES.servicio) return { rol: 'service' };
    if (apikey !== CLAVES.anon) return null;
    if (bearer && bearer !== CLAVES.anon) {
      const uid = estado.tokens.get(bearer);
      if (!uid) return { invalido: true };
      const u = [...estado.usuarios.values()].find((x) => x.id === uid);
      return { rol: 'authenticated', uid, admin: u?.role === 'admin' };
    }
    return { rol: 'anon' };
  }

  function filtrar(filas, params) {
    let r = filas;
    for (const [k, v] of params) if (v.startsWith('eq.') && !['select', 'order', 'limit'].includes(k)) r = r.filter((f) => String(f[k]) === v.slice(3));
    const orden = params.get('order');
    if (orden) {
      const reglas = orden.split(',').map((x) => x.split('.'));
      r = [...r].sort((a, b) => { for (const [col, dir = 'asc'] of reglas) { if (a[col] === b[col]) continue; const c = a[col] > b[col] ? 1 : -1; return dir === 'desc' ? -c : c; } return 0; });
    }
    return params.get('limit') ? r.slice(0, Number(params.get('limit'))) : r;
  }
  const puedeAdmin = (a) => a.rol === 'service' || (a.rol === 'authenticated' && a.admin);

  const servidor = http.createServer(async (req, res) => {
    const u = new URL(req.url, 'http://x');
    const cuerpo = await leer(req);
    const a = actor(req);
    estado.llamadas.push({ metodo: req.method, ruta: u.pathname, rol: a?.rol ?? (a?.invalido ? 'invalido' : 'sin-clave'), apikey: req.headers.apikey, auth: req.headers.authorization });
    if (!a || a.invalido) return responder(res, 401, { code: 401, msg: 'Invalid API key / JWT' });

    /* ---- Auth ---- */
    if (u.pathname === '/auth/v1/token' && req.method === 'POST') {
      const usr = estado.usuarios.get(cuerpo?.email);
      if (!usr || usr.password !== cuerpo?.password) return responder(res, 400, { error_code: 'invalid_credentials', msg: 'Invalid login credentials' });
      const token = `tok-${randomUUID()}`; estado.tokens.set(token, usr.id);
      return responder(res, 200, { access_token: token, token_type: 'bearer', expires_in: 3600, refresh_token: 'r', user: { id: usr.id, email: usr.email } });
    }
    if (u.pathname === '/auth/v1/user') {
      const uid = estado.tokens.get((req.headers.authorization || '').replace(/^Bearer\s+/i, ''));
      const usr = [...estado.usuarios.values()].find((x) => x.id === uid);
      return usr ? responder(res, 200, { id: usr.id, email: usr.email }) : responder(res, 401, { code: 401, msg: 'invalid JWT' });
    }
    if (u.pathname === '/auth/v1/logout') { estado.tokens.delete((req.headers.authorization || '').replace(/^Bearer\s+/i, '')); return responder(res, 204); }

    /* ---- RPC: límite de uso (misma lógica que la función SQL) ---- */
    if (u.pathname === '/rest/v1/rpc/consume_rate_limit') {
      if (a.rol !== 'service') return responder(res, 403, { code: '42501' });
      // Modos de fallo del RPC (para probar que el backend falla de forma controlada):
      estado.rpcLlamadas.push({ bucket: cuerpo?.p_bucket, limite: cuerpo?.p_limit, ventana: cuerpo?.p_window_seconds });
      if (estado.rpcModo === 'ausente') return responder(res, 404, { code: 'PGRST202', message: 'Could not find the function public.consume_rate_limit' });
      if (estado.rpcModo === 'error') return responder(res, 500, { code: 'XX000', message: 'internal error' });
      if (estado.rpcModo === 'malformada') return responder(res, 200, { ok: true });
      const { p_bucket: b, p_limit: l, p_window_seconds: w } = cuerpo; const ahora = Date.now();
      let e = estado.limites.get(b);
      if (!e || e.inicio + w * 1000 <= ahora) e = { inicio: ahora, hits: 0 };
      e.hits += 1; estado.limites.set(b, e);
      const ok = e.hits <= l;
      return responder(res, 200, { allowed: ok, remaining: Math.max(l - e.hits, 0), retry_after: ok ? 0 : Math.max(Math.ceil((e.inicio + w * 1000 - ahora) / 1000), 1) });
    }

    /* ---- Tablas ---- */
    const tabla = /^\/rest\/v1\/([a-z_]+)$/.exec(u.pathname)?.[1];
    const p = u.searchParams;
    if (tabla === 'profiles') {
      if (req.method !== 'GET') return responder(res, 403, { code: '42501' });
      if (a.rol === 'anon') return responder(res, 401, { code: '42501' });
      const filas = [...estado.usuarios.values()].map((x) => ({ id: x.id, role: x.role }));
      return responder(res, 200, filtrar(a.rol === 'service' ? filas : filas.filter((f) => f.id === a.uid), p));
    }
    if (tabla === 'resources') {
      if (req.method === 'GET') return responder(res, 200, filtrar(puedeAdmin(a) ? estado.recursos : estado.recursos.filter((r) => r.status === 'published'), p));
      if (!puedeAdmin(a)) return responder(res, a.rol === 'anon' ? 401 : 403, { code: '42501' });
      if (req.method === 'POST') {
        if (estado.recursos.some((r) => r.slug === cuerpo.slug)) return responder(res, 409, { code: '23505' });
        if (cuerpo.resource_type === 'fact' && cuerpo.status === 'published' && !(cuerpo.source_url && cuerpo.reviewed_at)) return responder(res, 400, { code: '23514' });
        return responder(res, 201, [nuevoRecurso(cuerpo)]);
      }
      const objetivo = filtrar(estado.recursos, p);
      if (req.method === 'PATCH') { objetivo.forEach((r) => Object.assign(r, cuerpo, { updated_at: new Date().toISOString() })); return responder(res, 200, objetivo); }
      if (req.method === 'DELETE') { estado.recursos = estado.recursos.filter((r) => !objetivo.includes(r)); return responder(res, 200, objetivo); }
    }
    if (tabla === 'news') {
      // Imita las políticas RLS y el trigger de la migración 003 (fecha de publicación fijada por el «servidor»).
      const CATS = ['Novedades de UNMUTE', 'Bienestar emocional', 'Autocuidado', 'Actualizaciones', 'Recursos educativos', 'Información importante'];
      if (req.method === 'GET') {
        const filas = filtrar(puedeAdmin(a) ? estado.noticias : estado.noticias.filter((n) => n.status === 'published'), p);
        const cols = (p.get('select') || '*').split(',');   // PostgREST solo devuelve las columnas pedidas
        return responder(res, 200, cols.includes('*') ? filas : filas.map((n) => Object.fromEntries(cols.map((c) => [c, n[c]]))));
      }
      if (!puedeAdmin(a)) return responder(res, a.rol === 'anon' ? 401 : 403, { code: '42501' });
      const fechas = (n, antes) => { n.published_at = n.status === 'published' ? (antes?.status === 'published' ? antes.published_at : new Date().toISOString()) : null; return n; };
      if (req.method === 'POST') {
        if (estado.noticias.some((n) => n.slug === cuerpo.slug)) return responder(res, 409, { code: '23505' });
        if (!CATS.includes(cuerpo.category) || (cuerpo.image_url && !/^https:\/\//i.test(cuerpo.image_url))) return responder(res, 400, { code: '23514' });
        const n = { id: randomUUID(), content: '', image_url: null, status: 'draft', created_by: a.uid ?? null, created_at: new Date().toISOString(), updated_at: new Date().toISOString(), ...cuerpo };
        estado.noticias.push(fechas(n));
        return responder(res, 201, [n]);
      }
      const objetivo = filtrar(estado.noticias, p);
      if (req.method === 'PATCH') { objetivo.forEach((n) => { const antes = { ...n }; Object.assign(n, cuerpo, { updated_at: new Date().toISOString() }); fechas(n, antes); }); return responder(res, 200, objetivo); }
      if (req.method === 'DELETE') { estado.noticias = estado.noticias.filter((n) => !objetivo.includes(n)); return responder(res, 200, objetivo); }
    }
    if (tabla === 'contact_messages') {
      if (req.method === 'POST') {
        if (a.rol !== 'service') return responder(res, 401, { code: '42501' });
        const fila = { id: randomUUID(), status: 'new', created_at: new Date().toISOString(), name: null, email: null, ...cuerpo };
        estado.mensajes.push(fila);
        // Como PostgREST: sin «Prefer: return=representation» el cuerpo llega vacío.
        return responder(res, 201, String(req.headers.prefer || '').includes('return=representation') && !estado.sinRepresentacion ? [fila] : undefined);
      }
      if (!puedeAdmin(a)) return responder(res, a.rol === 'anon' ? 401 : 403, { code: '42501' });
      const objetivo = filtrar(estado.mensajes, p);
      if (req.method === 'GET') return responder(res, 200, objetivo);
      if (req.method === 'PATCH') { objetivo.forEach((m) => Object.assign(m, cuerpo)); return responder(res, 200, objetivo); }
    }
    responder(res, 404, { code: 'PGRST205' });
  });
  const url = await escuchar(servidor);
  return { url, estado, crearUsuario, nuevoRecurso, cerrar: () => new Promise((ok) => servidor.close(ok)) };
}
