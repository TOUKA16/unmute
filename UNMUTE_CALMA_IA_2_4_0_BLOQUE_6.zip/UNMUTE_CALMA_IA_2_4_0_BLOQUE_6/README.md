# UNMUTE · Calma orgánica + IA

**Versión:** 2.4.0  
**Último bloque:** 6 — Administración, Privacidad y Accesibilidad  
**Lema:** «Tu voz también merece ser escuchada».

UNMUTE es un diario emocional digital para que cada persona pueda registrar cómo se siente, escribir libremente, consultar su historia y utilizar herramientas voluntarias de calma y acompañamiento. El diario es el centro de la aplicación; la IA y los demás servicios son complementarios.

## Funcionalidades incluidas

### Experiencia personal
- Inicio con las tarjetas «Un minuto para aprender» y «Noticias de UNMUTE».
- Diario emocional con check-in opcional, emoción, intensidad, título, texto y etiquetas.
- Guardado local, borradores, edición, eliminación y modo sin distracciones.
- Historia con búsqueda, filtros, favoritos y consulta de entradas.
- Pausa con respiración, orientación sensorial, escritura libre y temporizador.
- Acompañar con IA, consentimiento explícito y contexto conversacional limitado.
- Recursos con búsqueda y filtros.
- Noticias públicas.
- Necesito ayuda con el directorio de Colombia.
- Contacto con referencia UUID y consulta de estado.
- Ajustes de tema, accesibilidad, concentración, privacidad y gestión de copias.

### Administración
- Inicio de sesión y verificación de rol.
- Resumen de recursos y mensajes.
- Gestión de datos curiosos.
- Gestión de noticias.
- Gestión de mensajes de contacto y sus estados.
- Limpieza de datos y estados de la interfaz al cerrar sesión.

## Cambios del Bloque 6 (2.4.0)

- Ajustes separados en Tema visual, Accesibilidad, Concentración y escritura, Privacidad y Tus datos.
- Accesibilidad concentra tamaño del texto, reducción de animaciones y desactivación de efectos decorativos.
- El modo sin distracciones queda en Concentración y escritura.
- Privacidad describe los flujos de diario local, IA, Contacto, exportación, importación y eliminación.
- El panel administrativo restablece botones y estados al cerrar sesión, limpia información de sesión del DOM, bloquea acciones simultáneas y mejora la gestión del foco.
- No se modificaron backend, endpoints, autenticación, roles, RLS, base de datos ni migraciones.
- Se conservaron la clave `unmute_v2_prefs`, los valores `PREF0` y los identificadores de controles.
- `public/js/app.js`, `public/js/ai-chat.js` y `public/js/contact.js` permanecen sin cambios en este bloque.

Consulta:
- `INFORME_CAMBIOS_BLOQUE_6.md` para este bloque.
- `INFORME_GENERAL_UNMUTE.md` para la evolución completa y el mapa de implementaciones.
- `CHANGELOG_BLOQUE_6.md` para el registro técnico original.

## Arquitectura

```text
public/                 Frontend HTML, CSS, JavaScript y recursos estáticos
netlify/functions/      APIs serverless
src/config/             Variables y configuración de entorno
src/lib/                HTTP, errores, validación, Supabase y rate limit
src/services/           Servicios de IA, autenticación, recursos, noticias y contacto
src/data/               Semilla privada del catálogo
supabase/migrations/    Esquema, RLS, datos iniciales y noticias
scripts/                Generación de semilla y comprobaciones
tests/                  Pruebas unitarias, API y verificaciones estáticas
server.js               Servidor local de desarrollo
netlify.toml            Configuración de Netlify, rutas y cabeceras
```

**Tecnologías:** HTML5, CSS3 y JavaScript; Node.js; Netlify Functions; Supabase/PostgreSQL/Auth/RLS; OpenAI API.

## Instalación y ejecución local

Requisitos: Node.js 20.12 o superior.

1. Copia `.env.example` como `.env`.
2. Configura las variables necesarias. No subas ni compartas `.env`.
3. Instala dependencias:

```bash
npm install
```

4. Inicia el servidor local:

```bash
npm start
```

5. Abre `http://localhost:3000`. La administración se encuentra en `http://localhost:3000/admin`.

Para utilizar Netlify CLI:

```bash
npm run dev
```

Se requieren las variables del archivo `.env.example`. Para utilizar IA, configura una clave API válida y un `OPENAI_MODEL` habilitado para tu cuenta.

## Supabase y migraciones

El proyecto incluye:

1. `supabase/migrations/001_initial_schema.sql`
2. `supabase/migrations/002_seed_resources.sql`
3. `supabase/migrations/003_news.sql`

Ejecútalas en ese orden en el proyecto Supabase correspondiente si todavía no están aplicadas. Antes de repetir una migración, confirma su estado en el proyecto. La semilla fuente se encuentra en `src/data/resources-seed.json`, fuera de `public/`, porque contiene borradores.

Comandos:

```bash
npm run seed:build
npm run seed:check
```

## Variables y secretos

Consulta `.env.example`. Las credenciales privadas, incluidas `OPENAI_API_KEY` y `SUPABASE_SERVICE_ROLE_KEY`/`SUPABASE_SECRET_KEY`, solo deben configurarse en el servidor o en el entorno de Functions de Netlify. No deben aparecer en HTML, CSS, JavaScript público ni Git.

## Pruebas

```bash
npm test
npm run check
npm run seed:check
npm run e2e
```

Resultados reproducidos sobre el paquete 2.4.0:
- `npm test`: **108/108 pruebas aprobadas**.
- `npm run check`: **45 correctas, 0 errores y 1 advertencia**.
- `npm run seed:check`: correcto.
- `npm run e2e`: no ejecutable porque falta `tests/e2e-smoke.mjs`.

Las pruebas del Bloque 6 son estáticas y revisan estructura, ARIA, controles, gestión de foco y ausencia de cambios fuera del alcance. No equivalen a una auditoría visual, lector de pantalla o certificación WCAG.

## Privacidad

- El diario y los borradores se almacenan en `localStorage`; no están cifrados ni sincronizados.
- No se envían automáticamente entradas del diario a Supabase ni a OpenAI.
- Acompañar transmite únicamente los mensajes que la persona decide enviar y el contexto reciente de esa conversación después de aceptar el consentimiento.
- `store: false` no equivale a una garantía de retención cero del proveedor.
- Contacto guarda los datos del formulario en Supabase para su gestión administrativa; el seguimiento público devuelve solo estado y fecha de recepción.
- «Eliminar todos mis datos» elimina el contenido local de UNMUTE en ese navegador, no los mensajes almacenados en Supabase ni el tratamiento que pudiera realizar el proveedor de IA.
- El consentimiento de Contacto se exige en el servidor, pero no se registra en una columna independiente en esta versión.
- No se ha implementado una política de retención ni borrado automático de mensajes.

UNMUTE IA no diagnostica ni sustituye profesionales de salud o servicios de emergencia. Puede equivocarse y no garantiza detectar situaciones de crisis.

## Publicación

El despliegue previsto usa Netlify:
- Frontend desde `public/`.
- Funciones desde `netlify/functions/`.
- Variables privadas configuradas en Netlify con alcance de Functions.
- Supabase para datos y autenticación.
- OpenAI desde el backend.

Antes de considerar la publicación final, verifica las migraciones aplicadas, RLS, variables, APIs, flujo de contacto y navegación administrativa en el entorno real.

---

**UNMUTE — Tu voz también merece ser escuchada.**
